﻿namespace ECR_Veriphone_Demo
{
    partial class frmMain
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.ddlComPorts = new System.Windows.Forms.ComboBox();
            this.btnRefreshComPorts = new System.Windows.Forms.Button();
            this.lblComPorts = new System.Windows.Forms.Label();
            this.lblBaudrate = new System.Windows.Forms.Label();
            this.ddlBaudrate = new System.Windows.Forms.ComboBox();
            this.lblStopBits = new System.Windows.Forms.Label();
            this.ddlStopbits = new System.Windows.Forms.ComboBox();
            this.lblDatabits = new System.Windows.Forms.Label();
            this.ddlDatabits = new System.Windows.Forms.ComboBox();
            this.lblParity = new System.Windows.Forms.Label();
            this.ddlParity = new System.Windows.Forms.ComboBox();
            this.btnVenta = new System.Windows.Forms.Button();
            this.txtMonto = new System.Windows.Forms.TextBox();
            this.lblMonto = new System.Windows.Forms.Label();
            this.btnCierre = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtTimeout = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSerial = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtDisplayText = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtBinTableId = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtTransactionType = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtE2 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtIssuerAuth = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtResponseCode = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtAutorizado = new System.Windows.Forms.TextBox();
            this.chkEnmascarar = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCurrencyCode = new System.Windows.Forms.TextBox();
            this.lblTokenE1 = new System.Windows.Forms.Label();
            this.txtTokenE1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtCurrencyIndex = new System.Windows.Forms.TextBox();
            this.lblTipUSd = new System.Windows.Forms.Label();
            this.txtTipUSD = new System.Windows.Forms.TextBox();
            this.lblCashbackUSD = new System.Windows.Forms.Label();
            this.txtCashbackUSD = new System.Windows.Forms.TextBox();
            this.lblMontoUSD = new System.Windows.Forms.Label();
            this.txtMontoUSD = new System.Windows.Forms.TextBox();
            this.lblTip = new System.Windows.Forms.Label();
            this.txtTip = new System.Windows.Forms.TextBox();
            this.lblCashback = new System.Windows.Forms.Label();
            this.txtCashback = new System.Windows.Forms.TextBox();
            this.lblVoucher = new System.Windows.Forms.Label();
            this.txtVoucher = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtECRId = new System.Windows.Forms.TextBox();
            this.btnECRSync = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lblResponseCode = new System.Windows.Forms.Label();
            this.lblSerial = new System.Windows.Forms.Label();
            this.lblSoftwareVersion = new System.Windows.Forms.Label();
            this.lblVoucherNumber = new System.Windows.Forms.Label();
            this.lblCurrencyCode = new System.Windows.Forms.Label();
            this.lblCardType = new System.Windows.Forms.Label();
            this.lblCard = new System.Windows.Forms.Label();
            this.lblCardHolderName = new System.Windows.Forms.Label();
            this.lblAuth = new System.Windows.Forms.Label();
            this.lblAmountAuthorized = new System.Windows.Forms.Label();
            this.lblHora = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblHostResponse = new System.Windows.Forms.Label();
            this.lblResult = new System.Windows.Forms.Label();
            this.btnAnulacion = new System.Windows.Forms.Button();
            this.btnbAuth = new System.Windows.Forms.Button();
            this.btnPreAuth = new System.Windows.Forms.Button();
            this.btnPreAuthGas = new System.Windows.Forms.Button();
            this.btnAuthGas = new System.Windows.Forms.Button();
            this.btnTopUp = new System.Windows.Forms.Button();
            this.chkIncluirMensaje = new System.Windows.Forms.CheckBox();
            this.btnStoreBin = new System.Windows.Forms.Button();
            this.btnCancelServices = new System.Windows.Forms.Button();
            this.btnDisplayText = new System.Windows.Forms.Button();
            this.btnLlave = new System.Windows.Forms.Button();
            this.btnCorresponsal = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // ddlComPorts
            // 
            this.ddlComPorts.FormattingEnabled = true;
            this.ddlComPorts.Location = new System.Drawing.Point(108, 32);
            this.ddlComPorts.Name = "ddlComPorts";
            this.ddlComPorts.Size = new System.Drawing.Size(121, 21);
            this.ddlComPorts.TabIndex = 0;
            // 
            // btnRefreshComPorts
            // 
            this.btnRefreshComPorts.Location = new System.Drawing.Point(235, 33);
            this.btnRefreshComPorts.Name = "btnRefreshComPorts";
            this.btnRefreshComPorts.Size = new System.Drawing.Size(41, 23);
            this.btnRefreshComPorts.TabIndex = 1;
            this.btnRefreshComPorts.Text = "...";
            this.btnRefreshComPorts.UseVisualStyleBackColor = true;
            this.btnRefreshComPorts.Click += new System.EventHandler(this.BtnRefreshComPorts_Click);
            // 
            // lblComPorts
            // 
            this.lblComPorts.AutoSize = true;
            this.lblComPorts.Location = new System.Drawing.Point(32, 38);
            this.lblComPorts.Name = "lblComPorts";
            this.lblComPorts.Size = new System.Drawing.Size(70, 13);
            this.lblComPorts.TabIndex = 2;
            this.lblComPorts.Text = "Puertos COM";
            // 
            // lblBaudrate
            // 
            this.lblBaudrate.AutoSize = true;
            this.lblBaudrate.Location = new System.Drawing.Point(32, 65);
            this.lblBaudrate.Name = "lblBaudrate";
            this.lblBaudrate.Size = new System.Drawing.Size(50, 13);
            this.lblBaudrate.TabIndex = 4;
            this.lblBaudrate.Text = "Baudrate";
            // 
            // ddlBaudrate
            // 
            this.ddlBaudrate.FormattingEnabled = true;
            this.ddlBaudrate.Items.AddRange(new object[] {
            "9600",
            "14400",
            "19200",
            "38400",
            "56000",
            "57600",
            "115200",
            "128000",
            "256000"});
            this.ddlBaudrate.Location = new System.Drawing.Point(108, 59);
            this.ddlBaudrate.Name = "ddlBaudrate";
            this.ddlBaudrate.Size = new System.Drawing.Size(121, 21);
            this.ddlBaudrate.TabIndex = 3;
            this.ddlBaudrate.Text = "115200";
            // 
            // lblStopBits
            // 
            this.lblStopBits.AutoSize = true;
            this.lblStopBits.Location = new System.Drawing.Point(32, 92);
            this.lblStopBits.Name = "lblStopBits";
            this.lblStopBits.Size = new System.Drawing.Size(46, 13);
            this.lblStopBits.TabIndex = 6;
            this.lblStopBits.Text = "StopBits";
            // 
            // ddlStopbits
            // 
            this.ddlStopbits.FormattingEnabled = true;
            this.ddlStopbits.Items.AddRange(new object[] {
            "1",
            "1.5",
            "2"});
            this.ddlStopbits.Location = new System.Drawing.Point(108, 86);
            this.ddlStopbits.Name = "ddlStopbits";
            this.ddlStopbits.Size = new System.Drawing.Size(121, 21);
            this.ddlStopbits.TabIndex = 5;
            this.ddlStopbits.Text = "1";
            // 
            // lblDatabits
            // 
            this.lblDatabits.AutoSize = true;
            this.lblDatabits.Location = new System.Drawing.Point(32, 119);
            this.lblDatabits.Name = "lblDatabits";
            this.lblDatabits.Size = new System.Drawing.Size(47, 13);
            this.lblDatabits.TabIndex = 8;
            this.lblDatabits.Text = "DataBits";
            // 
            // ddlDatabits
            // 
            this.ddlDatabits.FormattingEnabled = true;
            this.ddlDatabits.Items.AddRange(new object[] {
            "7",
            "8"});
            this.ddlDatabits.Location = new System.Drawing.Point(108, 113);
            this.ddlDatabits.Name = "ddlDatabits";
            this.ddlDatabits.Size = new System.Drawing.Size(121, 21);
            this.ddlDatabits.TabIndex = 7;
            this.ddlDatabits.Text = "8";
            // 
            // lblParity
            // 
            this.lblParity.AutoSize = true;
            this.lblParity.Location = new System.Drawing.Point(32, 146);
            this.lblParity.Name = "lblParity";
            this.lblParity.Size = new System.Drawing.Size(33, 13);
            this.lblParity.TabIndex = 10;
            this.lblParity.Text = "Parity";
            // 
            // ddlParity
            // 
            this.ddlParity.FormattingEnabled = true;
            this.ddlParity.Items.AddRange(new object[] {
            "None",
            "Odd",
            "Even"});
            this.ddlParity.Location = new System.Drawing.Point(108, 140);
            this.ddlParity.Name = "ddlParity";
            this.ddlParity.Size = new System.Drawing.Size(121, 21);
            this.ddlParity.TabIndex = 9;
            this.ddlParity.Text = "None";
            // 
            // btnVenta
            // 
            this.btnVenta.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVenta.Location = new System.Drawing.Point(527, 475);
            this.btnVenta.Name = "btnVenta";
            this.btnVenta.Size = new System.Drawing.Size(119, 39);
            this.btnVenta.TabIndex = 11;
            this.btnVenta.Text = "Venta";
            this.btnVenta.UseVisualStyleBackColor = true;
            this.btnVenta.Click += new System.EventHandler(this.BtnVenta_Click);
            // 
            // txtMonto
            // 
            this.txtMonto.Location = new System.Drawing.Point(9, 42);
            this.txtMonto.Name = "txtMonto";
            this.txtMonto.Size = new System.Drawing.Size(119, 20);
            this.txtMonto.TabIndex = 13;
            this.txtMonto.Text = "1.00";
            // 
            // lblMonto
            // 
            this.lblMonto.AutoSize = true;
            this.lblMonto.Location = new System.Drawing.Point(6, 24);
            this.lblMonto.Name = "lblMonto";
            this.lblMonto.Size = new System.Drawing.Size(37, 13);
            this.lblMonto.TabIndex = 14;
            this.lblMonto.Text = "Monto";
            // 
            // btnCierre
            // 
            this.btnCierre.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCierre.Location = new System.Drawing.Point(652, 521);
            this.btnCierre.Name = "btnCierre";
            this.btnCierre.Size = new System.Drawing.Size(119, 40);
            this.btnCierre.TabIndex = 15;
            this.btnCierre.Text = "Cierre";
            this.btnCierre.UseVisualStyleBackColor = true;
            this.btnCierre.Click += new System.EventHandler(this.BtnCierre_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 173);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "Timeout";
            // 
            // txtTimeout
            // 
            this.txtTimeout.Location = new System.Drawing.Point(108, 167);
            this.txtTimeout.Name = "txtTimeout";
            this.txtTimeout.Size = new System.Drawing.Size(121, 20);
            this.txtTimeout.TabIndex = 17;
            this.txtTimeout.Text = "20000";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(293, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "Serial";
            // 
            // txtSerial
            // 
            this.txtSerial.Location = new System.Drawing.Point(296, 43);
            this.txtSerial.Name = "txtSerial";
            this.txtSerial.Size = new System.Drawing.Size(119, 20);
            this.txtSerial.TabIndex = 18;
            this.txtSerial.Text = "0331374507";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.txtDisplayText);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txtBinTableId);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.txtTransactionType);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txtE2);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txtIssuerAuth);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtResponseCode);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtAutorizado);
            this.groupBox1.Controls.Add(this.chkEnmascarar);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtCurrencyCode);
            this.groupBox1.Controls.Add(this.lblTokenE1);
            this.groupBox1.Controls.Add(this.txtTokenE1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtCurrencyIndex);
            this.groupBox1.Controls.Add(this.lblTipUSd);
            this.groupBox1.Controls.Add(this.txtTipUSD);
            this.groupBox1.Controls.Add(this.lblCashbackUSD);
            this.groupBox1.Controls.Add(this.txtCashbackUSD);
            this.groupBox1.Controls.Add(this.lblMontoUSD);
            this.groupBox1.Controls.Add(this.txtMontoUSD);
            this.groupBox1.Controls.Add(this.lblTip);
            this.groupBox1.Controls.Add(this.txtTip);
            this.groupBox1.Controls.Add(this.lblCashback);
            this.groupBox1.Controls.Add(this.txtCashback);
            this.groupBox1.Controls.Add(this.lblVoucher);
            this.groupBox1.Controls.Add(this.txtVoucher);
            this.groupBox1.Controls.Add(this.lblMonto);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtMonto);
            this.groupBox1.Controls.Add(this.txtSerial);
            this.groupBox1.Location = new System.Drawing.Point(529, 38);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(424, 431);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Autorización";
            this.groupBox1.Enter += new System.EventHandler(this.GroupBox1_Enter);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(293, 260);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 13);
            this.label13.TabIndex = 52;
            this.label13.Text = "Display Text";
            // 
            // txtDisplayText
            // 
            this.txtDisplayText.Location = new System.Drawing.Point(296, 277);
            this.txtDisplayText.MaxLength = 100;
            this.txtDisplayText.Name = "txtDisplayText";
            this.txtDisplayText.Size = new System.Drawing.Size(119, 20);
            this.txtDisplayText.TabIndex = 51;
            this.txtDisplayText.Text = "Pinpad Test";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(292, 211);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(64, 13);
            this.label12.TabIndex = 50;
            this.label12.Text = "Bin Table Id";
            // 
            // txtBinTableId
            // 
            this.txtBinTableId.Location = new System.Drawing.Point(295, 228);
            this.txtBinTableId.MaxLength = 100;
            this.txtBinTableId.Name = "txtBinTableId";
            this.txtBinTableId.Size = new System.Drawing.Size(119, 20);
            this.txtBinTableId.TabIndex = 49;
            this.txtBinTableId.Text = "00000000";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(152, 212);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(90, 13);
            this.label11.TabIndex = 48;
            this.label11.Text = "Transaction Type";
            // 
            // txtTransactionType
            // 
            this.txtTransactionType.Location = new System.Drawing.Point(151, 228);
            this.txtTransactionType.MaxLength = 2;
            this.txtTransactionType.Name = "txtTransactionType";
            this.txtTransactionType.Size = new System.Drawing.Size(100, 20);
            this.txtTransactionType.TabIndex = 47;
            this.txtTransactionType.Text = "B7";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(5, 376);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 13);
            this.label10.TabIndex = 46;
            this.label10.Text = "Token E2";
            // 
            // txtE2
            // 
            this.txtE2.Location = new System.Drawing.Point(8, 394);
            this.txtE2.Name = "txtE2";
            this.txtE2.Size = new System.Drawing.Size(404, 20);
            this.txtE2.TabIndex = 45;
            this.txtE2.Text = "9F269F279F36959F109F379BA8";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 285);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(132, 13);
            this.label9.TabIndex = 44;
            this.label9.Text = "Issuer Authentication Data";
            // 
            // txtIssuerAuth
            // 
            this.txtIssuerAuth.Location = new System.Drawing.Point(6, 303);
            this.txtIssuerAuth.Name = "txtIssuerAuth";
            this.txtIssuerAuth.Size = new System.Drawing.Size(404, 20);
            this.txtIssuerAuth.TabIndex = 43;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 213);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 13);
            this.label8.TabIndex = 42;
            this.label8.Text = "Response Code";
            // 
            // txtResponseCode
            // 
            this.txtResponseCode.Location = new System.Drawing.Point(9, 230);
            this.txtResponseCode.MaxLength = 2;
            this.txtResponseCode.Name = "txtResponseCode";
            this.txtResponseCode.Size = new System.Drawing.Size(119, 20);
            this.txtResponseCode.TabIndex = 41;
            this.txtResponseCode.Text = "00";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(292, 160);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 13);
            this.label7.TabIndex = 40;
            this.label7.Text = "Autorizado";
            // 
            // txtAutorizado
            // 
            this.txtAutorizado.Location = new System.Drawing.Point(295, 177);
            this.txtAutorizado.MaxLength = 6;
            this.txtAutorizado.Name = "txtAutorizado";
            this.txtAutorizado.Size = new System.Drawing.Size(119, 20);
            this.txtAutorizado.TabIndex = 39;
            this.txtAutorizado.Text = "000002";
            // 
            // chkEnmascarar
            // 
            this.chkEnmascarar.AutoSize = true;
            this.chkEnmascarar.Checked = true;
            this.chkEnmascarar.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkEnmascarar.Location = new System.Drawing.Point(152, 177);
            this.chkEnmascarar.Name = "chkEnmascarar";
            this.chkEnmascarar.Size = new System.Drawing.Size(107, 17);
            this.chkEnmascarar.TabIndex = 38;
            this.chkEnmascarar.Text = "Enmascarar PAN";
            this.chkEnmascarar.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 158);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 13);
            this.label6.TabIndex = 37;
            this.label6.Text = "Currency Code";
            // 
            // txtCurrencyCode
            // 
            this.txtCurrencyCode.Location = new System.Drawing.Point(9, 175);
            this.txtCurrencyCode.MaxLength = 4;
            this.txtCurrencyCode.Name = "txtCurrencyCode";
            this.txtCurrencyCode.Size = new System.Drawing.Size(119, 20);
            this.txtCurrencyCode.TabIndex = 36;
            this.txtCurrencyCode.Text = "0484";
            // 
            // lblTokenE1
            // 
            this.lblTokenE1.AutoSize = true;
            this.lblTokenE1.Location = new System.Drawing.Point(3, 328);
            this.lblTokenE1.Name = "lblTokenE1";
            this.lblTokenE1.Size = new System.Drawing.Size(54, 13);
            this.lblTokenE1.TabIndex = 35;
            this.lblTokenE1.Text = "Token E1";
            // 
            // txtTokenE1
            // 
            this.txtTokenE1.Location = new System.Drawing.Point(6, 346);
            this.txtTokenE1.Name = "txtTokenE1";
            this.txtTokenE1.Size = new System.Drawing.Size(404, 20);
            this.txtTokenE1.TabIndex = 34;
            this.txtTokenE1.Text = "5F2A8284959A9C9F029F039F099F109F1A9F1E9F269F279F339F349F359F369F379F419F53";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(292, 111);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 13);
            this.label5.TabIndex = 33;
            this.label5.Text = "Currency Index";
            // 
            // txtCurrencyIndex
            // 
            this.txtCurrencyIndex.Location = new System.Drawing.Point(295, 128);
            this.txtCurrencyIndex.MaxLength = 2;
            this.txtCurrencyIndex.Name = "txtCurrencyIndex";
            this.txtCurrencyIndex.Size = new System.Drawing.Size(119, 20);
            this.txtCurrencyIndex.TabIndex = 32;
            this.txtCurrencyIndex.Text = "01";
            // 
            // lblTipUSd
            // 
            this.lblTipUSd.AutoSize = true;
            this.lblTipUSd.Location = new System.Drawing.Point(148, 113);
            this.lblTipUSd.Name = "lblTipUSd";
            this.lblTipUSd.Size = new System.Drawing.Size(48, 13);
            this.lblTipUSd.TabIndex = 31;
            this.lblTipUSd.Text = "Tip USD";
            // 
            // txtTipUSD
            // 
            this.txtTipUSD.Location = new System.Drawing.Point(151, 128);
            this.txtTipUSD.Name = "txtTipUSD";
            this.txtTipUSD.Size = new System.Drawing.Size(119, 20);
            this.txtTipUSD.TabIndex = 30;
            this.txtTipUSD.Text = "0.00";
            // 
            // lblCashbackUSD
            // 
            this.lblCashbackUSD.AutoSize = true;
            this.lblCashbackUSD.Location = new System.Drawing.Point(148, 70);
            this.lblCashbackUSD.Name = "lblCashbackUSD";
            this.lblCashbackUSD.Size = new System.Drawing.Size(55, 13);
            this.lblCashbackUSD.TabIndex = 29;
            this.lblCashbackUSD.Text = "Cashback";
            // 
            // txtCashbackUSD
            // 
            this.txtCashbackUSD.Location = new System.Drawing.Point(151, 85);
            this.txtCashbackUSD.Name = "txtCashbackUSD";
            this.txtCashbackUSD.Size = new System.Drawing.Size(119, 20);
            this.txtCashbackUSD.TabIndex = 28;
            this.txtCashbackUSD.Text = "0.00";
            // 
            // lblMontoUSD
            // 
            this.lblMontoUSD.AutoSize = true;
            this.lblMontoUSD.Location = new System.Drawing.Point(148, 27);
            this.lblMontoUSD.Name = "lblMontoUSD";
            this.lblMontoUSD.Size = new System.Drawing.Size(63, 13);
            this.lblMontoUSD.TabIndex = 27;
            this.lblMontoUSD.Text = "Monto USD";
            // 
            // txtMontoUSD
            // 
            this.txtMontoUSD.Location = new System.Drawing.Point(152, 45);
            this.txtMontoUSD.Name = "txtMontoUSD";
            this.txtMontoUSD.Size = new System.Drawing.Size(119, 20);
            this.txtMontoUSD.TabIndex = 26;
            this.txtMontoUSD.Text = "0.00";
            // 
            // lblTip
            // 
            this.lblTip.AutoSize = true;
            this.lblTip.Location = new System.Drawing.Point(6, 110);
            this.lblTip.Name = "lblTip";
            this.lblTip.Size = new System.Drawing.Size(22, 13);
            this.lblTip.TabIndex = 25;
            this.lblTip.Text = "Tip";
            // 
            // txtTip
            // 
            this.txtTip.Location = new System.Drawing.Point(9, 128);
            this.txtTip.Name = "txtTip";
            this.txtTip.Size = new System.Drawing.Size(119, 20);
            this.txtTip.TabIndex = 24;
            this.txtTip.Text = "0.00";
            // 
            // lblCashback
            // 
            this.lblCashback.AutoSize = true;
            this.lblCashback.Location = new System.Drawing.Point(6, 67);
            this.lblCashback.Name = "lblCashback";
            this.lblCashback.Size = new System.Drawing.Size(55, 13);
            this.lblCashback.TabIndex = 23;
            this.lblCashback.Text = "Cashback";
            // 
            // txtCashback
            // 
            this.txtCashback.Location = new System.Drawing.Point(9, 85);
            this.txtCashback.Name = "txtCashback";
            this.txtCashback.Size = new System.Drawing.Size(119, 20);
            this.txtCashback.TabIndex = 22;
            this.txtCashback.Text = "0.00";
            // 
            // lblVoucher
            // 
            this.lblVoucher.AutoSize = true;
            this.lblVoucher.Location = new System.Drawing.Point(292, 69);
            this.lblVoucher.Name = "lblVoucher";
            this.lblVoucher.Size = new System.Drawing.Size(47, 13);
            this.lblVoucher.TabIndex = 21;
            this.lblVoucher.Text = "Voucher";
            // 
            // txtVoucher
            // 
            this.txtVoucher.Location = new System.Drawing.Point(296, 85);
            this.txtVoucher.MaxLength = 8;
            this.txtVoucher.Name = "txtVoucher";
            this.txtVoucher.Size = new System.Drawing.Size(119, 20);
            this.txtVoucher.TabIndex = 20;
            this.txtVoucher.Text = "12345678";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txtECRId);
            this.groupBox2.Controls.Add(this.btnECRSync);
            this.groupBox2.Location = new System.Drawing.Point(302, 43);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 161);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Sincronización";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 22;
            this.label3.Text = "ECR Id";
            // 
            // txtECRId
            // 
            this.txtECRId.Location = new System.Drawing.Point(17, 33);
            this.txtECRId.Name = "txtECRId";
            this.txtECRId.Size = new System.Drawing.Size(119, 20);
            this.txtECRId.TabIndex = 21;
            this.txtECRId.Text = "0000000001";
            // 
            // btnECRSync
            // 
            this.btnECRSync.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnECRSync.Location = new System.Drawing.Point(17, 109);
            this.btnECRSync.Name = "btnECRSync";
            this.btnECRSync.Size = new System.Drawing.Size(119, 39);
            this.btnECRSync.TabIndex = 20;
            this.btnECRSync.Text = "ECR Sync";
            this.btnECRSync.UseVisualStyleBackColor = true;
            this.btnECRSync.Click += new System.EventHandler(this.Button1_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.lblResponseCode);
            this.groupBox4.Controls.Add(this.lblSerial);
            this.groupBox4.Controls.Add(this.lblSoftwareVersion);
            this.groupBox4.Controls.Add(this.lblVoucherNumber);
            this.groupBox4.Controls.Add(this.lblCurrencyCode);
            this.groupBox4.Controls.Add(this.lblCardType);
            this.groupBox4.Controls.Add(this.lblCard);
            this.groupBox4.Controls.Add(this.lblCardHolderName);
            this.groupBox4.Controls.Add(this.lblAuth);
            this.groupBox4.Controls.Add(this.lblAmountAuthorized);
            this.groupBox4.Controls.Add(this.lblHora);
            this.groupBox4.Controls.Add(this.lblDate);
            this.groupBox4.Controls.Add(this.lblHostResponse);
            this.groupBox4.Controls.Add(this.lblResult);
            this.groupBox4.Location = new System.Drawing.Point(35, 224);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(241, 417);
            this.groupBox4.TabIndex = 23;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Salida";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 408);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 13);
            this.label4.TabIndex = 38;
            // 
            // lblResponseCode
            // 
            this.lblResponseCode.AutoSize = true;
            this.lblResponseCode.Font = new System.Drawing.Font("Open Sans", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResponseCode.Location = new System.Drawing.Point(15, 62);
            this.lblResponseCode.Name = "lblResponseCode";
            this.lblResponseCode.Size = new System.Drawing.Size(84, 15);
            this.lblResponseCode.TabIndex = 37;
            this.lblResponseCode.Text = "ResponseCode";
            // 
            // lblSerial
            // 
            this.lblSerial.AutoSize = true;
            this.lblSerial.Font = new System.Drawing.Font("Open Sans", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSerial.Location = new System.Drawing.Point(18, 384);
            this.lblSerial.Name = "lblSerial";
            this.lblSerial.Size = new System.Drawing.Size(35, 15);
            this.lblSerial.TabIndex = 36;
            this.lblSerial.Text = "Serial";
            // 
            // lblSoftwareVersion
            // 
            this.lblSoftwareVersion.AutoSize = true;
            this.lblSoftwareVersion.Font = new System.Drawing.Font("Open Sans", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoftwareVersion.Location = new System.Drawing.Point(18, 357);
            this.lblSoftwareVersion.Name = "lblSoftwareVersion";
            this.lblSoftwareVersion.Size = new System.Drawing.Size(95, 15);
            this.lblSoftwareVersion.TabIndex = 35;
            this.lblSoftwareVersion.Text = "Software Version";
            // 
            // lblVoucherNumber
            // 
            this.lblVoucherNumber.AutoSize = true;
            this.lblVoucherNumber.Font = new System.Drawing.Font("Open Sans", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVoucherNumber.Location = new System.Drawing.Point(18, 330);
            this.lblVoucherNumber.Name = "lblVoucherNumber";
            this.lblVoucherNumber.Size = new System.Drawing.Size(92, 15);
            this.lblVoucherNumber.TabIndex = 34;
            this.lblVoucherNumber.Text = "VoucherNumber";
            // 
            // lblCurrencyCode
            // 
            this.lblCurrencyCode.AutoSize = true;
            this.lblCurrencyCode.Font = new System.Drawing.Font("Open Sans", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrencyCode.Location = new System.Drawing.Point(18, 304);
            this.lblCurrencyCode.Name = "lblCurrencyCode";
            this.lblCurrencyCode.Size = new System.Drawing.Size(83, 15);
            this.lblCurrencyCode.TabIndex = 33;
            this.lblCurrencyCode.Text = "Currency Code";
            // 
            // lblCardType
            // 
            this.lblCardType.AutoSize = true;
            this.lblCardType.Font = new System.Drawing.Font("Open Sans", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCardType.Location = new System.Drawing.Point(18, 277);
            this.lblCardType.Name = "lblCardType";
            this.lblCardType.Size = new System.Drawing.Size(59, 15);
            this.lblCardType.TabIndex = 32;
            this.lblCardType.Text = "Card Type";
            // 
            // lblCard
            // 
            this.lblCard.AutoSize = true;
            this.lblCard.Font = new System.Drawing.Font("Open Sans", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCard.Location = new System.Drawing.Point(15, 251);
            this.lblCard.Name = "lblCard";
            this.lblCard.Size = new System.Drawing.Size(31, 15);
            this.lblCard.TabIndex = 31;
            this.lblCard.Text = "Card";
            // 
            // lblCardHolderName
            // 
            this.lblCardHolderName.AutoSize = true;
            this.lblCardHolderName.Font = new System.Drawing.Font("Open Sans", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCardHolderName.Location = new System.Drawing.Point(15, 224);
            this.lblCardHolderName.Name = "lblCardHolderName";
            this.lblCardHolderName.Size = new System.Drawing.Size(96, 15);
            this.lblCardHolderName.TabIndex = 30;
            this.lblCardHolderName.Text = "CardHolderName";
            // 
            // lblAuth
            // 
            this.lblAuth.AutoSize = true;
            this.lblAuth.Font = new System.Drawing.Font("Open Sans", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAuth.Location = new System.Drawing.Point(15, 198);
            this.lblAuth.Name = "lblAuth";
            this.lblAuth.Size = new System.Drawing.Size(111, 15);
            this.lblAuth.TabIndex = 29;
            this.lblAuth.Text = "Authorization Code:";
            // 
            // lblAmountAuthorized
            // 
            this.lblAmountAuthorized.AutoSize = true;
            this.lblAmountAuthorized.Font = new System.Drawing.Font("Open Sans", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAmountAuthorized.Location = new System.Drawing.Point(15, 171);
            this.lblAmountAuthorized.Name = "lblAmountAuthorized";
            this.lblAmountAuthorized.Size = new System.Drawing.Size(108, 15);
            this.lblAmountAuthorized.TabIndex = 28;
            this.lblAmountAuthorized.Text = "Monto Autorizado: ";
            // 
            // lblHora
            // 
            this.lblHora.AutoSize = true;
            this.lblHora.Font = new System.Drawing.Font("Open Sans", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHora.Location = new System.Drawing.Point(15, 144);
            this.lblHora.Name = "lblHora";
            this.lblHora.Size = new System.Drawing.Size(35, 15);
            this.lblHora.TabIndex = 27;
            this.lblHora.Text = "Hora:";
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Open Sans", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(15, 117);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(40, 15);
            this.lblDate.TabIndex = 26;
            this.lblDate.Text = "Fecha:";
            // 
            // lblHostResponse
            // 
            this.lblHostResponse.AutoSize = true;
            this.lblHostResponse.Font = new System.Drawing.Font("Open Sans", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHostResponse.Location = new System.Drawing.Point(15, 91);
            this.lblHostResponse.Name = "lblHostResponse";
            this.lblHostResponse.Size = new System.Drawing.Size(87, 15);
            this.lblHostResponse.TabIndex = 25;
            this.lblHostResponse.Text = "Host Response:";
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Font = new System.Drawing.Font("Open Sans", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult.Location = new System.Drawing.Point(15, 35);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(65, 15);
            this.lblResult.TabIndex = 24;
            this.lblResult.Text = "Resultado: ";
            // 
            // btnAnulacion
            // 
            this.btnAnulacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAnulacion.Location = new System.Drawing.Point(652, 475);
            this.btnAnulacion.Name = "btnAnulacion";
            this.btnAnulacion.Size = new System.Drawing.Size(119, 39);
            this.btnAnulacion.TabIndex = 24;
            this.btnAnulacion.Text = "Anulación ";
            this.btnAnulacion.UseVisualStyleBackColor = true;
            this.btnAnulacion.Click += new System.EventHandler(this.BtnAnulacion_Click);
            // 
            // btnbAuth
            // 
            this.btnbAuth.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbAuth.Location = new System.Drawing.Point(777, 475);
            this.btnbAuth.Name = "btnbAuth";
            this.btnbAuth.Size = new System.Drawing.Size(119, 39);
            this.btnbAuth.TabIndex = 25;
            this.btnbAuth.Text = "Autorización";
            this.btnbAuth.UseVisualStyleBackColor = true;
            this.btnbAuth.Click += new System.EventHandler(this.BtnbAuth_Click);
            // 
            // btnPreAuth
            // 
            this.btnPreAuth.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPreAuth.Location = new System.Drawing.Point(527, 522);
            this.btnPreAuth.Name = "btnPreAuth";
            this.btnPreAuth.Size = new System.Drawing.Size(119, 39);
            this.btnPreAuth.TabIndex = 26;
            this.btnPreAuth.Text = "Pre-Autorización";
            this.btnPreAuth.UseVisualStyleBackColor = true;
            this.btnPreAuth.Click += new System.EventHandler(this.BtnPreAuth_Click);
            // 
            // btnPreAuthGas
            // 
            this.btnPreAuthGas.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPreAuthGas.Location = new System.Drawing.Point(777, 521);
            this.btnPreAuthGas.Name = "btnPreAuthGas";
            this.btnPreAuthGas.Size = new System.Drawing.Size(119, 40);
            this.btnPreAuthGas.TabIndex = 27;
            this.btnPreAuthGas.Text = "PreAuth Gas";
            this.btnPreAuthGas.UseVisualStyleBackColor = true;
            this.btnPreAuthGas.Click += new System.EventHandler(this.BtnPreAuthGas_Click);
            // 
            // btnAuthGas
            // 
            this.btnAuthGas.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAuthGas.Location = new System.Drawing.Point(527, 569);
            this.btnAuthGas.Name = "btnAuthGas";
            this.btnAuthGas.Size = new System.Drawing.Size(119, 40);
            this.btnAuthGas.TabIndex = 28;
            this.btnAuthGas.Text = "Comple Gas";
            this.btnAuthGas.UseVisualStyleBackColor = true;
            this.btnAuthGas.Click += new System.EventHandler(this.BtnAuthGas_Click);
            // 
            // btnTopUp
            // 
            this.btnTopUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTopUp.Location = new System.Drawing.Point(652, 569);
            this.btnTopUp.Name = "btnTopUp";
            this.btnTopUp.Size = new System.Drawing.Size(119, 40);
            this.btnTopUp.TabIndex = 29;
            this.btnTopUp.Text = "Top Up";
            this.btnTopUp.UseVisualStyleBackColor = true;
            this.btnTopUp.Click += new System.EventHandler(this.BtnTopUp_Click);
            // 
            // chkIncluirMensaje
            // 
            this.chkIncluirMensaje.AutoSize = true;
            this.chkIncluirMensaje.Checked = true;
            this.chkIncluirMensaje.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkIncluirMensaje.Location = new System.Drawing.Point(108, 188);
            this.chkIncluirMensaje.Name = "chkIncluirMensaje";
            this.chkIncluirMensaje.Size = new System.Drawing.Size(123, 17);
            this.chkIncluirMensaje.TabIndex = 30;
            this.chkIncluirMensaje.Text = "Incluir en el Mensaje";
            this.chkIncluirMensaje.UseVisualStyleBackColor = true;
            this.chkIncluirMensaje.CheckedChanged += new System.EventHandler(this.ChkIncluirMensaje_CheckedChanged);
            // 
            // btnStoreBin
            // 
            this.btnStoreBin.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStoreBin.Location = new System.Drawing.Point(652, 615);
            this.btnStoreBin.Name = "btnStoreBin";
            this.btnStoreBin.Size = new System.Drawing.Size(119, 40);
            this.btnStoreBin.TabIndex = 31;
            this.btnStoreBin.Text = "Store Bin";
            this.btnStoreBin.UseVisualStyleBackColor = true;
            this.btnStoreBin.Click += new System.EventHandler(this.Button1_Click_1);
            // 
            // btnCancelServices
            // 
            this.btnCancelServices.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelServices.Location = new System.Drawing.Point(780, 569);
            this.btnCancelServices.Name = "btnCancelServices";
            this.btnCancelServices.Size = new System.Drawing.Size(119, 40);
            this.btnCancelServices.TabIndex = 32;
            this.btnCancelServices.Text = "Cancel 72";
            this.btnCancelServices.UseVisualStyleBackColor = true;
            this.btnCancelServices.Click += new System.EventHandler(this.BtnCancelServices_Click);
            // 
            // btnDisplayText
            // 
            this.btnDisplayText.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisplayText.Location = new System.Drawing.Point(527, 615);
            this.btnDisplayText.Name = "btnDisplayText";
            this.btnDisplayText.Size = new System.Drawing.Size(119, 40);
            this.btnDisplayText.TabIndex = 33;
            this.btnDisplayText.Text = "Display";
            this.btnDisplayText.UseVisualStyleBackColor = true;
            this.btnDisplayText.Click += new System.EventHandler(this.BtnDisplayText_Click);
            // 
            // btnLlave
            // 
            this.btnLlave.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLlave.Location = new System.Drawing.Point(780, 615);
            this.btnLlave.Name = "btnLlave";
            this.btnLlave.Size = new System.Drawing.Size(119, 40);
            this.btnLlave.TabIndex = 34;
            this.btnLlave.Text = "Llaves";
            this.btnLlave.UseVisualStyleBackColor = true;
            this.btnLlave.Click += new System.EventHandler(this.BtnLlave_Click);
            // 
            // btnCorresponsal
            // 
            this.btnCorresponsal.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCorresponsal.Location = new System.Drawing.Point(527, 661);
            this.btnCorresponsal.Name = "btnCorresponsal";
            this.btnCorresponsal.Size = new System.Drawing.Size(119, 40);
            this.btnCorresponsal.TabIndex = 35;
            this.btnCorresponsal.Text = "Corresponsal";
            this.btnCorresponsal.UseVisualStyleBackColor = true;
            this.btnCorresponsal.Click += new System.EventHandler(this.Button1_Click_2);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1018, 802);
            this.Controls.Add(this.btnCorresponsal);
            this.Controls.Add(this.btnLlave);
            this.Controls.Add(this.btnDisplayText);
            this.Controls.Add(this.btnCancelServices);
            this.Controls.Add(this.btnStoreBin);
            this.Controls.Add(this.chkIncluirMensaje);
            this.Controls.Add(this.btnTopUp);
            this.Controls.Add(this.btnAuthGas);
            this.Controls.Add(this.btnPreAuthGas);
            this.Controls.Add(this.btnPreAuth);
            this.Controls.Add(this.btnCierre);
            this.Controls.Add(this.btnbAuth);
            this.Controls.Add(this.btnAnulacion);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnVenta);
            this.Controls.Add(this.txtTimeout);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblParity);
            this.Controls.Add(this.ddlParity);
            this.Controls.Add(this.lblDatabits);
            this.Controls.Add(this.ddlDatabits);
            this.Controls.Add(this.lblStopBits);
            this.Controls.Add(this.ddlStopbits);
            this.Controls.Add(this.lblBaudrate);
            this.Controls.Add(this.ddlBaudrate);
            this.Controls.Add(this.lblComPorts);
            this.Controls.Add(this.btnRefreshComPorts);
            this.Controls.Add(this.ddlComPorts);
            this.Name = "frmMain";
            this.Text = "Veriphone Lib Demo";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox ddlComPorts;
        private System.Windows.Forms.Button btnRefreshComPorts;
        private System.Windows.Forms.Label lblComPorts;
        private System.Windows.Forms.Label lblBaudrate;
        private System.Windows.Forms.ComboBox ddlBaudrate;
        private System.Windows.Forms.Label lblStopBits;
        private System.Windows.Forms.ComboBox ddlStopbits;
        private System.Windows.Forms.Label lblDatabits;
        private System.Windows.Forms.ComboBox ddlDatabits;
        private System.Windows.Forms.Label lblParity;
        private System.Windows.Forms.ComboBox ddlParity;
        private System.Windows.Forms.Button btnVenta;
        private System.Windows.Forms.TextBox txtMonto;
        private System.Windows.Forms.Label lblMonto;
        private System.Windows.Forms.Button btnCierre;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTimeout;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSerial;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtECRId;
        private System.Windows.Forms.Button btnECRSync;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Label lblHostResponse;
        private System.Windows.Forms.Label lblHora;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblCard;
        private System.Windows.Forms.Label lblCardHolderName;
        private System.Windows.Forms.Label lblAuth;
        private System.Windows.Forms.Label lblAmountAuthorized;
        private System.Windows.Forms.Label lblSoftwareVersion;
        private System.Windows.Forms.Label lblVoucherNumber;
        private System.Windows.Forms.Label lblCurrencyCode;
        private System.Windows.Forms.Label lblCardType;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblResponseCode;
        private System.Windows.Forms.Label lblSerial;
        private System.Windows.Forms.Label lblVoucher;
        private System.Windows.Forms.TextBox txtVoucher;
        private System.Windows.Forms.Label lblTipUSd;
        private System.Windows.Forms.TextBox txtTipUSD;
        private System.Windows.Forms.Label lblCashbackUSD;
        private System.Windows.Forms.TextBox txtCashbackUSD;
        private System.Windows.Forms.Label lblMontoUSD;
        private System.Windows.Forms.TextBox txtMontoUSD;
        private System.Windows.Forms.Label lblTip;
        private System.Windows.Forms.TextBox txtTip;
        private System.Windows.Forms.Label lblCashback;
        private System.Windows.Forms.TextBox txtCashback;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtCurrencyIndex;
        private System.Windows.Forms.Button btnAnulacion;
        private System.Windows.Forms.Button btnbAuth;
        private System.Windows.Forms.Label lblTokenE1;
        private System.Windows.Forms.TextBox txtTokenE1;
        private System.Windows.Forms.Button btnPreAuth;
        private System.Windows.Forms.Button btnPreAuthGas;
        private System.Windows.Forms.Button btnAuthGas;
        private System.Windows.Forms.Button btnTopUp;
        private System.Windows.Forms.CheckBox chkIncluirMensaje;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtCurrencyCode;
        private System.Windows.Forms.CheckBox chkEnmascarar;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtAutorizado;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtIssuerAuth;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtResponseCode;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtE2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtTransactionType;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtBinTableId;
        private System.Windows.Forms.Button btnStoreBin;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtDisplayText;
        private System.Windows.Forms.Button btnCancelServices;
        private System.Windows.Forms.Button btnDisplayText;
        private System.Windows.Forms.Button btnLlave;
        private System.Windows.Forms.Button btnCorresponsal;
    }
}

