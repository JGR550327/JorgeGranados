﻿using ECR_Veriphone_Lib;
using ECR_Veriphone_Lib.core;
using ECR_Veriphone_Lib.util;
using log4net;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ECR_Veriphone_Demo
{
    public partial class frmMain : Form
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(frmMain));

        public frmMain()
        {
            InitializeComponent ();
            Utilidad.Init       ();
        }


        public byte[] getTag(byte[] response, ref int index) 
        {
           
            //----------------------
            // tag c1, e1, e2, etc
            //----------------------
            byte[] temp = new byte[1];

            Array.Copy(response, index, temp, 0, temp.Length);

            log.Info("Tag " + ASCIIEncoding.ASCII.GetString(temp));

            index += temp.Length;
          

            //----------------------
            // tag length
            //----------------------

            int tagLen = response[index];

            log.Info("Length: " + tagLen.ToString());

            index += 1;
           
            //----------------------
            // tag value
            //----------------------
            temp = new byte[tagLen];

            Array.Copy(response, index, temp, 0, temp.Length);

            log.Info("Value BCD     " + Utilidad.Bcd2Str(temp));
            log.Info("Value ASCII   " + ASCIIEncoding.ASCII.GetString(temp));

            index += temp.Length;

            return temp;
        }

        public TransactionResult ParseResponse(byte[] response)
        {
            TransactionResult result = new TransactionResult();

            int index = 0;

            log.Info("--------------------------------");
            log.Info("ParseResponse");
            log.Info("--------------------------------");

            try
            {


                //--------------------------------
                // Message Identifier 3 bytes ASCII
                //--------------------------------
                byte[] temp = new byte[3];
                System.Array.Copy(response, index, temp, 0, temp.Length);

                log.Info("Identifier BCD    : [" + Utilidad.Bcd2Str(temp) + "]");

                result.Identifier = ASCIIEncoding.ASCII.GetString(temp);

                log.Info("Identifier ASCII  : [" + result.Identifier + "]");

                index += temp.Length;

                //--------------------------------
                // Result 2 bytes ASCII
                //--------------------------------
                temp = new byte[2];
                System.Array.Copy(response, index, temp, 0, temp.Length);

                log.Info("Operation Result    : [" + Utilidad.Bcd2Str(temp) + "]");

                int iResult = 0;

                if (Int32.TryParse(ASCIIEncoding.ASCII.GetString(temp), out iResult))
                {
                    result.Result = (OperationResult)iResult;
                }

                index += temp.Length;


                //--------------------------------
                // Longitud 2 bytes HEX
                //--------------------------------
                temp = new byte[2];
                Array.Copy(response, index, temp, 0, temp.Length);

                log.Info("Len HEX    : [" + Utilidad.Bcd2Str(temp) + "]");

                index += temp.Length;

                int longitudTotal = Convert.ToInt32(Utilidad.Bcd2Str(temp), 16);


                //--------------------------------
                // C1 - Host Response Code ASCII
                //--------------------------------

                temp = getTag(response, ref index);

                if (null != temp)
                {
                    result.HostResponse = Utilidad.Bcd2Str(temp);
                }

                //--------------------------------
                // C1 - Authorization Code ASCII
                //--------------------------------

                temp = getTag(response, ref index);

                if (null != temp)
                {
                    result.AuthorizationCode = ASCIIEncoding.ASCII.GetString(temp);
                }

                //--------------------------------
                // C1 - Response Code ASCII
                //--------------------------------

                temp = getTag(response, ref index);

                if (null != temp)
                {
                    result.ResponseCode = ASCIIEncoding.ASCII.GetString(temp);
                }

                //--------------------------------
                // C1 - Transaction Date BCD
                //--------------------------------

                temp = getTag(response, ref index);

                if (null != temp)
                {
                    result.TransactionDate = Utilidad.Bcd2Str(temp);
                }

                //--------------------------------
                // C1 - Transaction Time BCD
                //--------------------------------

                temp = getTag(response, ref index);

                if (null != temp)
                {
                    result.TransactionTime = Utilidad.Bcd2Str(temp);
                }

                //--------------------------------
                // C1 - CardNumber BCD
                //--------------------------------

                temp = getTag(response, ref index);

                if (null != temp)
                {
                    result.CardNumber = Utilidad.Bcd2Str(temp);
                }

                //--------------------------------
                // C1 - CardHolderName ASCII
                //--------------------------------

                temp = getTag(response, ref index);

                if (null != temp)
                {
                    result.CardHolderName = ASCIIEncoding.ASCII.GetString(temp);
                }


                //--------------------------------
                // C1 - CardEntryMode ASCII
                //--------------------------------

                temp = getTag(response, ref index);

                if (null != temp && temp.Length > 0)
                {
                    int entryMode = Convert.ToInt32(ASCIIEncoding.ASCII.GetString(temp));
                    result.EntryMode = (CardEntryMode)entryMode;
                }

                //--------------------------------
                // C1 - Voucher  ASCII
                //--------------------------------

                temp = getTag(response, ref index);

                if (null != temp)
                {
                    result.VoucherNumber = Utilidad.Bcd2Str(temp);
                }

                //--------------------------------
                // C1 - CardType  ASCII
                //--------------------------------

                temp = getTag(response, ref index);

                if (null != temp && temp.Length > 0)
                {
                    int cType = Convert.ToInt32(ASCIIEncoding.ASCII.GetString(temp));
                    result.CardType = (CardType)cType;
                }

                //--------------------------------
                // C1 - CurrencyCode  BCD
                //--------------------------------

                temp = getTag(response, ref index);

                if (null != temp)
                {
                    result.CurrencyCode = Utilidad.Bcd2Str(temp);
                }

                //--------------------------------
                // C1 - Amount  BCD
                //--------------------------------

                temp = getTag(response, ref index);

                if (null != temp)
                {
                    result.AmountAuthorized = Utilidad.Bcd2Str(temp);
                }

                //--------------------------------
                // C1 - Software Verson  ASCII
                //--------------------------------

                temp = getTag(response, ref index);

                if (null != temp)
                {
                    result.SoftwareVersion = ASCIIEncoding.ASCII.GetString(temp);
                }

                //--------------------------------
                // C1 - Serial  ASCII
                //--------------------------------

                temp = getTag(response, ref index);

                if (null != temp)
                {
                    result.SerialNumber = ASCIIEncoding.ASCII.GetString(temp);
                }

                //--------------------------------
                // C1 - ECR + POS SERIAL ASCII
                //--------------------------------

                temp = getTag(response, ref index);

                if (null != temp)
                {
                    result.ECR_ID_SERIAL = ASCIIEncoding.ASCII.GetString(temp);
                }

                //--------------------------------
                // E1 - EMV BCD
                //--------------------------------

                temp = getTag(response, ref index);

                if (null != temp && temp.Length > 0)
                {
                    result.E1 = temp;
                }

                //--------------------------------
                // E2 - EMV BCD
                //--------------------------------

                temp = getTag(response, ref index);

                if (null != temp && temp.Length > 0)
                {
                    result.E2 = temp;
                }

            }
            catch (Exception ex)
            {
                log.Error(ex);
                return result;
            }
            /*
            *done dynamically
            * 
            int innerIndex = 0;

            while (true)
            {

                if (innerIndex == longitudTotal)
                {
                    break;
                }

                if (response.Length > index)
                {
                   //----------------------
                   // tag c1, e1, e2, etc
                   //----------------------
                   temp = new byte[1];

                   Array.Copy(response, index, temp, 0, temp.Length);

                   log.Info("Tag " + ASCIIEncoding.ASCII.GetString(temp));

                   index       += temp.Length;
                   innerIndex  += temp.Length;

                   //----------------------
                   // tag length
                   //----------------------

                   int tagLen = response[index];

                   log.Info("Length: " + tagLen.ToString());

                   index       += 1;
                   innerIndex  += 1;
                   //----------------------
                   // tag value
                   //----------------------
                    temp = new byte[tagLen];

                    Array.Copy(response, index, temp, 0, temp.Length);

                    log.Info("Value BCD     " + Utilidad.Bcd2Str(temp));
                    log.Info("Value ASCII   " + ASCIIEncoding.ASCII.GetString(temp));

                    index       += temp.Length;
                    innerIndex  += temp.Length;
                }
               

            }*/

            return result;
        }




        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "Veriphone Lib Demo " + AppVersion.GetVersion() + " - " + AppVersion.GetRevision();

            String response = "C14!ET00366APLINETC08002011A2B3F7210000030320002416601ACA0CD33C4C629E824EAD50CF5277CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E434BA63AB03";

            byte[] bResponse =
                                       ASCIIEncoding.ASCII.GetBytes(response)
                                       ;
                                                

            String response2 = "43313421204554303033363620413435393939333230313030323031303030303832363131303030303143303332303030393337463245383646333141324345333939373844383644443841373432394438324243414137374141324646393442454335353538303943423145313138454241343639343045373645464643333834354236413837394346374642344433354446344430423041333739373336313436463444304230413337393733363134364634443042304133373937333631343646344430423041333739373336313436463444304230413337393733363134364634443042304133373937333631343646344430423041333739373336313436463444304230413337393733363134364634443042304133373937333631343646344430423041333739373336313436463444304230413337393733363134364634443042304133373937333631343646344430423041333739373336313436463444304230413337393733363134363236353738334545";

            byte[] bResponse2 = Utilidad.ASCII_To_BCD(
                                                    ASCIIEncoding.ASCII.GetBytes(response2)
                                                );

            byte[] lcr1 = Utilidad.CalculateLCR(bResponse);

            byte[] lcr2 = Utilidad.CalculateLCR(bResponse2);
            /*

            String response     = "4335343038006BC10197C100C100C103210505C103143929C100C100C100C10400000000C100C1020532C100C114563532305F30365F303220202020202020202020C1145658383230202020202020202020202020202020C1140031303530350000565830333331333734353037E100E200";
            String responseC53  = "433533303001DEC1084152312A2A2A8721C11A2020202020202020202020202020202020202020202020202020C100C100C100C1023035E15C4F07A00000000320109F120D42414E434F4D45522056495341500D5649534120454C454354524F4E5F300200005F3401019F3403010302C20100950580800088009F2701809F260885BAE0E5FE815F859B0268009F3901058A009900E2885F2A02048482021C008407A0000000032010950580800088009A032106149C01009F02060000000001009F03060000000000009F0902008C9F100706010A03A4B0009F1A0204849F1E0835343137313832379F260885BAE0E5FE815F859F2701809F3303E0B0C89F34030103029F3501229F360200029F3704F40E83DC9F4104000000069F530152212045533030303630205646503230307630385F3139202020202020202020202020202020202056463534313731383237333530303030303030303030303030303030303030212052313030303030202120455A303030393820303032303130303030363946453130303030303730303030303036303031303533374130303036343431374146324231333130304437384337323933303445314232353335453132383930363344453733354245323838373231423331463941434521204559303030303020";

            byte[] bResponse =  Utilidad.ASCII_To_BCD   ( 
                                                            ASCIIEncoding.ASCII.GetBytes(response) 
                                                        );


            byte[] bResponseC53 = Utilidad.ASCII_To_BCD(
                                                           ASCIIEncoding.ASCII.GetBytes(responseC53)
                                                       );

            TransactionResult result = ParseResponse(bResponse);

            TransactionCore core = new TransactionCore();
            
            TransactionResult resultC53 = core.ParseResponseC53(bResponseC53);


            if (null != result) 
            {
                log.Info (result.ToString());
            }
            */

            //----------------------------------------------------
            // Obt'en los puertos seriales
            //----------------------------------------------------
            GetSerialPorts  (       );

        }

     

        /// <summary>
        /// Obtiene todos los puertos diponibles 
        /// </summary>
        private     void        GetSerialPorts              (                                )
        {
            ddlComPorts.Items.Clear();
            
            foreach (String comport in SerialPort.GetPortNames())
            {
                ddlComPorts.Items.Add(comport);
            }
        }

        #region "Eventos"
        
        private     void        BtnRefreshComPorts_Click    (       object sender, EventArgs e  )
        {
            
            GetSerialPorts  ( );
        }



   


        #endregion

        public      string      FormatAmount                (       String amount               ) 
        {
            amount = amount.Replace(",", "").Replace(".", "");

            amount = Utilidad.FillStringWith(amount, '0', 8, true);

            return amount;

        }


        public bool ValidateAmount(String strAmount, out String formattedAmount)
        {
            long lMonto = 0;

            formattedAmount = "";

            if (null == strAmount) 
            {   
                return false;
            }

            if (strAmount.Length == 0)
            {
                MessageBox.Show("Digite un valor para el monto");
                return false;

            }

            formattedAmount = strAmount.Replace(",", "").Replace(".", "");

            if (!long.TryParse(formattedAmount, out lMonto))
            {
                MessageBox.Show("Digite un valor numérico para el monto");
                return false;
            }

            return true;
        }


        /// <summary>
        /// Transacción para realizar una venta 
        /// </summary>
        public  void            performTransaction          (   TransactionType trxType     ) 
        {

            long                lMonto                  = 0     ;
            String              strMonto                = ""    ;
            int                 timeout                 = 0     ;
            String              strCashback             = ""    ;
            String              strTip                  = ""    ;
            String              strMontoUSD             = ""    ;
            String              strCashbackUSD          = ""    ;
            String              strTipUSD               = ""    ;


            Transaction_RS232   transaction = null  ;

            //----------------------------
            // validaciones
            //----------------------------
            {
                //---------------------------------------------------------------------
                // validacion de montos
                //---------------------------------------------------------------------
                strMonto = txtMonto.Text.Trim();

                if (strMonto.Length == 0)
                {
                    MessageBox.Show("Digite un valor para el monto");
                    return;

                }

                strMonto = strMonto.Replace(",", "").Replace(".", "");

                if (!long.TryParse(strMonto, out lMonto))
                {
                    MessageBox.Show("Digite un valor numérico para el monto");
                    return;
                }

                if (!ValidateAmount(txtCashback.Text, out strCashback)) 
                {
                    MessageBox.Show("Digite un valor numérico para el cashback");
                    return;
                }

                if (!ValidateAmount(txtTip.Text, out strTip))
                {
                    MessageBox.Show("Digite un valor numérico para la propina");
                    return;
                }

                if (!ValidateAmount(txtMontoUSD.Text, out strMontoUSD))
                {
                    MessageBox.Show("Digite un valor numérico para el monto USD");
                    return;
                }

                if (!ValidateAmount(txtCashbackUSD.Text, out strCashbackUSD))
                {
                    MessageBox.Show("Digite un valor numérico para el cashback USD");
                    return;
                }

                if (!ValidateAmount(txtTipUSD.Text, out strTipUSD))
                {
                    MessageBox.Show("Digite un valor numérico para la propina USD");
                    return;
                }


                //---------------------------------------------------------------------
                // validacion datos com
                //---------------------------------------------------------------------

                if (ddlBaudrate.Text == "")
                {
                    MessageBox.Show("BaudRate está vacío");
                    return;
                }

                if (ddlComPorts.Text == "")
                {
                    MessageBox.Show("Puerto COMM está vacío");
                    return;
                }

                if (ddlDatabits.Text == "")
                {
                    MessageBox.Show("DataBits está vacío");
                    return;
                }

                if (ddlParity.Text == "")
                {
                    MessageBox.Show("Paridad está vacío");
                    return;
                }

                if (ddlStopbits.Text == "")
                {
                    MessageBox.Show("StopBits está vacío");
                    return;
                }

                if (!Int32.TryParse(txtTimeout.Text.Trim(), out timeout))
                {
                    MessageBox.Show("Número de Tiempo de espera inválido");
                    return;
                }
            }

            //---------------------------------------------------------------------
            // Core Transaction
            //---------------------------------------------------------------------

            transaction = new Transaction_RS232();

            transaction.Baudrate        = ddlBaudrate   .Text   ;
            transaction.ComPort         = ddlComPorts   .Text   ;
            transaction.DataBits        = ddlDatabits   .Text   ;
            transaction.StopBits        = ddlStopbits   .Text   ;
            transaction.Parity          = ddlParity     .Text   ;
            transaction.Timeout         = timeout               ;
            transaction.IncluirTimeout  = chkIncluirMensaje.Checked;
            DateTime    rigth_now   = DateTime.Now              ;   

            
            transaction.setTransactionDate      (   rigth_now.ToString("yyMMdd")        );
            transaction.setTransactionTime      (   rigth_now.ToString("hhmmss")        );
            transaction.setVoucherNumber        (   txtVoucher.Text                     );
        
            transaction.setAmount               (   FormatAmount(   strMonto        )       );
            transaction.setCashback_Amount      (   FormatAmount(   strCashback     )       );
            transaction.setTip_Amount           (   FormatAmount(   strTip          )       );

            transaction.setAmount_USD           (   FormatAmount(   strMontoUSD     )       );
            transaction.setCashback_Amount_USD  (   FormatAmount(   strCashbackUSD  )       );
            transaction.setTip_Amount_USD       (   FormatAmount(   strTipUSD       )       );


            transaction.setTransactionType      (   trxType                             );

            transaction.setCurrencyIndex        (   txtCurrencyIndex.Text               );
            transaction.setCurrencyCode         (   txtCurrencyCode.Text                );

            transaction.EnmascararPAN   = chkEnmascarar.Checked;

            String ecr_id = txtECRId.Text;  // "0000000001";

            String pos_sn = txtSerial.Text; // "0331374507";

            transaction.setECR_ID_SERIAL                            (   ecr_id + pos_sn     )   ; 

            transaction.setEmvTags                                  (   txtTokenE1.Text     )   ;

            if (trxType == TransactionType.SETTLEMENT) 
            {
                transaction.setEmvTags("");
            }
            
            transaction.setECRId                                    (   ecr_id                      )   ;

            transaction.setTransactionType                          (   trxType                     )   ;

            transaction.setAuthorizationCode                        (   "000000"                    )   ;

            //-----------------------------------------------------------------------------
            // Request BIN
            //-----------------------------------------------------------------------------

            TransactionResult trxResult = null;
            /*
            if (trxType == TransactionType.SALE) 
            {
                trxResult = transaction.RequestBIN();

                showResponse    (   trxResult);
            }
            */

            transaction.SendACK = true; 

            trxResult = transaction.Authorization ( Instructions.C51_Authorization );

            showResponse(trxResult);

            //

            if (null != trxResult && trxResult.Result == OperationResult.Sucess)
            {
                transaction.setResponseCode             (   txtResponseCode.Text);
                transaction.setAuthorizationCode        (   txtAutorizado.Text  );
                transaction.setIssuerAuthenticationData (   txtIssuerAuth.Text  );

                rigth_now = DateTime.Now;

                transaction.setTransactionDate          (   rigth_now.ToString("yyMMdd"));
                transaction.setTransactionTime          (   rigth_now.ToString("hhmmss"));
                transaction.setE2                       (   txtE2.Text);


                TransactionResult trxResultFinish = transaction.FinishAuthorization();
            }

            transaction.CloseChannel                                (                               )   ;
            
           

        }

        /// <summary>
        /// Transacción para realizar una venta 
        /// </summary>
        public void performTransaction                      (   byte            trxType         )
        {

            long lMonto = 0;
            String strMonto = "";
            int timeout = 0;
            String strCashback = "";
            String strTip = "";
            String strMontoUSD = "";
            String strCashbackUSD = "";
            String strTipUSD = "";


            Transaction_RS232 transaction = null;

            //----------------------------
            // validaciones
            //----------------------------
            {
                //---------------------------------------------------------------------
                // validacion de montos
                //---------------------------------------------------------------------
                strMonto = txtMonto.Text.Trim();

                if (strMonto.Length == 0)
                {
                    MessageBox.Show("Digite un valor para el monto");
                    return;

                }

                strMonto = strMonto.Replace(",", "").Replace(".", "");

                if (!long.TryParse(strMonto, out lMonto))
                {
                    MessageBox.Show("Digite un valor numérico para el monto");
                    return;
                }

                if (!ValidateAmount(txtCashback.Text, out strCashback))
                {
                    MessageBox.Show("Digite un valor numérico para el cashback");
                    return;
                }

                if (!ValidateAmount(txtTip.Text, out strTip))
                {
                    MessageBox.Show("Digite un valor numérico para la propina");
                    return;
                }

                if (!ValidateAmount(txtMontoUSD.Text, out strMontoUSD))
                {
                    MessageBox.Show("Digite un valor numérico para el monto USD");
                    return;
                }

                if (!ValidateAmount(txtCashbackUSD.Text, out strCashbackUSD))
                {
                    MessageBox.Show("Digite un valor numérico para el cashback USD");
                    return;
                }

                if (!ValidateAmount(txtTipUSD.Text, out strTipUSD))
                {
                    MessageBox.Show("Digite un valor numérico para la propina USD");
                    return;
                }


                //---------------------------------------------------------------------
                // validacion datos com
                //---------------------------------------------------------------------

                if (ddlBaudrate.Text == "")
                {
                    MessageBox.Show("BaudRate está vacío");
                    return;
                }

                if (ddlComPorts.Text == "")
                {
                    MessageBox.Show("Puerto COMM está vacío");
                    return;
                }

                if (ddlDatabits.Text == "")
                {
                    MessageBox.Show("DataBits está vacío");
                    return;
                }

                if (ddlParity.Text == "")
                {
                    MessageBox.Show("Paridad está vacío");
                    return;
                }

                if (ddlStopbits.Text == "")
                {
                    MessageBox.Show("StopBits está vacío");
                    return;
                }

                if (!Int32.TryParse(txtTimeout.Text.Trim(), out timeout))
                {
                    MessageBox.Show("Número de Tiempo de espera inválido");
                    return;
                }
            }

            //---------------------------------------------------------------------
            // Core Transaction
            //---------------------------------------------------------------------

            transaction = new Transaction_RS232();

            transaction.Baudrate = ddlBaudrate.Text;
            transaction.ComPort = ddlComPorts.Text;
            transaction.DataBits = ddlDatabits.Text;
            transaction.StopBits = ddlStopbits.Text;
            transaction.Parity = ddlParity.Text;
            transaction.Timeout = timeout;
            transaction.IncluirTimeout = chkIncluirMensaje.Checked;
            DateTime rigth_now = DateTime.Now;


            transaction.setTransactionDate(rigth_now.ToString("yyMMdd"));
            transaction.setTransactionTime(rigth_now.ToString("hhmmss"));
            transaction.setVoucherNumber(txtVoucher.Text);

            transaction.setAmount(FormatAmount(strMonto));
            transaction.setCashback_Amount(FormatAmount(strCashback));
            transaction.setTip_Amount(FormatAmount(strTip));

            transaction.setAmount_USD(FormatAmount(strMontoUSD));
            transaction.setCashback_Amount_USD(FormatAmount(strCashbackUSD));
            transaction.setTip_Amount_USD(FormatAmount(strTipUSD));


            transaction.setTransactionType(trxType);

            transaction.setCurrencyIndex(txtCurrencyIndex.Text);
            transaction.setCurrencyCode(txtCurrencyCode.Text);

            transaction.EnmascararPAN = chkEnmascarar.Checked;

            String ecr_id = txtECRId.Text;  // "0000000001";

            String pos_sn = txtSerial.Text; // "0331374507";

            transaction.setECR_ID_SERIAL(ecr_id + pos_sn);

            transaction.setEmvTags(txtTokenE1.Text);

            transaction.setECRId(ecr_id);

            transaction.setTransactionType(trxType);

            transaction.setAuthorizationCode("000000");

            //-----------------------------------------------------------------------------
            // Request BIN
            //-----------------------------------------------------------------------------

            TransactionResult trxResult = null;
            /*
            if (trxType == TransactionType.SALE) 
            {
                trxResult = transaction.RequestBIN();

                showResponse    (   trxResult);
            }
            */

            transaction.SendACK = true;

            trxResult = transaction.Authorization(Instructions.C51_Authorization);

            showResponse(trxResult);

            //

            if  (null != trxResult && 
                (trxResult.Result == OperationResult.Sucess || trxResult.Result == OperationResult.Contactless)
                )
            {
                transaction.setResponseCode(txtResponseCode.Text);
                transaction.setAuthorizationCode(txtAutorizado.Text);
                transaction.setIssuerAuthenticationData(txtIssuerAuth.Text);

                rigth_now = DateTime.Now;

                transaction.setTransactionDate(rigth_now.ToString("yyMMdd"));
                transaction.setTransactionTime(rigth_now.ToString("hhmmss"));
                transaction.setE2(txtE2.Text);


                TransactionResult trxResultFinish = transaction.FinishAuthorization();
            }

            transaction.CloseChannel();



        }



        public void performSyncronization()
        {

    
            int                 timeout         = 0     ;

            Transaction_RS232   transaction     = null  ;

            
            //---------------------------------------------------------------------
            // validacion datos com
            //---------------------------------------------------------------------

            if (ddlBaudrate.Text == "")
            {
                MessageBox.Show("BaudRate está vacío");
                return;
            }

            if (ddlComPorts.Text == "")
            {
                MessageBox.Show("Puerto COMM está vacío");
                return;
            }

            if (ddlDatabits.Text == "")
            {
                MessageBox.Show("DataBits está vacío");
                return;
            }

            if (ddlParity.Text == "")
            {
                MessageBox.Show("Paridad está vacío");
                return;
            }

            if (ddlStopbits.Text == "")
            {
                MessageBox.Show("StopBits está vacío");
                return;
            }

            if (!Int32.TryParse(txtTimeout.Text.Trim(), out timeout))
            {
                MessageBox.Show("Número de Tiempo de espera inválido");
                return;
            }

            //---------------------------------------------------------------------
            // Core Transaction
            //---------------------------------------------------------------------

            transaction = new Transaction_RS232();

            transaction.Baudrate    = ddlBaudrate.Text  ;
            transaction.ComPort     = ddlComPorts.Text  ;
            transaction.DataBits    = ddlDatabits.Text  ;
            transaction.StopBits    = ddlStopbits.Text  ;
            transaction.Parity      = ddlParity.Text    ;
            transaction.Timeout     = timeout           ;
            DateTime rigth_now      = DateTime.Now      ;

 
            transaction.setTransactionDate(rigth_now.ToString("yyMMdd"));
            transaction.setTransactionTime(rigth_now.ToString("hhmmss"));
  
            String ecr_id = txtECRId.Text;

            if (ecr_id.Length == 0) 
            {
                ecr_id = "0000000000";
            }

            transaction.setECRId            (   ecr_id      );

            TransactionResult resultSync = 
                transaction.Syncronization  (               );

            transaction.CloseChannel        (               );

            showResponse                    (   resultSync  );
            
        }


        public void showResponse(TransactionResult trxResult)
        {
            if (null != trxResult)
            {
                lblResult           .Text = String.Format("Resultado            = {0}", trxResult.Result            );
                lblHostResponse     .Text = String.Format("Host Response        = {0}", trxResult.HostResponse      );
                lblDate             .Text = String.Format("Date                 = {0}", trxResult.TransactionDate   );
                lblHora             .Text = String.Format("Time                 = {0}", trxResult.TransactionTime   );

                lblAmountAuthorized .Text = String.Format("Amount Authorized    = {0}", trxResult.AmountAuthorized  );
                lblAuth             .Text = String.Format("Authorization Code   = {0}", trxResult.AuthorizationCode );
                lblCardHolderName   .Text = String.Format("CardHolderName       = {0}", trxResult.CardHolderName    );
                lblCard             .Text = String.Format("CardNumber           = {0}", trxResult.CardNumber        );

                lblCardType         .Text = String.Format("CardType             = {0}",  trxResult.CardType.ToString());
                lblCurrencyCode     .Text = String.Format("Currency Code        = {0}", trxResult.CurrencyCode      );
                lblVoucherNumber    .Text = String.Format("VoucherNumber        = {0}", trxResult.VoucherNumber     );
                lblSoftwareVersion  .Text = String.Format("SoftwareVersion      = {0}", trxResult.SoftwareVersion   );


                lblSerial           .Text = String.Format("SerialNumber         = {0}", trxResult.SerialNumber      );
                lblResponseCode     .Text = String.Format("Response Code        = {0}", trxResult.ResponseCode      );
         


            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            performSyncronization();
        }

        private void GroupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void BtnVenta_Click(object sender, EventArgs e)
        {
            //PerformTransaction  ( TransactionType.CLSS                  );

            byte[] trxType =  Utilidad.ASCII_To_BCD(ASCIIEncoding.ASCII.GetBytes(txtTransactionType.Text));

            performTransaction( trxType[0] );
        }

        private void BtnAnulacion_Click(object sender, EventArgs e)
        {
            performTransaction  (   TransactionType.VOID                );
        }

        private void BtnbAuth_Click(object sender, EventArgs e)
        {
            performTransaction  (   TransactionType.AUTHORIZATION       );
        }

        private void BtnCierre_Click(object sender, EventArgs e)
        {
            performTransaction  (   TransactionType.SETTLEMENT          );
        }

        private void BtnPreAuth_Click(object sender, EventArgs e)
        {
            performTransaction  (   TransactionType.PRE_AUTHORIZATION   );
        }

        private void BtnPreAuthGas_Click(object sender, EventArgs e)
        {
            performTransaction  (   TransactionType.PREAUTH_GAS         );
        }

        private void BtnAuthGas_Click(object sender, EventArgs e)
        {
            performTransaction  (   TransactionType.COMPLETION_GAS      );
        }

        private void BtnTopUp_Click(object sender, EventArgs e)
        {
            performTransaction  (   TransactionType.TOP_UP_AUTH         );
        }


        public void storeBinTableId(String binTableId)
        {
            Transaction_RS232 transaction = null;

            int timeout = 0;
            //----------------------------
            // validaciones
            //----------------------------
            {
               
                //---------------------------------------------------------------------
                // validacion datos com
                //---------------------------------------------------------------------

                if (ddlBaudrate.Text == "")
                {
                    MessageBox.Show("BaudRate está vacío");
                    return;
                }

                if (ddlComPorts.Text == "")
                {
                    MessageBox.Show("Puerto COMM está vacío");
                    return;
                }

                if (ddlDatabits.Text == "")
                {
                    MessageBox.Show("DataBits está vacío");
                    return;
                }

                if (ddlParity.Text == "")
                {
                    MessageBox.Show("Paridad está vacío");
                    return;
                }

                if (ddlStopbits.Text == "")
                {
                    MessageBox.Show("StopBits está vacío");
                    return;
                }

                if (!Int32.TryParse(txtTimeout.Text.Trim(), out timeout))
                {
                    MessageBox.Show("Número de Tiempo de espera inválido");
                    return;
                }
            }

            //---------------------------------------------------------------------
            // Core Transaction
            //---------------------------------------------------------------------

            transaction = new Transaction_RS232();

            transaction.Baudrate        = ddlBaudrate.Text  ;
            transaction.ComPort         = ddlComPorts.Text  ;
            transaction.DataBits        = ddlDatabits.Text  ;
            transaction.StopBits        = ddlStopbits.Text  ;
            transaction.Parity          = ddlParity.Text    ;
            transaction.Timeout         = timeout           ;
            transaction.IncluirTimeout  = chkIncluirMensaje.Checked;
            DateTime rigth_now          = DateTime.Now      ;
            
            transaction.StopOnACK       = true              ;
            transaction.SendACK         = true              ;

            transaction.setBinTableId(binTableId);


            transaction.setET("!ET00366APLINETC08002011A2B3F7210000030320002416601ACA0CD33C4C629E824EAD50CF5277CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E477CC7FA651D9A5E434BA63AB");
            transaction.C14_BinTables();

            TransactionResult trxResult = transaction.Z3();

            transaction.CloseChannel();

            showResponse(trxResult);

        }
        private void ChkIncluirMensaje_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Button1_Click_1(object sender, EventArgs e)
        {
            if (txtBinTableId.Text.Length == 0) 
            {
                MessageBox.Show("El Bin Id es requerido");
                return;
            }

            storeBinTableId(txtBinTableId.Text);
        }


        public void displayText(String text) 
        {
            Transaction_RS232 transaction = null;

            int timeout = 0;
            //----------------------------
            // validaciones
            //----------------------------
            {

                //---------------------------------------------------------------------
                // validacion datos com
                //---------------------------------------------------------------------

                if (ddlBaudrate.Text == "")
                {
                    MessageBox.Show("BaudRate está vacío");
                    return;
                }

                if (ddlComPorts.Text == "")
                {
                    MessageBox.Show("Puerto COMM está vacío");
                    return;
                }

                if (ddlDatabits.Text == "")
                {
                    MessageBox.Show("DataBits está vacío");
                    return;
                }

                if (ddlParity.Text == "")
                {
                    MessageBox.Show("Paridad está vacío");
                    return;
                }

                if (ddlStopbits.Text == "")
                {
                    MessageBox.Show("StopBits está vacío");
                    return;
                }

                if (!Int32.TryParse(txtTimeout.Text.Trim(), out timeout))
                {
                    MessageBox.Show("Número de Tiempo de espera inválido");
                    return;
                }
            }

            //---------------------------------------------------------------------
            // Core Transaction
            //---------------------------------------------------------------------

            transaction = new Transaction_RS232();

            transaction.Baudrate = ddlBaudrate.Text;
            transaction.ComPort = ddlComPorts.Text;
            transaction.DataBits = ddlDatabits.Text;
            transaction.StopBits = ddlStopbits.Text;
            transaction.Parity = ddlParity.Text;
            transaction.Timeout = timeout;
            transaction.IncluirTimeout = chkIncluirMensaje.Checked;
            DateTime rigth_now = DateTime.Now;
            transaction.StopOnACK = true;

            transaction.SendACK = true;


            transaction.setDisplayText(text);

            TransactionResult trxResult = transaction.Z2();

      
            transaction.CloseChannel();

            showResponse(trxResult);
        }


        public void cancelServices()
        {
            Transaction_RS232 transaction = null;

            int timeout = 0;
            //----------------------------
            // validaciones
            //----------------------------
            {

                //---------------------------------------------------------------------
                // validacion datos com
                //---------------------------------------------------------------------

                if (ddlBaudrate.Text == "")
                {
                    MessageBox.Show("BaudRate está vacío");
                    return;
                }

                if (ddlComPorts.Text == "")
                {
                    MessageBox.Show("Puerto COMM está vacío");
                    return;
                }

                if (ddlDatabits.Text == "")
                {
                    MessageBox.Show("DataBits está vacío");
                    return;
                }

                if (ddlParity.Text == "")
                {
                    MessageBox.Show("Paridad está vacío");
                    return;
                }

                if (ddlStopbits.Text == "")
                {
                    MessageBox.Show("StopBits está vacío");
                    return;
                }

                if (!Int32.TryParse(txtTimeout.Text.Trim(), out timeout))
                {
                    MessageBox.Show("Número de Tiempo de espera inválido");
                    return;
                }
            }

            //---------------------------------------------------------------------
            // Core Transaction
            //---------------------------------------------------------------------

            transaction = new Transaction_RS232();

            transaction.Baudrate = ddlBaudrate.Text;
            transaction.ComPort = ddlComPorts.Text;
            transaction.DataBits = ddlDatabits.Text;
            transaction.StopBits = ddlStopbits.Text;
            transaction.Parity = ddlParity.Text;
            transaction.Timeout = timeout;
            transaction.IncluirTimeout = chkIncluirMensaje.Checked;
            DateTime rigth_now = DateTime.Now;
            transaction.StopOnACK = true;

            transaction.SendACK = true;

            TransactionResult trxResult = transaction.CancelServices();


            transaction.CloseChannel();

            showResponse(trxResult);
        }



        private void BtnDisplayText_Click(object sender, EventArgs e)
        {
            displayText(txtDisplayText.Text);
        }

        private void BtnCancelServices_Click(object sender, EventArgs e)
        {
            cancelServices();
        }



        public void llaveAleatoria(bool cancel)
        {
          
            Transaction_RS232 transaction = null;

            int timeout = 0;
            //----------------------------
            // validaciones
            //----------------------------
            {

                //---------------------------------------------------------------------
                // validacion datos com
                //---------------------------------------------------------------------

                if (ddlBaudrate.Text == "")
                {
                    MessageBox.Show("BaudRate está vacío");
                    return;
                }

                if (ddlComPorts.Text == "")
                {
                    MessageBox.Show("Puerto COMM está vacío");
                    return;
                }

                if (ddlDatabits.Text == "")
                {
                    MessageBox.Show("DataBits está vacío");
                    return;
                }

                if (ddlParity.Text == "")
                {
                    MessageBox.Show("Paridad está vacío");
                    return;
                }

                if (ddlStopbits.Text == "")
                {
                    MessageBox.Show("StopBits está vacío");
                    return;
                }

                if (!Int32.TryParse(txtTimeout.Text.Trim(), out timeout))
                {
                    MessageBox.Show("Número de Tiempo de espera inválido");
                    return;
                }
            }

            //---------------------------------------------------------------------
            // Core Transaction
            //---------------------------------------------------------------------

            transaction = new Transaction_RS232();

            transaction.Baudrate = ddlBaudrate.Text;
            transaction.ComPort = ddlComPorts.Text;
            transaction.DataBits = ddlDatabits.Text;
            transaction.StopBits = ddlStopbits.Text;
            transaction.Parity = ddlParity.Text;
            transaction.Timeout = timeout;
            transaction.IncluirTimeout = chkIncluirMensaje.Checked;
            DateTime rigth_now = DateTime.Now;

            transaction.SendACK = true;

            TransactionResult trxResult = transaction.RandomKeyRequest();

            if (null != trxResult && trxResult.Result == OperationResult.Sucess) 
            {
                if (cancel) 
                {
                    transaction.StopOnACK = true;
                    transaction.CancelServices();
                }
              
            }

            transaction.CloseChannel();

            showResponse(trxResult);
            
        } 

        private void BtnLlave_Click(object sender, EventArgs e)
        {
            llaveAleatoria(cancel: true);
        }


        public void makeCorresponsal() 
        {
        
        }
        private void Button1_Click_2(object sender, EventArgs e)
        {

            Transaction_RS232 transaction = null;

            int timeout = 0;
            //----------------------------
            // validaciones
            //----------------------------
            {

                //---------------------------------------------------------------------
                // validacion datos com
                //---------------------------------------------------------------------

                if (ddlBaudrate.Text == "")
                {
                    MessageBox.Show("BaudRate está vacío");
                    return;
                }

                if (ddlComPorts.Text == "")
                {
                    MessageBox.Show("Puerto COMM está vacío");
                    return;
                }

                if (ddlDatabits.Text == "")
                {
                    MessageBox.Show("DataBits está vacío");
                    return;
                }

                if (ddlParity.Text == "")
                {
                    MessageBox.Show("Paridad está vacío");
                    return;
                }

                if (ddlStopbits.Text == "")
                {
                    MessageBox.Show("StopBits está vacío");
                    return;
                }

                if (!Int32.TryParse(txtTimeout.Text.Trim(), out timeout))
                {
                    MessageBox.Show("Número de Tiempo de espera inválido");
                    return;
                }
            }

            //---------------------------------------------------------------------
            // Core Transaction
            //---------------------------------------------------------------------

            transaction = new Transaction_RS232();

            transaction.Baudrate        = ddlBaudrate.Text  ;
            transaction.ComPort         = ddlComPorts.Text  ;
            transaction.DataBits        = ddlDatabits.Text  ;
            transaction.StopBits        = ddlStopbits.Text  ;
            transaction.Parity          = ddlParity.Text    ;
            transaction.Timeout         = timeout           ;
            transaction.IncluirTimeout  = chkIncluirMensaje.Checked;
            DateTime rigth_now          = DateTime.Now              ;

            transaction.SendACK = false;

            transaction.setTransactionDate                  (   rigth_now.ToString("yyMMdd")    );
            transaction.setTransactionTime                  (   rigth_now.ToString("hhmmss")    );
            transaction.setAmount                           (   FormatAmount("1.23")            );
            transaction.setCardNumber                       (   "4342574031759775"              );
            transaction.setOperatorName                     (   "OP1"                           );
            transaction.setReference                        (   "REF"                           );
            transaction.setIdSucursal                       (   "0001"                          );
            transaction.setIdCaja                           (   "0002"                          );
            transaction.setPOSSerial                        (   "VF4566"                        );
            transaction.setCifrarPagosTarjetaCorresponsal   (   true                            );

            TransactionResult trxResult = transaction.Corresponsal();

            transaction.CloseChannel();

            showResponse(trxResult);

        }
    }
}
