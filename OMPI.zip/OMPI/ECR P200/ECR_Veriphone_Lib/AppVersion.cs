﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECR_Veriphone_Lib
{

    //-----------------------------------------------------------------------
    // La version 1.1.0 
    // empieza a soportar el verifone utilizado por bbva que 
    // rige por la documentación 8.5 
    // Anexo B Protocolo de Comunicación Pinpad ECR v8.5 mayo2020.pdf
    //-----------------------------------------------------------------------

    /// <summary>    
    /// Name         :  AppVersion.cs
    /// Author       :  Carlos E Mejia Martinez   
    /// Date         :  14 Marzo de 2014                
    /// Description  :     
    ///                 Esta clase contiene la información sobre la versión y release de la librería.
    /// </summary>
    public class AppVersion
    {

        /// <summary>
        /// Gets the DCL Core version
        /// </summary>
        /// <returns>
        /// String : Version
        /// </returns>
        public static String GetVersion()
        {
            return "1.1.7";
        }


        /// <summary>
        ///
        /// Get the DCL Build Version commonly a build date (yyyyMMdd)
        /// 
        /// </summary>
        /// <returns> String: Build Version (yyyyMMdd) </returns>
        public static String GetRevision()
        {
            return "20210901";
        }
    }
}
