﻿using ECR_Veriphone_Lib.util;
using log4net               ;
using System                ;
using System.Diagnostics;
using System.IO             ;
using System.IO.Ports       ;
using System.Linq           ;
using System.Text           ;
using System.Threading      ;

namespace ECR_Veriphone_Lib.communication
{
    /// <summary>    
    /// Name         :  PortHandler.cs
    /// Author       :  Carlos E Mejia Martinez   
    /// Date         :  22 Agosto de 2014                
    /// Description  :     
    ///                 Esta clase es el componente que se encarga de realizar la conexión serial con la terminal.
    /// </summary>
    public class PortHandler
    {

        private static  readonly ILog log = LogManager.GetLogger(typeof(PortHandler));

        public  String              TripleDESKey = "Encrypte$$2015";

        /// <summary>
        /// Enumeración para manejar los errores de comunicación serial
        /// </summary>
        public  enum                ERR_SERIAL_PORT
        {
            ERR_NO_ERROR            =  0,
            ERR_PORT_OPEN           = -1,
            ERR_PORT_CLOSE          = -2,
            ERR_SERIAL_PORT_NULL    = -3,
            ERR_DATA_NOT_SENT       = -4,
            ERR_DATA_NOT_READ       = -5

        }

        private const   int         BUFFER_SIZE     = 1024 * 3  ;

        public  static  byte[]      ACK             = { 0x06 }  ;

        public  static  byte[]      NACK            = { 0x15 }  ;

        public  static  byte[]      NOTHING         = { 0x01 }  ;

        public static   int         iNACK           = 21        ;

        public bool verifyCheckSum = false; 


        /// <summary>
        /// Buffer que recepciona los datos (bytes) de respuesta que viene de la terminal.
        /// </summary>
        public          byte[]      ReceivedBuffer              { get; set; }     //este es usado como buffer temporal   para recibir la data

        public          byte[]      Buffer                      { get; set; }     //este es el buffer final 

        public          bool        UseReceivedMethodString     { get; set; }

        public          bool        IsSpecialConnection         { get; set; }
       
        /// <summary>
        /// Communication Port 
        /// </summary>
        public          string      ComPort                     { get; set; }

        /// <summary>
        /// Connection Speed
        /// </summary>
        public          string      Baudrate                    { get; set; }

        /// <summary>
        /// Parity Bits
        /// </summary>
        public          string      Parity                      { get; set; }

        /// <summary>
        /// Stop Bits
        /// </summary>
        public          string      StopBits                    { get; set; }

        /// <summary>
        /// Data Bits
        /// </summary>
        public          string      DataBits                    { get; set; }

        /// <summary>
        /// Tiempo de Espera para terminar el proceso de la transacción en el tiempo indicado.
        /// </summary>
        public          int         TimeOut                     { get; set; }

        public          bool        AckReceived                 { get; set; }

        public bool StopOnAck { get; set; }


        public          bool        BufferRead = false      ;

        private         SerialPort  _serialPort             ;

        /// <summary>
        /// Retorna el objeto SerialPort usado en el comunicación con la terminal
        /// </summary>
        public          SerialPort  SerialPortObject
        {
            get
            {
                return _serialPort;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public          PortHandler                         (                                               )
        {
            _serialPort = new SerialPort();

            IsSpecialConnection = false;

            StopOnAck           = false;
        }

        /// <summary>
        /// Esta función intenta abrir el puerto asignada por la propieda ComPort
        /// </summary>
        public          int         OpenPort                (                                               )
        {

            ERR_SERIAL_PORT portError = ERR_SERIAL_PORT.ERR_NO_ERROR;

            log.Info("Opening Port");

            if (_serialPort == null)
            {
                _serialPort = new SerialPort();
            }

            _serialPort.Encoding        = Encoding.Default          ;
            BufferRead                  = false                     ;
            ReceivedBuffer              = null                      ;
            _serialPort.DataReceived    += _serialPort_DataReceived ;
            _serialPort.PortName        = ComPort                   ;
            _serialPort.BaudRate        = Convert.ToInt32(Baudrate) ;

            switch (Parity.ToUpper())
            {
                case "NONE":
                    _serialPort.Parity = System.IO.Ports.Parity.None            ;
                    break;
                case "EVEN":
                    _serialPort.Parity = System.IO.Ports.Parity.Even            ;
                    break;
                case "ODD":
                    _serialPort.Parity = System.IO.Ports.Parity.Odd             ;
                    break;
            }


            switch (StopBits)
            {
                case "1"    :
                    _serialPort.StopBits = System.IO.Ports.StopBits.One         ;
                    break;
                case "1.5"  :
                    _serialPort.StopBits = System.IO.Ports.StopBits.OnePointFive;
                    break;
                case "2"    :
                    _serialPort.StopBits = System.IO.Ports.StopBits.Two         ;
                    break;
            }

            _serialPort.DataBits = Convert.ToInt32(DataBits);

            try
            {
                if (!_serialPort.IsOpen)
                {
                    _serialPort.Open    (                   );
                    log.Info            (   "Port opened"   );
                }
                else
                {
                    log.Info("Port is already opened");
                }
            }
            catch (IOException ex)
            {
                portError = ERR_SERIAL_PORT.ERR_PORT_OPEN;
                log.Error("OpenPort", ex);
            }
            catch (Exception ex)
            {
                portError = ERR_SERIAL_PORT.ERR_PORT_OPEN;
                log.Error("OpenPort", ex);
            }

            if (portError == ERR_SERIAL_PORT.ERR_NO_ERROR)
            {
                _serialPort.DiscardOutBuffer(   );
                _serialPort.DiscardInBuffer (   );
            }

            return (int)portError;
        }

        /// <summary>
        /// Chequea si el Puerto está abierto.
        /// </summary>
        /// <returns></returns>
        public          bool        IsOpen                  (                                               )
        {
            bool isOpen = false;

            if (_serialPort != null)
            {
                isOpen = _serialPort.IsOpen;
            }
            else
            {
                isOpen = false;
            }

            return isOpen;
        }

        /// <summary>
        /// Cierra el canal de comunicación serial.
        /// </summary>
        public          int         ClosePort               (                                               )
        {

            ERR_SERIAL_PORT commPort = ERR_SERIAL_PORT.ERR_NO_ERROR;

            log.Info("Closing Port");

            try
            {
                if (_serialPort != null)
                {
                    _serialPort.Close();
                    log.Info("Port Closed");
                }
            }
            catch (Exception ex)
            {
                commPort = ERR_SERIAL_PORT.ERR_PORT_CLOSE;
                log.Error("ClosePort", ex);
            }

            return (int)commPort;
        }

        /// <summary>
        /// Envía la ACK a la terminal.
        /// Esto indica que ya terminamos de enviar datos a la terminal.
        /// </summary>
        /// <returns></returns>
        public          bool        SendACK                 (                                               )
        {
            bool    sent        = false;
            byte[]  chrControl  = new byte[1];

            chrControl[0] = 0x06;

            if (SendData(chrControl))
            {
                sent = true;
                log.Info("ACK Sent");
            }
            else
            {
                sent = false;
                log.Info("ACK not Sent");
            }

            Thread.Sleep(500);

            return sent;
        }

        /// <summary>
        /// Recibe el ACK que envá la terminal.        
        /// Esto indica que ya terminamos de leer. 
        /// 
        /// 
        /// </summary>
        /// <returns> 
        ///     ACK         -> Good
        ///     NACK        -> Retry
        ///     NOTHING     -> Stop
        /// </returns>
        public          byte        WaitACK                 (                                               )
        {

            byte    bRet        = NOTHING[0];
            int     bytesRead   = 0;

            ReceivedBuffer = null;

            byte[] readACKBuffer = new byte[1];

            while (bytesRead == 0)
            {

                // 5 seg solamente para leer el ACK
                _serialPort.ReadTimeout = 5000;

                bytesRead += _serialPort.ReadByte();

            }

            if (bytesRead > 0)
            {

                // Restauramos el timeout correcto 
                _serialPort.ReadTimeout = TimeOut;

                log.Info(String.Format("WaitACK Received {0:X2}", bytesRead));

                bRet = (byte)bytesRead;

            }
            else
            {
                bRet = NOTHING[0];
                log.Error("WaitACK not Received");
            }

            return bRet;

        }
      
        public          string      EncriptTrace            (   String prefix   ,   byte[] data             )
        {
            String trace = "";
            try
            {
                trace = Utilidad.Bcd2str(data, 0, data.Length * 2, false);
                if (!String.IsNullOrEmpty(trace))
                {

#if (encrypt_trace)
                   
                    String encriptedTrace = PINBlockLibrary.TripleDESLib.EncryptAsBytes(trace, true, TripleDESKey);
                    
                    log.Info(String.Format(" {0} = {1}", prefix, encriptedTrace));
#else
                    log.Info(String.Format(" {0} = {1}", prefix, trace));
#endif
                }

            }
            catch (Exception ex)
            {
                trace = "";
                log.Error(ex);
            }

            return trace;
        }
        /// <summary>
        /// Escribe o envía datos (bytes) al puerto. 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public          bool        SendData                (   byte[] data                                 )
        {
            bool _sentData = false;

            try
            {
                String trace = Utilidad.Bcd2str(data, 0, data.Length * 2, false);
                if (!String.IsNullOrEmpty(trace))
                {

#if (encrypt_trace)
                    String encriptedTrace = PINBlockLibrary.TripleDESLib.EncryptAsBytes(trace, true, TripleDESKey);
                    
                    log.Info(String.Format("Sending Data = {0} ", encriptedTrace));
#else

                    log.Info(String.Format("Sending Data = {0} ", trace));

                    log.Info("Sent >>>> ");

                    log.Info(HexDump.dumpHexString(data));

                    //log.Info( Utilidad.HexDump ( data ));
#endif

                }

            }
            catch (Exception ex)
            {
                log.Error(ex);
            }

            try
            {

                if (_serialPort != null)
                {
                    _serialPort.DiscardOutBuffer(                       );
                    _serialPort.Write           (data, 0, data.Length   );


                    /*
                    int MAX_SIZE = 30; 
                
                    int size = 0; 
                
                    while (data.Length != size ) 
                    {
                        if (size + MAX_SIZE > data.Length) 
                        {
                            _serialPort.Write( data,  size, (data.Length - size ));
                        
                            log.Info("Sending size [" + (data.Length - size ).ToString() + "]");
                        
                            //encriptTrace ("Sending Size ", data);
                            //log.Info( "Data Sent = " + Utilidad.Bcd2str(data, size, (data.Length - size ) * 2, false));
                        
                            break;
                        
                        }
                        else 
                        {
                            _serialPort.Write( data,  size, MAX_SIZE);
                        
                            //log.Info( "Data Sent = " + Utilidad.Bcd2str(data, size, MAX_SIZE * 2, false));
                        
                            String sSize = size.ToString(); 
                        
                            String sSize2 = ""; 
                        
                            //System.out.println("Sending size =[" + sSize + "]");
                        
                            size += MAX_SIZE;
                         
                            sSize2 = size.ToString(); 
                        
                            log.Info("Sending size =[" + sSize + "] to [" + sSize2 + "]");
                        
                            //System.out.println(" to size30  =[" + sSize + "]");
                        }
                    
                        Thread.Sleep(10);
                    }
                        
                    */
                    log.Info("Data Sent!");

                    _sentData = true;
                }
                else
                {
                    _sentData = false;
                    log.Info("Data not Sent!");
                }
                return _sentData;
            }
            catch (UnauthorizedAccessException ex)
            {
                log.Error(ex);
                return false;
            }
        }
        

        public          int         ResetPort               (                                               )
        {
            log.Info("Resetting Port");
            try
            {
                if (_serialPort != null)
                {
                    _serialPort.DiscardOutBuffer();
                    _serialPort.DiscardInBuffer();
                }
            }
            catch (Exception ex)
            {
                log.Info(ex.Message);
            }

            return 0;
        }
        String sDataRead = "";

        /// <summary>
        /// Evento que surge cuando hay data disponible para leer 
        /// En este evento se lee el ACK y luego la data de la transacci'on enviada por la terminal
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void                        _serialPort_DataReceived(object sender, SerialDataReceivedEventArgs e   )
        {
            try
            {
                log.Info("_serialPort_DataReceived Event Fired");

                SerialPort sp = (SerialPort)sender;


                //-------------------------------------------------------
                //-- Task List
                //-- Task 1 
                //--        a. Read Transaction Data including ACK byte
                //-------------------------------------------------------

                if (!sp.IsOpen)
                {
                    log.Info("sp.IsOpen is false");
                    return;
                }

                if (sp.BytesToRead > 0)
                {
                    sDataRead += sp.ReadExisting();
                }

                Byte[] bDataRead = null;

                if (!String.IsNullOrEmpty(sDataRead))
                {
                    //bDataRead = ASCIIEncoding.ASCII.GetBytes(sDataRead);
                    bDataRead = Utilidad.String2Bytes(sDataRead);
                }

                String receiveDataTrace = "";

                if (null != bDataRead)
                {
                    receiveDataTrace = Utilidad.Bcd2str(bDataRead, 0, bDataRead.Length * 2, false);
                }
                else
                {
                    log.Info("bDataRead =  Utilidad.String2Bytes(sDataRead) is null ");
                }


                if (!String.IsNullOrEmpty(receiveDataTrace))
                {
#if encrypt_trace
                    String encriptedTrace = PINBlockLibrary.TripleDESLib.EncryptAsBytes(receiveDataTrace, true, TripleDESKey);
                    log.Info("Buffer Received -> " + encriptedTrace);
#else
                    log.Info("Buffer Received -> " + receiveDataTrace);
#endif
                }

                bool AckRead = false;

                int minimum_length = 8; // abarca dos bytes pueden ser ACK + STX + 2 bytes de Len

                if (IsSpecialConnection)
                {
                    minimum_length = 6; // abarca dos bytes pueden ser ACK + STX + 2 bytes de CMD + 2 bytes de Len
                }


                if (bDataRead != null && bDataRead.Length == 1 && bDataRead[0] == NACK[0]) 
                {
                    //--------------------------------
                    //esto hace que deje de leer mas
                    //--------------------------------

                    log.Info("--------------- NACK ----------------");
                    ReceivedBuffer  = bDataRead;
                    BufferRead      = true;
                    AckReceived     = true;

                }

                if (bDataRead != null && bDataRead.Length > 0 && bDataRead[0] == ACK[0])
                {
                    //--------------------------------
                    //esto hace que deje de leer mas
                    //--------------------------------

                    if (StopOnAck)
                    {
                        log.Info("--------------- ACK ----------------");
                        ReceivedBuffer  = bDataRead ;
                        BufferRead      = true      ; 
                        AckReceived     = true      ;
                    }

                
                }

               

                if (bDataRead != null && bDataRead.Length > minimum_length)
                {
                    int startIndex = 7;


                    if (IsSpecialConnection)
                    {
                        startIndex = 4;
                    }

                    byte[] bTraceLength = new byte[2];

                    //-- vamos a chequear que tenemos leido el ACK
                    if (bDataRead[0] == 0x06)
                    {
                        AckRead = true;
                    }
                    else
                    {
                        AckRead = false;
                    }

                    if (AckRead)
                    {
                        System.Array.Copy(bDataRead, startIndex, bTraceLength, 0, 2);
                    }
                    else
                    {
                        System.Array.Copy(bDataRead, startIndex - 1, bTraceLength, 0, 2);
                    }

                    int transactionDataLenght = 0;

                    if (IsSpecialConnection)
                    {
                        transactionDataLenght = Convert.ToInt32(Utilidad.Bcd2Str(bTraceLength), 16);

                        //transactionDataLenght += 2;
                        if (transactionDataLenght == 0)
                        {
                            transactionDataLenght += 2;
                        }

                    }
                    else
                    {
                        transactionDataLenght = Convert.ToInt32(Utilidad.Bcd2Str(bTraceLength), 16);
                    }



                    int bytesRead = bDataRead.Length;

                    log.Info(String.Format("BytesRead = '{0}' -- transactionDataLenght='{1}'", bytesRead, transactionDataLenght));

                    //con DCL la validación era transactionDataLenght > 0
                    //con Kinpos Connect será >= 0

                    // para verifone setrá >= 0
                    if (transactionDataLenght >= 0)
                    {
                        //--
                        //-- Si el ack esta leido entonces la tram tiene 6 bytes adicionales, 
                        //-- en caso contrario tendra un byte menos
                        //-- Los bytes serian:
                        //-- ACK + STX + L1 + L2 + ETX + LCR
                        //-- donde L1 y L2 son dos bytes de longitud
                        //-- En caso de no recibir el ACK, tendriamos 5 bytes:
                        //-- STX + L1 + L2 + ETX + LCR
                        //--

                        int totalLength = transactionDataLenght + (AckRead ? 11 : 10);


                        if (IsSpecialConnection)
                        {
                            //--
                            //-- Si el ack esta leido entonces la tram tiene 6 bytes adicionales, 
                            //-- en caso contrario tendra un byte menos
                            //-- Los bytes serian:
                            //-- ACK + STX + CMD1 + CMD2  + ETX + LCR
                            //-- donde L1 y L2 son dos bytes de longitud
                            //-- En caso de no recibir el ACK, tendriamos 5 bytes:
                            //-- STX + CMD1 + CMD2 + ETX + LCR
                            //--

                            //kinpos connect en la longitud incluye del campo longitud (dos bytes), siempre y cuando el comando traiga respuesta.
                            //Ejemplo Comando: A001 Datos: 01020304 Len: 04
                            //       
                            //       ----------------------------------------
                            //       | CMD   | Len incluyendo | Datos       |
                            //       ----------------------------------------
                            // Trama:|  A001 |      0006      | 01020304    |
                            //       ----------------------------------------
                            //
                            //
                            //Si el comando NO trae respuesta por ejemplo un beep, la longitud viene en cero, no se incluye 
                            //
                            //
                            //       ----------------------------------------
                            //       | CMD   | Len incluyendo | Datos       |
                            //       ----------------------------------------
                            // Trama:|  A002 |      0000      |             |
                            //       ----------------------------------------
                            // es por eso que siempre que sea mayor que cero la longitud, vamos a restarle el tamano de los dos bytes
                            // y cuando venga en cero vamos a agregarlo los dos bytes de longitud

                            //if (transactionDataLenght == 0)
                            //{
                            //    transactionDataLenght += 2;
                            //}
                            //else
                            //{
                            //    transactionDataLenght -= 2;
                            //}



                            totalLength = transactionDataLenght + (AckRead ? 6 : 5);
                        }

                        if (verifyCheckSum) 
                        {
                            log.Info( String.Format("Verificando CheckSum   STX = {0} LCR = {1} ",
                                bDataRead[bDataRead.Length -2].ToString("X2"), 
                                bDataRead[bDataRead.Length -1].ToString("X2")) );


                            if (bDataRead[bDataRead.Length - 2] == 0x03)
                            {
                                byte    LCR        = bDataRead[bDataRead.Length - 1];

                                int totalRemove     = 2;

                                int initialIndex    = 1; 

                                if (AckRead)
                                {
                                    totalRemove     = 3;
                                    initialIndex    = 2;
                                }

                                byte[] temp         = new byte[bDataRead.Length - totalRemove]; // vamos a quitar ACK, STX y LCR

                                System.Array.Copy(bDataRead, initialIndex, temp, 0, temp.Length);

                                log.Info (Utilidad.Bcd2str(temp, 0, temp.Length * 2, false));

                                byte[]  calculate  = Utilidad.CalculateLCR(temp);

                                log.Info(String.Format("Calculated CheckSum LCR = {0} ", calculate[0].ToString("X2") ));

                                if (calculate[0] == LCR) 
                                {
                                    ReceivedBuffer  = bDataRead;
                                    BufferRead      = true;
                                    AckReceived     = true;
                                }
                            }
                        }

                        if (totalLength == bytesRead)
                        {
                            ReceivedBuffer = new byte[bytesRead];
                            System.Array.Copy(bDataRead, 0, ReceivedBuffer, 0, bytesRead);
                            BufferRead = true;
                            AckReceived = true;


                            if (ReceivedBuffer != null && BufferRead && AckReceived)
                            {
                                try
                                {
                                    String traceLog = Utilidad.Bcd2str(ReceivedBuffer, 0, ReceivedBuffer.Length * 2, false);

                                    if (!String.IsNullOrEmpty(traceLog))
                                    {
#if encrypt_trace
                                        String encriptedTrace = PINBlockLibrary.TripleDESLib.EncryptAsBytes(traceLog, true, TripleDESKey);
                                        log.Info(String.Format("Buffer Received ({1} ACK)-> {0}" , encriptedTrace, AckRead ? "Con" : "Sin"));
#else
                                        //log.Info(String.Format("Buffer Received ({1} ACK)-> {0}" , traceLog, AckRead ? "Con" : "Sin"));

                                        log.Info("Received <<<< ");
                                        log.Info(traceLog);
                                        log.Info(HexDump.dumpHexString(ReceivedBuffer));

#endif
                                    }
                                }
                                catch (Exception ex)
                                {
                                    log.Error(ex);
                                }

                              
                            }

                            if (ReceivedBuffer != null)
                            {
                                log.Info(String.Format("ReceivedBuffer.Length -> {0}", ReceivedBuffer.Length));
                            }
                            else
                            {
                                log.Info("ReceivedBuffer Null ==> Lenght = 0");
                            }

                        }
                    }  //-- end if trans
                }
            }
            catch (Exception ex)
            {
                log.Error("serialPort_DataReceived", ex);
            }
        }


        /// <summary>
        /// Este m'etodo lee de forma asincr'onica la data que viene de la terminal 
        /// El m'etodo de lectura del puerto serial es ReadExisting()
        /// </summary>
        /// <returns></returns>
        public          int         ReceiveDataAsyncronous  (                                               )
        {

            Stopwatch sw = new Stopwatch();
            sw.Start();

            //--
            //-- inicializamos nuestras variables de controls 
            //-- que son actualizadas en _serialPort_DataReceived 
            //-- 
            AckReceived = false;
            BufferRead = false;
            sDataRead = "";

            while (true)
            {

                //-- Let's check if we have a timeout
                if (sw.ElapsedMilliseconds > TimeOut)
                {
                    log.Info(String.Format("ReceiveDataAsyncronous() => Timeout ocurred ElapsedMilliseconds = {0} TimeOut = {1}", sw.ElapsedMilliseconds, TimeOut));
                    break;
                }

                //-- let's check if we have read some data
                if (AckReceived && BufferRead)
                {
                    //log.Info(String.Format("We have read some buffer in DataReceived Event"));
                    break;
                }
            }

            //Chequeamos si el buffer tiene datos

            if (ReceivedBuffer != null)
            {
                return ReceivedBuffer.Length;
            }
            else
            {
                log.Info("------------------------------ ReceivedBuffer NULL ------------------------------");
                return 0;
            }

        }

    }

}
