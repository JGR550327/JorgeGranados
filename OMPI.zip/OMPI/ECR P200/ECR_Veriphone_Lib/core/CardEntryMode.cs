﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECR_Veriphone_Lib.core
{
    public enum  CardEntryMode
    {
        None        = 00,
        Manual      = 01,
        Chip        = 05,
        Fallback    = 80,
        Swiped      = 90, 
        Other       
     
    }
}
