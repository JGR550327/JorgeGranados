﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECR_Veriphone_Lib.core
{
    public enum CardType
    {
        None    = 00,
        Debit   = 01, 
        Credit  = 02, 
        Other   = 03
    }
}
