﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECR_Veriphone_Lib.core
{
    public class Constantes
    {
        public static int TRAN_TYPE_LEN         =   1       ;
        public static int TRANSACTION_DATE_LEN  =   3       ;
        public static int TRANSACTION_TIME_LEN  =   3       ;
        public static int VOUCHER_LEN           =   4       ;
        public static int AUTH_LEN              =   6       ;
        public static int AMOUNT_LEN            =   4       ;
        public static int CURRENCY_LEN          =   1       ;
        public static int MERCHANT_DECISION_LEN =   1       ;
        public static int ECR_ID_LEN            =   26      ;
        public static int EMV_DATA_LEN          =   42      ;

    }
}
