﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECR_Veriphone_Lib.core
{
    public class FieldElement
    {

        public String       Name        { get; set; }

        public byte[]       Value       { get; set; }
        public String       ValueStr    { get; set; }


        /// <summary>
        /// BCD -> Binary Coded Decimal  
        /// N   -> Numeric      (BCD)
        /// ANS -> Alfanumeric (ASCII)
        /// HEX -> Hexadecimal 
        /// </summary>
        public FieldType    FieldType   { get; set; }
            
        public LengthType   LengthType  { get; set; }

        public FieldElement() 
        {
        }

        public FieldElement(FieldType fieldType, LengthType lengthType )
        {
            this.FieldType  = FieldType ;
            this.LengthType = lengthType;
        }

        public FieldElement
                            (    
                                String      name        , FieldType fieldType, 
                                LengthType  lengthType 
                            )
        {
            this.Name       = name      ;
            this.FieldType  = fieldType ;
            this.LengthType = lengthType;
            this.LengthType.CharToFill = '_';
        }

       


        public String getValueAsString ()
        {
            String strValue = ""; 

            if (null == Value) 
            {
                return "";
            }

            if (Value.Length == 0) 
            {
                return "";
            }

            if (FieldType == FieldType.ANS)
            {
                strValue =  ASCIIEncoding.ASCII.GetString(Value);
            }
            else 
            {
                strValue = util.Utilidad.Bcd2str(Value, 0, Value.Length * 2, true);
            }

            return strValue;

        }

        public override string ToString()
        {
            StringBuilder builder = new StringBuilder(  );

            builder.AppendLine  ("Nombre    = " + Name      + System.Environment.NewLine);
            builder.AppendLine  ("Value     = " + ValueStr  + System.Environment.NewLine);
            builder.AppendLine  (String.Format( "Length = {0} LengthType = {1} ", 
                this.LengthType.Length, 
                this.LengthType.ELengthType.ToString(), 
                this.LengthType.LengthFormat.ToString()) + System.Environment.NewLine);

            return builder.ToString();
        }

    }
}
