﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECR_Veriphone_Lib.core
{
    public enum FieldType
    {
        BCD , 
        N   , 
        ANS ,
        HEX   
    }
}
