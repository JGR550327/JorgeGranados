﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECR_Veriphone_Lib.core
{
    public enum HostStatus
    {
        Succeed                     = 0x00, 
        Declined                    = 0x01, 
        NoResponse                  = 0x02, 
        AbortTransaction_SyncPOS    = 0x03, 
        Other                       = 0xFF
    }
}
