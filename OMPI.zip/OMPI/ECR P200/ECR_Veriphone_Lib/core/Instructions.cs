﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECR_Veriphone_Lib.core
{
    public class Instructions
    {
     
        
        public static byte C1_Tags              = 0xC1;

        public static byte IssuerAD_Tags = 0x91;

        public static byte[] CC1                = ASCIIEncoding.ASCII.GetBytes("CC1");
        public static byte[] C14_BinTables      = ASCIIEncoding.ASCII.GetBytes("C14");
        public static byte[] C50_Authorization  = ASCIIEncoding.ASCII.GetBytes("C50");
        public static byte[] C51_Authorization  = ASCIIEncoding.ASCII.GetBytes("C51");
        public static byte[] C51_Settlement     = ASCIIEncoding.ASCII.GetBytes("C51");
        public static byte[] C53                = ASCIIEncoding.ASCII.GetBytes("C53");
        public static byte[] C54                = ASCIIEncoding.ASCII.GetBytes("C54");

        public static byte[] Z2                 = ASCIIEncoding.ASCII.GetBytes("Z2");
        public static byte[] Z3                 = ASCIIEncoding.ASCII.GetBytes("Z3");
        public static byte[] Z10                = ASCIIEncoding.ASCII.GetBytes("Z10");
        public static byte[] Z11                = ASCIIEncoding.ASCII.GetBytes("Z11");
        public static byte[] Cancel_72          = ASCIIEncoding.ASCII.GetBytes("72");
        public static byte[] Q8                 = ASCIIEncoding.ASCII.GetBytes("Q8");

        public static byte E1_Token             = 0xE1;
        public static byte E2_Token             = 0xE2;
        

    }
}
