﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECR_Veriphone_Lib.core
{
    public class Journal 
    {
        #region "propiedades"

        /// <summary>
        /// Transaction Date (YYMMDD)
        /// Format  : BCD 
        /// Len     : 3
        /// </summary>
        public FieldElement TransactionDate { get; set; }

        /// <summary>
        /// Transaction Time (HHMMSS)
        /// Format  : BCD
        /// Len     : 3
        /// </summary>
        public FieldElement TransactionTime { get; set; }

        /// <summary>
        /// Transaction Type 
        /// Format  : HEX
        /// Len     : 1
        /// </summary>
        public FieldElement TransactionType { get; set; }

        /// <summary>
        /// Voucher Number  
        /// Format  : BCD
        /// Len     : 4
        /// </summary>
        public FieldElement Voucher_Number { get; set; }


        /// <summary>
        /// Authorization Code 
        /// Format  : ANS
        /// Len     : 6
        /// </summary>
        public FieldElement Authorization_Code { get; set; }

        /// <summary>
        /// Amount
        /// Format  : HEX
        /// Len     : 4
        /// </summary>
        public FieldElement Amount { get; set; }

        /// <summary>
        /// Cashback Amount
        /// Format  : HEX
        /// Len     : 4
        /// </summary>
        public FieldElement Cashback_Amount { get; set; }

        /// <summary>
        /// Tip Amount
        /// Format  : HEX
        /// Len     : 4
        /// </summary>
        public FieldElement Tip_Amount { get; set; }

        /// <summary>
        /// Amount in USD 
        /// Format  : HEX
        /// Len     : 4
        /// </summary>
        public FieldElement Amount_USD { get; set; }

        /// <summary>
        /// Cashback Amount USD
        /// Format  : HEX
        /// Len     : 4
        /// </summary>
        public FieldElement Cashback_Amount_USD { get; set; }

        /// <summary>
        /// Tip Amount USD
        /// Format  : HEX
        /// Len     : 4
        /// </summary>
        public FieldElement Tip_Amount_USD { get; set; }


        /// <summary>
        /// Currency Index 
        /// 01 – Local      Currency
        /// 02 - Foreign    Currency
        /// Format  : HEX
        /// Len     : 1
        /// </summary>
        public FieldElement Currency_Index { get; set; }

        /// <summary>
        /// 
        /// Merchant Decision
        /// 
        /// if Amount = 0 
        ///     Merchant_Decision = 01
        /// else 
        ///     Merchant_Decision = 00
        ///     
        /// Format  : HEX
        /// Len     : 1
        /// </summary>
        public FieldElement Merchant_Decision { get; set; }

        /// <summary>
        /// 
        /// Merchant Decision
        /// 
        /// if Amount = 0 
        ///     Merchant_Decision = 01
        /// else 
        ///     Merchant_Decision = 00
        ///     
        /// Format  : HEX
        /// Len     : 1
        /// </summary>
        public FieldElement ECRID_POSSerialNumber { get; set; }


        /// <summary>
        /// 
        /// EMV Tags
        ///     
        /// Format  : HEX
        /// Len     : 42
        /// </summary>
        public FieldElement             EMV_Data        { get; set; }
     
         public List<FieldElement>      Elements        { get; set; }

        #endregion

        
        public  void        Init                    (                                                               ) 
        {
           

            //-----------------------------------------------------
            // Transaction Date
            // Format           : BCD
            // Length Type      : FIXED
            // Length           : 3
            // Length Format    : BCD
            //-----------------------------------------------------

            TransactionDate = new FieldElement( "TransactionDate"   ,
                                                FieldType.BCD       , 
                                                new LengthType(
                                                                    
                                                                    type            : EnumLengthType    .FIXED                  , 
                                                                    length          : Constantes        .TRANSACTION_DATE_LEN   ,
                                                                    lengthFormat    : LengthFormat      .BCD
                                                               )
                                                );

            //-----------------------------------------------------
            // Transaction Time
            // Format           : BCD
            // Length Type      : FIXED
            // Length           : 3
            // Length Format    : BCD
            //-----------------------------------------------------

            TransactionTime = new FieldElement  (
                                                    "TransactionTime"   ,
                                                    FieldType.BCD       , 
                                                    new LengthType(
                                                                    type            : EnumLengthType    .FIXED                  , 
                                                                    length          : Constantes        .TRANSACTION_TIME_LEN   ,
                                                                    lengthFormat    : LengthFormat.BCD
                                                                  )
                                                );

            //-----------------------------------------------------
            // Voucher Number 
            // Format           : BCD
            // Length Type      : DYNAMIC
            // Length           : MAX Value is 4
            // Length Format    : BCD

            //-----------------------------------------------------

            Voucher_Number = new FieldElement(
                                               "Voucher_Number"     ,
                                               FieldType.BCD        ,
                                               new LengthType(
                                                                   type             : EnumLengthType    .DYNAMIC                ,
                                                                   length           : Constantes        .VOUCHER_LEN            ,
                                                                   lengthFormat     : LengthFormat      .BCD
                                                              )
                                               );

            //-----------------------------------------------------
            // Autorization Code  
            // Format           : ANS
            // Length Type      : DYNAMIC
            // Length           : MAX Value is 6
            // Length Format    : BCD
            //-----------------------------------------------------

            Authorization_Code = new FieldElement(
                                                "Authorization_Code",
                                                FieldType.BCD       ,
                                                new LengthType(
                                                                   type             : EnumLengthType    .DYNAMIC                ,
                                                                   length           : Constantes        .VOUCHER_LEN            ,
                                                                   lengthFormat     : LengthFormat      .BCD
                                                              )
                                               );

            //-----------------------------------------------------
            // Autorization Code  
            // Format           : ANS
            // Length Type      : DYNAMIC
            // Length           : MAX Value is 6
            // Length Format    : BCD

            //-----------------------------------------------------

            TransactionType = new FieldElement(
                                                "TransactionType"   ,
                                                FieldType.BCD       ,
                                                new LengthType(
                                                                   type             : EnumLengthType    .FIXED                  ,
                                                                   length           : Constantes        .TRAN_TYPE_LEN          ,
                                                                   lengthFormat     : LengthFormat      .BCD
                                                              )
                                               );


            //-----------------------------------------------------
            // Amount 
            // Format           : HEX
            // Length Type      : FIXED
            // Length           : 4
            // Length Format    : BCD

            //-----------------------------------------------------

            Amount = new FieldElement(
                                                "Amount"        ,
                                                FieldType.HEX   ,
                                                new LengthType  (
                                                                   type             : EnumLengthType    .FIXED                  ,
                                                                   length           : Constantes        .AMOUNT_LEN             ,
                                                                   lengthFormat     : LengthFormat      .HEX
                                                            )
                                    );

            Amount.LengthType.CharToFill        = '0';
            Amount.LengthType.FillToTheLeft     = true;

            //-----------------------------------------------------
            // Cashback Amount 
            // Format           : HEX
            // Length Type      : FIXED
            // Length           : 4
            // Length Format    : BCD

            //-----------------------------------------------------

            Cashback_Amount = new FieldElement(
                                                "Cashback_Amount",
                                                FieldType.HEX,
                                                new LengthType(
                                                                   type             : EnumLengthType    .FIXED                  ,
                                                                   length           : Constantes        .AMOUNT_LEN             ,
                                                                   lengthFormat     : LengthFormat      .HEX
                                                              )
                                               );

            Cashback_Amount.LengthType.CharToFill       = '0';
            Cashback_Amount.LengthType.FillToTheLeft    = true;

            //-----------------------------------------------------
            // Tip Amount 
            // Format           : HEX
            // Length Type      : FIXED
            // Length           : 4
            // Length Format    : BCD

            //-----------------------------------------------------

            Tip_Amount = new FieldElement(
                                                "Tip_Amount",
                                                FieldType.HEX,
                                                new LengthType(
                                                                   type             : EnumLengthType    .FIXED                  ,
                                                                   length           : Constantes        .AMOUNT_LEN             ,
                                                                   lengthFormat     : LengthFormat      .HEX
                                                              )
                                        );

            Tip_Amount.LengthType.CharToFill        = '0';
            Tip_Amount.LengthType.FillToTheLeft     = true;

            //-----------------------------------------------------
            // Amount  USD
            // Format           : HEX
            // Length Type      : FIXED
            // Length           : 4
            // Length Format    : BCD

            //-----------------------------------------------------

            Amount_USD = new FieldElement(
                                                "Amount_USD",
                                                FieldType.HEX,
                                                new LengthType(
                                                                   type             : EnumLengthType    .FIXED                  ,
                                                                   length           : Constantes        .AMOUNT_LEN             ,
                                                                   lengthFormat     : LengthFormat      .HEX
                                                              )
                                               );

            Amount_USD.LengthType.CharToFill        = '0';
            Amount_USD.LengthType.FillToTheLeft     = true;

            //-----------------------------------------------------
            // Cashback Amount  USD
            // Format           : HEX
            // Length Type      : FIXED
            // Length           : 4
            // Length Format    : BCD

            //-----------------------------------------------------

            Cashback_Amount_USD = new FieldElement(
                                                "Cashback_Amount_USD"   ,
                                                FieldType.HEX           ,
                                                new LengthType(
                                                                   type             : EnumLengthType    .FIXED                  ,
                                                                   length           : Constantes        .AMOUNT_LEN             ,
                                                                   lengthFormat     : LengthFormat      .HEX
                                                              )
                                               );

            Cashback_Amount_USD.LengthType.CharToFill       = '0';
            Cashback_Amount_USD.LengthType.FillToTheLeft    = true;

            //-----------------------------------------------------
            // Tip Amount USD
            // Format           : HEX
            // Length Type      : FIXED
            // Length           : 4
            // Length Format    : BCD
            //-----------------------------------------------------

            Tip_Amount_USD = new FieldElement(
                                                "Tip_Amount_USD"    ,
                                                FieldType.HEX       ,
                                                new LengthType(
                                                                   type             : EnumLengthType    .FIXED                  ,
                                                                   length           : Constantes        .AMOUNT_LEN             ,
                                                                   lengthFormat     : LengthFormat      .HEX
                                                              )
                                               );


            Tip_Amount_USD.LengthType.CharToFill        = '0';
            Tip_Amount_USD.LengthType.FillToTheLeft     = true;

            //-----------------------------------------------------
            // Currency Index
            // Format           : HEX
            // Length Type      : FIXED
            // Length           : 1
            // Length Format    : BCD
            //-----------------------------------------------------

            Currency_Index = new FieldElement(
                                                "Currency_Index", 
                                                FieldType.HEX,
                                                new LengthType(
                                                                   type             : EnumLengthType    .FIXED                  ,
                                                                   length           : Constantes        .CURRENCY_LEN           ,
                                                                   lengthFormat     : LengthFormat      .BCD
                                                              )
                                            );


            //-----------------------------------------------------
            // Merchant Decision
            // Format           : HEX
            // Length Type      : FIXED
            // Length           : 1
            // Length Format    : BCD
            //-----------------------------------------------------

            Merchant_Decision = new FieldElement(
                                                "Merchant_Decision" ,
                                                FieldType.HEX       ,
                                                new LengthType(
                                                                   type             : EnumLengthType    .FIXED                  ,
                                                                   length           : Constantes        .MERCHANT_DECISION_LEN  ,
                                                                   lengthFormat     : LengthFormat      .BCD
                                                              )
                                               );

            //-----------------------------------------------------
            // ECR ID & POS SerialNumber
            // Format           : ANS
            // Length Type      : VARIABLE
            // Length           : Max 42
            // Length Format    : BCD
            //-----------------------------------------------------

            ECRID_POSSerialNumber = new FieldElement(
                                                "ECRID_POSSerialNumber" ,
                                                FieldType.ANS           ,
                                                new LengthType(
                                                                   type             : EnumLengthType    .DYNAMIC                ,
                                                                   length           : Constantes        .ECR_ID_LEN             ,
                                                                   lengthFormat     : LengthFormat      .BCD
                                                              )
                                               );


            //-----------------------------------------------------
            // EMV Data
            // Format           : HEX
            // Length Type      : VARIABLE
            // Length           : Max 42
            // Length Format    : BCD
            //-----------------------------------------------------

            EMV_Data = new FieldElement(
                                                "EMV_Data"      ,
                                                FieldType.HEX   ,
                                                new LengthType(
                                                                   type             : EnumLengthType    .DYNAMIC            ,
                                                                   length           : Constantes        .EMV_DATA_LEN       ,
                                                                   lengthFormat     : LengthFormat      .BCD
                                                              )
                                               );


            //-----------------------------------------------------
            // Elementos por defecto en nuestra lista 
            //-----------------------------------------------------
            Elements = new List<FieldElement>()
            {
                TransactionDate         , 
                TransactionTime         , 
                Voucher_Number          ,    
                Authorization_Code      , 
                Amount                  , 
                Cashback_Amount         , 
                Tip_Amount              , 
                Amount_USD              , 
                Cashback_Amount_USD     , 
                Tip_Amount_USD          , 
                Currency_Index          , 
                Merchant_Decision       , 
                ECRID_POSSerialNumber   ,
                EMV_Data
            };
        }


    }
}
