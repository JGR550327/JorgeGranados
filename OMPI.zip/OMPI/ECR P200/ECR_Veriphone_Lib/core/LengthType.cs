﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECR_Veriphone_Lib.core
{
    public class LengthType 
    {
        

        /// <summary>
        /// 0-> Dynamic 
        /// x -> Cualquier otro valor mayor a cero
        /// </summary>
        public int              Length          { get; set; }

        public EnumLengthType   ELengthType     { get; set; }

        public LengthFormat     LengthFormat    { get; set; }

        public char             CharToFill      { get; set; }

        public bool             FillToTheLeft   { get; set; }  

        public LengthType   (  
                                EnumLengthType  type            ,  int length, 
                                LengthFormat    lengthFormat
                            ) 
        {
            this.ELengthType    = type          ;
            this.Length         = length        ;
            this.LengthFormat   = lengthFormat  ;
            CharToFill          = '_'           ; //This means no char to fill with 
            FillToTheLeft       = false         ;
        }

         public LengthType   (  
                                EnumLengthType  type            ,  int  length      , 
                                LengthFormat    lengthFormat    ,  char charToFill  , 
                                bool            fillToTheLeft
                            ) 
        {
            this.ELengthType    = type          ;
            this.Length         = length        ;
            this.LengthFormat   = lengthFormat  ;
            this.CharToFill     = charToFill    ;
            this.FillToTheLeft  = fillToTheLeft ;
        }

    }
   
}
