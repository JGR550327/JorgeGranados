﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECR_Veriphone_Lib.core
{
    public enum OperationResult
    {
        Sucess                          =   0, 
        Invalid                         =   2, 
        Timeout                         =   6,
        Cancel                          =   8,
        ICC_Failed                      =   10, // Falla en la lectura del chip
        InputedCard                     =   20, // Tarjeta Digitada
        Use_MagCard                     =   21, // Use banda magnética
        Contactless                     =   22,  
        RemovedCard                     =   23,
        NotSupportedCard                =   25, // Tarjeta no soportada
        InvalidApp                      =   26, //Aplicación inválida
        InvalidCardOperator             =   27, //Tarjeta Operador inválida 
        ExpiredDate                     =   29,  //Tarj con fecha vencimiento expirada 
        InvalidDate                     =   30, // Fecha Inválida 
        NotMatchedCRC                   =   50, // CRC no coincide. 
        IncorrectCheckValue             =   51, // Check Value incorrecto
        KeyNotExist                     =   52, 
        HSMCripto                       =   53,
        CipherExceededLimit             =   54, 
        InvalidSignature                =   55,
        TelechargeInvalidLength         =   56,
        CommandNotAllowed               =   60, 
        InitializedKeyCMDNotRecognized  =   61, 
        InitKeyNotPerformed             =   62, 
        ReadingError                    =   63, 
        CardNotMatchedTryAgain          =   64,
        InvalidDataForCipher            =   65, 
        OtherFailureCancelFromPinpad    =   99
           
    }
}
