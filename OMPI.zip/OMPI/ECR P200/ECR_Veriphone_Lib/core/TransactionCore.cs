﻿using ECR_Veriphone_Lib.util;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECR_Veriphone_Lib.core
{
    /// <summary>
    /// Class       : TransactionCore
    /// Description : Contiene todas las propiedades y funciones para llevar a cabo una transacción con la terminal. 
    /// Author      : Carlos Mejía
    /// Date        : 14 Marzo, 2021
    /// </summary>
    public class TransactionCore
    {

        private static readonly ILog log = LogManager.GetLogger(typeof(TransactionCore));

        #region "Propiedades"


        public Journal Request { get; set; }

        public Journal Response { get; set; }

        public bool Success { get; set; }

        public byte[] RequestBytes { get; set; }

        public byte[] ResponseBytes { get; set; }

        public bool SendACK { get; set; }
        /// <summary>
        /// Indica el tiempo de espera para cortar la comunicación con la terminal PAX
        /// </summary>
        public int Timeout { get; set; }


        public bool StopOnACK { get; set; }


        public Boolean IncluirTimeout { get; set; }

        private byte[] transactionDate;
        private byte[] transactionTime;
        private byte[] transactionType;
        private byte[] voucherNumber;
        private byte[] authorizationCode;
        private byte[] amount;
        private byte[] cashback_amount;
        private byte[] tip_amount;
        private byte[] amount_usd;
        private byte[] cashback_amount_usd;
        private byte[] tip_amount_usd;
        private byte[] currency_index;
        private byte[] erc_serial;
        private byte[] emv_tags;
        private byte[] currency_code;

        public byte[] ResponseCode;
        public byte[] StatusCode;
        public byte[] IssuerAuthenticationData;
        public byte[] E2;
        public byte[] ET; //utilizado para actualizaci'on de bines 

        public String displayText       ;
        public String binTableID        ;

        public byte[] cardNumber        ;

        public byte[] operatorName      ;

        public byte[] reference         ;

        public byte[] idSucursal        ;

        public byte[] idCaja            ;

        public byte[] posSerial         ;

        public bool cifrarPagosTajeta = false; 



        public Boolean EnmascararPAN = true;


        public bool verifyCheckSum = false;

        //-----------------------------------------------------
        // Transaction Date   YYMMDD
        // Format           : BCD
        // Length Type      : FIXED
        // Length           : 3
        // Length Format    : BCD     
        //-----------------------------------------------------

        public void setTransactionDate(String theDate)
        {
            byte[] dataOut = new byte[] { Instructions.C1_Tags };

            if (theDate.Length > 6)
            {
                theDate = theDate.Substring(0, 6);
            }


            byte[] bcdDate = Utilidad.ASCII_To_BCD(
                                                ASCIIEncoding.ASCII.GetBytes(theDate)
                                            );

            byte[] lengthBytes = Utilidad.Str2bcd(bcdDate.Length.ToString("00"), false);

            dataOut = Utilidad.ConcatVar(dataOut,
                                            lengthBytes,
                                            bcdDate
                                            );
            transactionDate = dataOut;


        }

        public byte[] getTransactionDate()
        {
            return transactionDate;
        }


        //-----------------------------------------------------
        // Transaction Time  HHMMSS
        // Format           : BCD
        // Length Type      : FIXED
        // Length           : 3
        // Length Format    : BCD
        //-----------------------------------------------------
        public void setTransactionTime(String theTime)
        {
            byte[] dataOut = new byte[] { Instructions.C1_Tags };

            if (theTime.Length > 6)
            {
                theTime = theTime.Substring(0, 6);
            }


            byte[] bcdDate = Utilidad.ASCII_To_BCD(
                                                ASCIIEncoding.ASCII.GetBytes(theTime)
                                            );

            byte[] lengthBytes = Utilidad.Str2bcd(bcdDate.Length.ToString("00"), false);

            dataOut = Utilidad.ConcatVar(dataOut,
                                            lengthBytes,
                                            bcdDate
                                            );
            transactionTime = dataOut;


        }

        public byte[] getCardNumber () 
        {
            return this.cardNumber;
        }

        public void setCardNumber(String pan) 
        {
            byte[] dataOut = new byte[] { Instructions.C1_Tags };


            byte[] panASCII = ASCIIEncoding.ASCII.GetBytes(pan);

            byte[] length = new byte[] { (byte)panASCII.Length };

            dataOut = Utilidad.ConcatVar(dataOut,
                                          length,
                                          panASCII
                                            );
            cardNumber = dataOut;
        }

        public byte[] getOperatorName()
        {
            return this.operatorName;
        }

        public void setOperatorName(String operador)
        {

            if (operador == null) 
            {
                operador = "";
            }

            if (operador.Length > 25) 
            {
                operador = operador.Substring(0, 25);
            }

            operador = Utilidad.FillStringWith(operador, '0', 25, true); 

            byte[] dataOut = new byte[] { Instructions.C1_Tags };

            byte[] operadorASCII = ASCIIEncoding.ASCII.GetBytes(operador);

            byte[] length = new byte[] { (byte)operadorASCII.Length };

            dataOut = Utilidad.ConcatVar(dataOut,
                                          length,
                                          operadorASCII
                                            );
            operatorName = dataOut;
        }


        public byte[] getReference()
        {
            return this.reference;
        }

        public void setReference(String data)
        {
            if (data == null)
            {
                data = "";
            }

            if (data.Length > 20)
            {
                data = data.Substring(0, 20);
            }


            data = Utilidad.FillStringWith(data, '0', 20, true);

            byte[] dataOut = new byte[] { Instructions.C1_Tags };

            byte[] dataASCII = ASCIIEncoding.ASCII.GetBytes(data);

            byte[] length = new byte[] { (byte)dataASCII.Length };

            dataOut = Utilidad.ConcatVar(dataOut,
                                          length,
                                          dataASCII
                                            );
            reference = dataOut;
        }



        public byte[] getIdSucursal()
        {
            return this.idSucursal;
        }

        public void setIdSucursal(String data)
        {
            if (data == null)
            {
                data = "";
            }

            if (data.Length > 12)
            {
                data = data.Substring(0, 12);
            }


            data = Utilidad.FillStringWith(data, '0', 12, true);

            byte[] dataOut = new byte[] { Instructions.C1_Tags };

            byte[] dataASCII = ASCIIEncoding.ASCII.GetBytes(data);

            byte[] length = new byte[] { (byte)dataASCII.Length };

            dataOut = Utilidad.ConcatVar(dataOut,
                                          length,
                                          dataASCII
                                            );
            idSucursal = dataOut;
        }



        public byte[] getIdCaja()
        {
            return this.idCaja;
        }

        public void setIdCaja(String data)
        {
            if (data == null)
            {
                data = "";
            }

            if (data.Length > 12)
            {
                data = data.Substring(0, 12);
            }


            data = Utilidad.FillStringWith(data, '0', 12, true);

            byte[] dataOut = new byte[] { Instructions.C1_Tags };

            byte[] dataASCII = ASCIIEncoding.ASCII.GetBytes(data);

            byte[] length = new byte[] { (byte)dataASCII.Length };

            dataOut = Utilidad.ConcatVar(dataOut,
                                          length,
                                          dataASCII
                                            );
            idCaja = dataOut;
        }


        public byte[] getPOSSerial()
        {
            return this.posSerial;
        }

        public void setPOSSerial(String data)
        {
            if (data == null)
            {
                data = "";
            }

            if (data.Length > 20)
            {
                data = data.Substring(0, 20);
            }


            data = Utilidad.FillStringWith(data, '0', 20, true);

            byte[] dataOut = new byte[] { Instructions.C1_Tags };

            byte[] dataASCII = ASCIIEncoding.ASCII.GetBytes(data);

            byte[] length = new byte[] { (byte)dataASCII.Length };

            dataOut = Utilidad.ConcatVar(dataOut,
                                          length,
                                          dataASCII
                                            );
            posSerial = dataOut;
        }




        public byte[] getCifrarPagosTarjetaCorresponsal()
        {
            byte[] data = null;

            if (cifrarPagosTajeta)
            {
                data = new byte[] { Instructions.C1_Tags, 0x01, 0x01 };
            }
            else 
            {
                data = new byte[] { Instructions.C1_Tags, 0x01, 0x00 };
            }

            return data;
        }

        public void setCifrarPagosTarjetaCorresponsal(bool data)
        {
            this.cifrarPagosTajeta = data;
        }
        public byte[] getTransactionTime()
        {
            return transactionTime;
        }


        public void setTransactionType(TransactionType type)
        {
            byte[] dataOut = new byte[] { Instructions.C1_Tags };


            byte[] bcdType = Utilidad.Str2bcd(((int)type).ToString("00"), false);

            dataOut = Utilidad.ConcatVar(dataOut,
                                          new byte[] { 0x01 },
                                          bcdType

                                            );
            transactionType = dataOut;
        }


        public void setTransactionType(byte trxType)
        {
            byte[] dataOut = new byte[] { Instructions.C1_Tags };


            byte[] bcdType = new byte[] { trxType }; 

            dataOut = Utilidad.ConcatVar(dataOut,
                                          new byte[] { 0x01 },
                                          bcdType

                                            );
            transactionType = dataOut;
        }


        public byte[] getTransactionType()
        {
            return transactionType;
        }


        //-----------------------------------------------------
        // Voucher Number 
        // Format           : BCD
        // Length Type      : DYNAMIC
        // Length           : MAX Value is 4
        // Length Format    : BCD
        //-----------------------------------------------------
        public void setVoucherNumber(String voucher)
        {
            byte[] dataOut = new byte[] { Instructions.C1_Tags };

            if (voucher.Length > 8)
            {
                voucher = voucher.Substring(0, 8);
            }
            else
            {
                voucher = Utilidad.FillStringWith(voucher, '0', 8, true);
            }


            byte[] bcdVoucher = Utilidad.ASCII_To_BCD(
                                                ASCIIEncoding.ASCII.GetBytes(voucher)
                                            );

            byte[] lengthBytes = Utilidad.Str2bcd(bcdVoucher.Length.ToString("00"), false);

            dataOut = Utilidad.ConcatVar(dataOut,
                                            lengthBytes,
                                            bcdVoucher
                                            );
            voucherNumber = dataOut;


        }

        public byte[] getVoucherNumber()
        {
            return voucherNumber;
        }

        //-----------------------------------------------------
        // Autorization Code  
        // Format           : ANS
        // Length Type      : DYNAMIC
        // Length           : MAX Value is 6
        // Length Format    : BCD
        //-----------------------------------------------------
        public void setAuthorizationCode(String authorizationCode)
        {
            byte[] dataOut = new byte[] { Instructions.C1_Tags };

            if (authorizationCode.Length > 6)
            {
                authorizationCode = authorizationCode.Substring(0, 6);
            }
            else
            {
                authorizationCode = Utilidad.FillStringWith(authorizationCode, '0', 6, true);
            }


            byte[] asciiAuth = ASCIIEncoding.ASCII.GetBytes(authorizationCode);


            byte[] lengthBytes = Utilidad.Str2bcd(asciiAuth.Length.ToString("00"), false);

            dataOut = Utilidad.ConcatVar(dataOut,
                                            lengthBytes,
                                            asciiAuth
                                            );
            this.authorizationCode = dataOut;


        }

        public byte[] getAuthorizationCode()
        {
            return authorizationCode;
        }

        public byte[] addChar(int times, byte theByte, byte[] source, bool left)
        {
            byte[] new_array = null;

            if (times > source.Length)
            {
                new_array = source;

                for (int i = 0; i < times - source.Length; i++)
                {
                    if (left)
                        new_array = Utilidad.ConcatVar(new byte[] { theByte }, new_array);
                    else
                        new_array = Utilidad.ConcatVar(new_array, new byte[] { theByte });
                }
            }
            else
            {
                new_array = source;
            }

            return new_array;
        }


        //-----------------------------------------------------
        // Amount  
        // Format           : ANS
        // Length Type      : DYNAMIC
        // Length           : MAX Value is 6
        // Length Format    : HEX
        //-----------------------------------------------------
        public void setAmount(String amount)
        {

            Utilidad.Init();

            byte[] dataOut = new byte[] { Instructions.C1_Tags };

            log.Info($"Monto = {amount}");

            amount = amount.Replace(",", "").Replace(".", "");

            if (amount.Length > 8)
            {
                amount = amount.Substring( amount.Length - 8, 8);
            }
            else
            {
                amount = Utilidad.FillStringWith(amount, '0', 8, true);
            }

            long number =  Convert.ToInt64(amount);



            String hexString = number.ToString("X8");

            byte[] hexValue = Utilidad.ASCII_To_BCD(
                                    ASCIIEncoding.ASCII.GetBytes(hexString)
                                  );

            hexValue = addChar(4, 0x00, hexValue, true);

            byte[] lengthBytes = Utilidad.Str2bcd(hexValue.Length.ToString("00"), false);

            dataOut = Utilidad.ConcatVar(
                                                dataOut,
                                                lengthBytes,
                                                hexValue
                                            );

            this.amount = dataOut;

            try
            {
                log.Info($"Monto = {Utilidad.Bcd2Str(dataOut)}");
            }
            catch (Exception ex) 
            {
                
            }
           


        }

        public byte[] getAmount()
        {
            return this.amount;
        }

        //-----------------------------------------------------
        // CashBack Amount  
        // Format           : ANS
        // Length Type      : DYNAMIC
        // Length           : MAX Value is 6
        // Length Format    : HEX
        //-----------------------------------------------------
        public void setCashback_Amount(String amount)
        {
            byte[] dataOut = new byte[] { Instructions.C1_Tags };

            amount = amount.Replace(",", "").Replace(".", "");

            if (amount.Length > 8)
            {
                amount = amount.Substring(amount.Length - 8, 8);
            }
            else
            {
                amount = Utilidad.FillStringWith(amount, '0', 8, true);
            }

            long number = Convert.ToInt64(amount);
            String hexString = number.ToString("X8");

            byte[] hexValue = Utilidad.ASCII_To_BCD(
                                    ASCIIEncoding.ASCII.GetBytes(hexString)
                                  );

            hexValue = addChar(4, 0x00, hexValue, true);

            byte[] lengthBytes = Utilidad.Str2bcd(hexValue.Length.ToString("00"), false);

            dataOut = Utilidad.ConcatVar(
                                                dataOut,
                                                lengthBytes,
                                                hexValue
                                            );

            this.cashback_amount = dataOut;

        }

        public byte[] getCashback_Amount()
        {
            return this.cashback_amount;
        }

        //-----------------------------------------------------
        // Tip Amount  
        // Format           : ANS
        // Length Type      : DYNAMIC
        // Length           : MAX Value is 6
        // Length Format    : HEX
        //-----------------------------------------------------
        public void setTip_Amount(String amount)
        {
            byte[] dataOut = new byte[] { Instructions.C1_Tags };

            amount = amount.Replace(",", "").Replace(".", "");

            if (amount.Length > 8)
            {
                amount = amount.Substring(amount.Length - 8, 8);
            }
            else
            {
                amount = Utilidad.FillStringWith(amount, '0', 8, true);
            }

            long number = Convert.ToInt64(amount);
            String hexString = number.ToString("X8");

            byte[] hexValue = Utilidad.ASCII_To_BCD(
                                    ASCIIEncoding.ASCII.GetBytes(hexString)
                                  );

            hexValue = addChar(4, 0x00, hexValue, true);

            byte[] lengthBytes = Utilidad.Str2bcd(hexValue.Length.ToString("00"), false);

            dataOut = Utilidad.ConcatVar(
                                                dataOut,
                                                lengthBytes,
                                                hexValue
                                            );

            this.tip_amount = dataOut;

        }

        public byte[] getTip_Amount()
        {
            return this.tip_amount;
        }

        //-----------------------------------------------------
        // Amount  
        // Format           : ANS
        // Length Type      : DYNAMIC
        // Length           : MAX Value is 6
        // Length Format    : HEX
        //-----------------------------------------------------
        public void setAmount_USD(String amount)
        {
            byte[] dataOut = new byte[] { Instructions.C1_Tags };

            if (amount.Length > 8)
            {
                amount = amount.Substring(amount.Length - 8, 8);
            }
            else
            {
                amount = Utilidad.FillStringWith(amount, '0', 8, true);
            }

            long number = Convert.ToInt64(amount);
            String hexString = number.ToString("X8");

            byte[] hexValue = Utilidad.ASCII_To_BCD(
                                    ASCIIEncoding.ASCII.GetBytes(hexString)
                                  );

            hexValue = addChar(4, 0x00, hexValue, true);

            byte[] lengthBytes = Utilidad.Str2bcd(hexValue.Length.ToString("00"), false);

            dataOut = Utilidad.ConcatVar(
                                                dataOut,
                                                lengthBytes,
                                                hexValue
                                            );

            this.amount_usd = dataOut;


        }

        public byte[] getAmount_USD()
        {
            return this.amount_usd;
        }

        //-----------------------------------------------------
        // CashBack Amount  
        // Format           : ANS
        // Length Type      : DYNAMIC
        // Length           : MAX Value is 6
        // Length Format    : HEX
        //-----------------------------------------------------
        public void setCashback_Amount_USD(String amount)
        {
            byte[] dataOut = new byte[] { Instructions.C1_Tags };

            amount = amount.Replace(",", "").Replace(".", "");

            if (amount.Length > 8)
            {
                amount = amount.Substring(amount.Length - 8, 8);
            }
            else
            {
                amount = Utilidad.FillStringWith(amount, '0', 8, true);
            }

            long number = Convert.ToInt64(amount);
            String hexString = number.ToString("X8");

            byte[] hexValue = Utilidad.ASCII_To_BCD(
                                    ASCIIEncoding.ASCII.GetBytes(hexString)
                                  );

            hexValue = addChar(4, 0x00, hexValue, true);

            byte[] lengthBytes = Utilidad.Str2bcd(hexValue.Length.ToString("00"), false);

            dataOut = Utilidad.ConcatVar(
                                                dataOut,
                                                lengthBytes,
                                                hexValue
                                            );

            this.cashback_amount_usd = dataOut;

        }

        public byte[] getCashback_Amount_USD()
        {
            return this.cashback_amount_usd;
        }

        //-----------------------------------------------------
        // Tip Amount  
        // Format           : ANS
        // Length Type      : DYNAMIC
        // Length           : MAX Value is 6
        // Length Format    : HEX
        //-----------------------------------------------------
        public void setTip_Amount_USD(String amount)
        {
            byte[] dataOut = new byte[] { Instructions.C1_Tags };

            amount = amount.Replace(",", "").Replace(".", "");

            if (amount.Length > 8)
            {
                amount = amount.Substring(amount.Length - 8, 8);
            }
            else
            {
                amount = Utilidad.FillStringWith(amount, '0', 8, true);
            }

            long number = Convert.ToInt64(amount);
            String hexString = number.ToString("X8");

            byte[] hexValue = Utilidad.ASCII_To_BCD(
                                    ASCIIEncoding.ASCII.GetBytes(hexString)
                                  );

            hexValue = addChar(4, 0x00, hexValue, true);

            byte[] lengthBytes = Utilidad.Str2bcd(hexValue.Length.ToString("00"), false);

            dataOut = Utilidad.ConcatVar(
                                                dataOut,
                                                lengthBytes,
                                                hexValue
                                            );

            this.tip_amount_usd = dataOut;

        }

        public byte[] getTip_Amount_USD()
        {
            return this.tip_amount_usd;
        }


        public void setCurrencyIndex(String index)
        {
            byte[] dataOut = new byte[] { Instructions.C1_Tags };

            if (index.Length > 2)
            {
                index = index.Substring(0, 2);
            }
            else
            {
                index = Utilidad.FillStringWith(index, '0', 2, true);
            }


            byte[] bcdIndex = Utilidad.ASCII_To_BCD(
                                                ASCIIEncoding.ASCII.GetBytes(index)
                                            );

            dataOut = Utilidad.ConcatVar(dataOut,
                                            new byte[] { 0x01 },
                                            bcdIndex
                                            );
            currency_index = dataOut;


        }

        public byte[] getCurrencyIndex()
        {
            return currency_index;
        }

        public byte[] getMerchantDecision()
        {

            if (amount == null)
            {
                return new byte[] { 0x01 };
            }

            if (amount.Length < 4)
            {
                return new byte[] { 0x01 };
            }

            if (amount[0] == 0x00 && amount[1] == 0x00 && amount[2] == 0x00 && amount[3] == 0x00)
            {
                return new byte[] { 0xC1, 0x01, 0x01 };
            }
            else
            {
                return new byte[] { 0xC1, 0x01, 0x00 };
            }
        }


        public void setECR_ID_SERIAL(String serial)
        {

            byte[] dataOut = new byte[] { Instructions.C1_Tags };

            if (serial.Length > 26)
            {
                serial = serial.Substring(0, 26);
            }

            byte[] asciiSerial = ASCIIEncoding.ASCII.GetBytes(serial);


            long number = Convert.ToInt64(asciiSerial.Length.ToString());

            String hexString = number.ToString("X2");

            byte[] hexValue = Utilidad.ASCII_To_BCD(
                                    ASCIIEncoding.ASCII.GetBytes(hexString)
                                  );

            byte[] lengthBytes = hexValue;

            dataOut = Utilidad.ConcatVar(dataOut,
                                            lengthBytes,
                                            asciiSerial
                                        );

            this.erc_serial = dataOut;
        }

        public byte[] getECR_ID_SERIAL()
        {
            return erc_serial;
        }

        byte[] ecr_id;

        public void setECRId(String serial)
        {

            byte[] dataOut = new byte[] { Instructions.C1_Tags };

            if (serial.Length > 10)
            {
                serial = serial.Substring(0, 10);
            }

            serial = Utilidad.FillStringWith(serial, '0', 10, true);

            byte[] asciiSerial = ASCIIEncoding.ASCII.GetBytes(serial);


            long number = Convert.ToInt64(asciiSerial.Length.ToString());

            String hexString = number.ToString("X2");

            byte[] hexValue = Utilidad.ASCII_To_BCD(
                                    ASCIIEncoding.ASCII.GetBytes(hexString)
                                  );

            byte[] lengthBytes = hexValue;

            dataOut = Utilidad.ConcatVar(dataOut,
                                            lengthBytes,
                                            asciiSerial
                                        );

            this.ecr_id = dataOut;
        }

        public byte[] getECRId()
        {
            return this.ecr_id;
        }

        public void setEmvTags(String tags)
        {
            byte[] dataOut = new byte[] { Instructions.E1_Token };

            byte[] bcdEmv = null;

            if (tags.Length > 0)
            {
                bcdEmv = Utilidad.ASCII_To_BCD(
                                                ASCIIEncoding.ASCII.GetBytes(tags)
                                            );
            }


            long number = Convert.ToInt64(bcdEmv == null ? "0" : bcdEmv.Length.ToString());

            String hexString = number.ToString("X2");

            byte[] hexValue = Utilidad.ASCII_To_BCD(
                                    ASCIIEncoding.ASCII.GetBytes(hexString)
                                  );

            byte[] lengthBytes = hexValue;


            //if (null != bcdEmv) { }
            dataOut = Utilidad.ConcatVar(
                                            dataOut,
                                            lengthBytes,
                                            bcdEmv
                                            );
            emv_tags = dataOut;


        }

        public byte[] getEmvTags()
        {
            return emv_tags;
        }


        #endregion

        #region Constructores


        public void Init()
        {
            Request = new Journal();
            Response = new Journal();

            Request.Init();
            Response.Init();
        }

        public TransactionCore()
        {

            Init();
            Success = false;
            SendACK = false;

        }

        public TransactionCore(bool includeDefaultElements, List<FieldElement> elements)
        {
            Success     = false;
            StopOnACK   = false;

            Init();

            if (includeDefaultElements)
            {
                Request.Elements.AddRange(elements);
                Response.Elements.AddRange(elements);
            }
            else
            {
                Request.Elements = elements;
                Response.Elements = elements;
            }

        }

        #endregion

        #region "funciones"

        public byte[] getTimeout()
        {

            byte[] dataOut = null;

            byte[] bcdTimeout = Utilidad.Str2bcd((Timeout / 1000).ToString(), true);

            byte[] lengthBytes = new byte[] { 0x01 };

            dataOut = Utilidad.ConcatVar(dataOut,
                                            new byte[] { Instructions.C1_Tags },
                                            lengthBytes,
                                            bcdTimeout
                                            );

            return dataOut;

        }

        public void setCurrencyCode(String currencyCode)
        {

            byte[] dataOut = null;

            byte[] bcdCurrencyCode = Utilidad.Str2bcd(currencyCode, true);

            byte[] lengthBytes = new byte[] { (byte)bcdCurrencyCode.Length };

            dataOut = Utilidad.ConcatVar(dataOut,
                                            new byte[] { Instructions.C1_Tags },
                                            lengthBytes,
                                            bcdCurrencyCode
                                            );

            this.currency_code = dataOut;

        }

        public byte[]   getCurrencyCode                 (                           )
        {
            return this.currency_code;
        }

        public byte[]   getStatusCode                   (                           ) 
        {
            return StatusCode;
        }

        public void     setStatusCode                   (   HostStatus result       ) 
        {
            byte[] dataOut = null;

            int iResult = (int)result;

            byte[] bcdStatusCode    = Utilidad.Str2bcd(iResult.ToString("00"), true);

            byte[] lengthBytes      = new byte[] { (byte)bcdStatusCode.Length };

            dataOut = Utilidad.ConcatVar(dataOut,
                                            new byte[] { Instructions.C1_Tags },
                                            lengthBytes,
                                            bcdStatusCode
                                            );

            this.StatusCode = dataOut;
        }

        public byte[]   getResponseCode                 (                           )
        {
            return ResponseCode;
        }

        public void     setResponseCode                 (   String response         )
        {
            byte[] dataOut = null;

            byte[] asciiResponseCode = ASCIIEncoding.ASCII.GetBytes(response);

            byte[] lengthBytes = new byte[] { (byte)asciiResponseCode.Length };

            dataOut = Utilidad.ConcatVar(dataOut,
                                            new byte[] { Instructions.C1_Tags },
                                            lengthBytes,
                                            asciiResponseCode
                                            );

            this.ResponseCode = dataOut;
        }


        public byte[]   getIssuerAuthenticationData     (                           )
        {
            return IssuerAuthenticationData;
        }

        public void     setIssuerAuthenticationData     (   String data             )
        {
            byte[] dataOut = null;

            byte[] bcdIssuerData = null;

            if (null != data && data.Length > 0)
            {
                bcdIssuerData = Utilidad.ASCII_To_BCD(ASCIIEncoding.ASCII.GetBytes(data));
            }

            byte[] lengthBytes = new byte[] { (bcdIssuerData != null ? (byte)bcdIssuerData.Length : (byte) 0) };

            dataOut = Utilidad.ConcatVar(dataOut,
                                            new byte[] { Instructions.IssuerAD_Tags },
                                            lengthBytes,
                                            bcdIssuerData
                                            );

            this.IssuerAuthenticationData = dataOut;
        }

        public byte[]   getE2                           (                           )
        {
            return E2;
        }

        public void setE2                               (   String data             )
        {
            byte[] dataOut = null;

            byte[] bcdIssuerData = null; 

            if (null != data && data.Length > 0) 
            {
                bcdIssuerData = ASCIIEncoding.ASCII.GetBytes(data);
            }
           
            byte[] lengthBytes = new byte[] { (bcdIssuerData != null ? (byte)bcdIssuerData.Length : (byte) 0x00 )};

            dataOut = Utilidad.ConcatVar(dataOut,
                                            new byte[] { Instructions.E2_Token },
                                            lengthBytes,
                                            bcdIssuerData
                                            );

            this.E2 = dataOut;
        }


        public byte[] getDisplayText() 
        {
            byte[] text = null;

            if (this.displayText != null) 
            {
                text = ASCIIEncoding.ASCII.GetBytes(this.displayText);
            }

            return text;
        }

        public void setDisplayText(String text) 
        {
            this.displayText = text;
        }


        public byte[] getBinTableId()
        {
            byte[] text = null;

            if (this.binTableID != null)
            {
                text = ASCIIEncoding.ASCII.GetBytes(this.binTableID);
            }

            return text;
        }

        public void setBinTableId(String text)
        {
            this.binTableID = text;
        }


        public byte[] getET()
        {
            return ET;
        }

        public void setET(String data)
        {
            byte[] dataOut = null;

            byte[] bcdIssuerData = null;

            if (null != data && data.Length > 0)
            {
                bcdIssuerData =  ASCIIEncoding.ASCII.GetBytes(data);
            }

            //byte[] lengthBytes = new byte[] { (bcdIssuerData != null ? (byte)bcdIssuerData.Length : (byte)0x00) };

            dataOut = Utilidad.ConcatVar(dataOut,
                                           
                                            bcdIssuerData
                                            );

            this.ET = dataOut;
        }


        public void setET(String data, int maxLength, char fillWith, bool padLeft)
        {
            byte[] dataOut = null;

            byte[] bcdIssuerData = null;


            data = Utilidad.FillStringWith(data, fillWith, maxLength, padLeft); 

            if (null != data && data.Length > 0)
            {
                bcdIssuerData = ASCIIEncoding.ASCII.GetBytes(data);
            }

            //byte[] lengthBytes = new byte[] { (bcdIssuerData != null ? (byte)bcdIssuerData.Length : (byte)0x00) };

            dataOut = Utilidad.ConcatVar(   dataOut,
                                            bcdIssuerData
                                            );

            this.ET = dataOut;
        }



        byte[] empty_c1                     = new byte[] { Instructions.C1_Tags, 0x01, 0x00                     };

        byte[] empty_c1_amount              = new byte[] { Instructions.C1_Tags, 0x04, 0x00, 0x00, 0x00, 0x00   };

        byte[] default_c1_currency_index    = new byte[] { Instructions.C1_Tags, 0x01, 0x01                     };

        public byte[]                   BuildTags               (                                                               ) 
        {
            byte[] dataOut = null;

            //--------------------------------
            //incluir timeout
            //--------------------------------

            if (IncluirTimeout) 
            {
                dataOut = Utilidad.ConcatVar(dataOut, getTimeout() != null ? getTimeout() : empty_c1);
            }
            //--------------------------------
            //transaction date
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getTransactionDate    () != null ? getTransactionDate     () : empty_c1                   );

            //--------------------------------
            //transaction time
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getTransactionTime    () != null ? getTransactionTime     () : empty_c1                   );

            //--------------------------------
            //transaction type
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getTransactionType    () != null ? getTransactionType     () : empty_c1                   );

            //--------------------------------
            // voucher number
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getVoucherNumber      () != null ? getVoucherNumber       () : empty_c1                   );

            //--------------------------------
            // authorization code 
            //--------------------------------
            //if (null != getAuthorizationCode())
            {
                dataOut = Utilidad.ConcatVar(dataOut, getAuthorizationCode() != null ? getAuthorizationCode() : empty_c1);
            }

            //--------------------------------
            // amount
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getAmount             () != null ? getAmount              () : empty_c1_amount            );

            //--------------------------------
            // cash back
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getCashback_Amount    () != null ? getCashback_Amount     () : empty_c1_amount            );

            //--------------------------------
            // tip 
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getTip_Amount         () != null ? getTip_Amount          () : empty_c1_amount            );

            //--------------------------------
            // amount USD
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getAmount_USD         () != null ? getAmount_USD          () : empty_c1_amount            );

            //--------------------------------
            // cash back USD
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getCashback_Amount_USD() != null ? getCashback_Amount_USD () : empty_c1_amount            );

            //--------------------------------
            // tip USD
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getTip_Amount_USD     () != null ? getTip_Amount_USD      () : empty_c1_amount            );

            //--------------------------------
            // currecny index 
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getCurrencyIndex      () != null ? getCurrencyIndex       () : default_c1_currency_index  );

            //--------------------------------
            // Merchant Decision
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getMerchantDecision   ()                                                                  );


           // dataOut = Utilidad.ConcatVar(dataOut, new byte[] { 0xC1, 0x01, 0x00, 0xC1, 0x01, 0x00 });
           
            //--------------------------------
            // ECR id + serial 
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getECR_ID_SERIAL      () != null ? getECR_ID_SERIAL       () : empty_c1_amount            );

            //--------------------------------
            // E1
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getEmvTags            () != null ? getEmvTags             () : empty_c1                   );

            return dataOut;
        }

        public byte[]                   BuildTagsC51            (                                                               )
        {
            byte[] dataOut = null;

            //--------------------------------
            //incluir timeout
            //--------------------------------

            if (IncluirTimeout)
            {
                dataOut = Utilidad.ConcatVar(dataOut, getTimeout() != null ? getTimeout() : empty_c1);
            }
            //--------------------------------
            //transaction date
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getTransactionDate() != null ? getTransactionDate() : empty_c1);

            //--------------------------------
            //transaction time
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getTransactionTime() != null ? getTransactionTime() : empty_c1);

            //--------------------------------
            //transaction type
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getTransactionType() != null ? getTransactionType() : empty_c1);

            //--------------------------------
            // amount
            //--------------------------------

            try
            {
                log.Info(String.Format("getAmount = [{0}]", Utilidad.Bcd2Str(getAmount())));
            }
            catch (Exception ex) 
            {
            } 

            dataOut = Utilidad.ConcatVar(dataOut, getAmount() != null ? getAmount() : empty_c1_amount);

            //--------------------------------
            // cash back
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getCashback_Amount() != null ? getCashback_Amount() : empty_c1_amount);

          
            //--------------------------------
            // currecny index 
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getCurrencyCode() != null ? getCurrencyCode() : default_c1_currency_index);

            //--------------------------------
            // Merchant Decision  01 forzar en linea
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut,  new byte[] { 0xC1, 0x01, 0x01 });

           
            //--------------------------------
            // E1
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getEmvTags() != null ? getEmvTags() : empty_c1);

            
            dataOut = Utilidad.ConcatVar(dataOut, EnmascararPAN ? new byte[] { 0xC1, 0x01, 0x01 } : new byte[] { 0xC1, 0x01, 0x00 });
            
            return dataOut;
        }

        public byte[]                   BuildTagsC54            (                                                               )
        {
            byte[] dataOut = null;

           
            //--------------------------------
            //status code
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getStatusCode                 () != null ? getStatusCode              () : empty_c1       );

            //--------------------------------
            //authorization code 
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getAuthorizationCode          () != null ? getAuthorizationCode       () : empty_c1       );

            //--------------------------------
            //Response Code
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getResponseCode               () != null ? getResponseCode            () : empty_c1       );

            //--------------------------------
            // Issuer Authentication Data
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getIssuerAuthenticationData   () != null ? getIssuerAuthenticationData() : empty_c1       );

            //--------------------------------
            //transaction date
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getTransactionDate            () != null ? getTransactionDate         () : empty_c1       );

            //--------------------------------
            //transaction time
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getTransactionTime            () != null ? getTransactionTime         () : empty_c1       );

            //--------------------------------
            // E2 
            //--------------------------------
            dataOut = Utilidad.ConcatVar(dataOut, getE2                         () != null ? getE2                      () : empty_c1       );

          

            return dataOut;
        }


        public byte[]                   GetTag                  (   byte[] response, ref int index                              )
        {

            //----------------------
            // tag c1, e1, e2, etc
            //----------------------
            byte[] temp = new byte[1];

            Array.Copy(response, index, temp, 0, temp.Length);

            log.Info("Tag " + Utilidad.Bcd2Str(temp));

            index += temp.Length;


            //----------------------
            // tag length
            //----------------------

            int tagLen = response[index];

            log.Info("Length: " + tagLen.ToString());

            index += 1;

            //----------------------
            // tag value
            //----------------------
            temp = new byte[tagLen];

            Array.Copy(response, index, temp, 0, temp.Length);

            log.Info("Value BCD     " + Utilidad.Bcd2Str(temp));
            log.Info("Value ASCII   " + ASCIIEncoding.ASCII.GetString(temp));

            index += temp.Length;

            return temp;
        }


        /// <summary>
        /// Realiza un parsing de la respuesta que viene del POS 
        /// y pone los resultados en un objeto de tipo TransactionResult
        /// </summary>
        /// <param name="response"></param>
        /// <returns></returns>
        public TransactionResult        ParseResponseZ2         (   byte[] response)
        {
            TransactionResult result = new TransactionResult();

            int index = 0;

            log.Info("--------------------------------");
            log.Info("ParseResponse");
            log.Info("--------------------------------");

            try
            {


                //--------------------------------
                // Message Identifier 3 bytes ASCII
                //--------------------------------
                byte[] temp = new byte[3];
                System.Array.Copy(response, index, temp, 0, temp.Length);

             
                result.Identifier = ASCIIEncoding.ASCII.GetString(temp);

                log.Info("Identifier ASCII  : [" + result.Identifier + "]");

                index += temp.Length;

                //--------------------------------
                // Result 2 bytes ASCII
                //--------------------------------
                temp = new byte[2];
                System.Array.Copy(response, index, temp, 0, temp.Length);

                log.Info("Operation Result    : [" + Utilidad.Bcd2Str(temp) + "]");

                int iResult = 0;

                if (Int32.TryParse(ASCIIEncoding.ASCII.GetString(temp), out iResult))
                {
                    result.Result = (OperationResult)iResult;
                }

                index += temp.Length;

            }
            catch (Exception ex)
            {
                log.Error(ex);
                return result;
            }
            

            return result;
        }



        /// <summary>
        /// Realiza un parsing de la respuesta que viene del POS 
        /// y pone los resultados en un objeto de tipo TransactionResult
        /// </summary>
        /// <param name="response"></param>
        /// <returns></returns>
        public TransactionResult ParseResponseQ8(byte[] response)
        {
            TransactionResult result = new TransactionResult();

            int index = 0;

            log.Info("--------------------------------");
            log.Info("ParseResponse Q8");
            log.Info("--------------------------------");

            try
            {

                //--------------------------------
                // Message Identifier 3 bytes ASCII
                //--------------------------------
                byte[] temp = new byte[2];
                System.Array.Copy(response, index, temp, 0, temp.Length);

                result.Identifier = ASCIIEncoding.ASCII.GetString(temp);

                log.Info("Identifier ASCII  : [" + result.Identifier + "]");

                index += temp.Length;
            
                //--------------------------------
                //TOKENS
                //--------------------------------

                int tokens_len = response.Length - index;

                byte[] bToken = new byte[tokens_len];

                Array.Copy(response, index, bToken, 0, tokens_len);

                String strToken = ASCIIEncoding.ASCII.GetString(bToken);

                result.ES = strToken;
                
            }
            catch (Exception ex)
            {
                log.Error(ex);
                return result;
            }


            return result;
        }


        /// <summary>
        /// Realiza un parsing de la respuesta que viene del POS 
        /// y pone los resultados en un objeto de tipo TransactionResult
        /// </summary>
        /// <param name="response"></param>
        /// <returns></returns>
        public TransactionResult ParseResponseZ10(byte[] response)
        {
            TransactionResult result = new TransactionResult();

            int index = 0;

            log.Info("--------------------------------");
            log.Info("ParseResponse Z10");
            log.Info("--------------------------------");

            try
            {


                //--------------------------------
                // Message Identifier 3 bytes ASCII
                //--------------------------------
                byte[] temp = new byte[3];
                System.Array.Copy(response, index, temp, 0, temp.Length);

                result.Identifier = ASCIIEncoding.ASCII.GetString(temp);

                log.Info("Identifier ASCII  : [" + result.Identifier + "]");

                index += temp.Length;

                //--------------------------------
                // Result 2 bytes ASCII
                //--------------------------------
                temp = new byte[2];
                System.Array.Copy(response, index, temp, 0, temp.Length);

                log.Info("Operation Result    : [" + ASCIIEncoding.ASCII.GetString(temp) + "]");

                int iResult = 0;

                if (Int32.TryParse(ASCIIEncoding.ASCII.GetString(temp), out iResult))
                {
                    result.Result = (OperationResult)iResult;
                }

                index += temp.Length;

                //--------------------------------
                // Longitud 2 bytes HEX
                //--------------------------------
                temp = new byte[2];
                Array.Copy(response, index, temp, 0, temp.Length);

                log.Info("Len HEX    : [" + Utilidad.Bcd2Str(temp) + "]");

                index += temp.Length;

                int longitudTotal = Convert.ToInt32(Utilidad.Bcd2Str(temp), 16);


                //--------------------------------
                //TOKENS
                //--------------------------------

                int tokens_len  = response.Length - index;

                byte[] bToken   = new byte[tokens_len];

                Array.Copy(response, index, bToken, 0, tokens_len);

                String strToken = ASCIIEncoding.ASCII.GetString(bToken);

                if (null != strToken && strToken.Length > 0)
                {
                    String[] tokenArray = strToken.Split('!');

                    foreach (String token in tokenArray)
                    {
                        if (null != token && token.Trim().Length > 0)
                        {
                            if (token.Trim().StartsWith("ES"))
                            {
                                result.ES = token.TrimStart();
                                continue;
                            }

                            if (token.Trim().StartsWith("EW"))
                            {
                                result.EW = token.TrimStart();
                                continue;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex);
                return result;
            }


            return result;
        }

        /// <summary>
        /// Realiza un parsing de la respuesta que viene del POS 
        /// y pone los resultados en un objeto de tipo TransactionResult
        /// </summary>
        /// <param name="response"></param>
        /// <returns></returns>
        public TransactionResult ParseResponseC11(byte[] response)
        {
            TransactionResult result = new TransactionResult();

            int index = 0;

            log.Info("--------------------------------");
            log.Info("ParseResponse C11");
            log.Info("--------------------------------");

            try
            {


                //--------------------------------
                // Message Identifier 3 bytes ASCII
                //--------------------------------
                byte[] temp = new byte[3];
                System.Array.Copy(response, index, temp, 0, temp.Length);

                result.Identifier = ASCIIEncoding.ASCII.GetString(temp);

                log.Info("Identifier ASCII  : [" + result.Identifier + "]");

                index += temp.Length;

                //--------------------------------
                // Result 2 bytes ASCII
                //--------------------------------
                temp = new byte[2];
                System.Array.Copy(response, index, temp, 0, temp.Length);

                log.Info("Operation Result    : [" + ASCIIEncoding.ASCII.GetString(temp) + "]");

                int iResult = 0;

                if (Int32.TryParse(ASCIIEncoding.ASCII.GetString(temp), out iResult))
                {
                    result.Result = (OperationResult)iResult;
                }

                index += temp.Length;

                //--------------------------------
                // Longitud 2 bytes HEX
                //--------------------------------
                temp = new byte[2];
                Array.Copy(response, index, temp, 0, temp.Length);

                log.Info("Len HEX    : [" + Utilidad.Bcd2Str(temp) + "]");

                index += temp.Length;

                int longitudTotal = Convert.ToInt32(Utilidad.Bcd2Str(temp), 16);


                //--------------------------------
                //TOKENS
                //--------------------------------

                int tokens_len = response.Length - index;

                byte[] bToken = new byte[tokens_len];

                Array.Copy(response, index, bToken, 0, tokens_len);

                String strToken = ASCIIEncoding.ASCII.GetString(bToken);

                if (null != strToken && strToken.Length > 0)
                {
                    String[] tokenArray = strToken.Split('!');

                    foreach (String token in tokenArray)
                    {
                        if (null != token && token.Trim().Length > 0)
                        {
                            if (token.Trim().StartsWith("ES"))
                            {
                                result.ES = token.TrimStart();
                                continue;
                            }

                            if (token.Trim().StartsWith("R1"))
                            {
                                result.R1 = token.TrimStart();
                                continue;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex);
                return result;
            }


            return result;
        }




        /// <summary>
        /// Realiza un parsing de la respuesta que viene del POS 
        /// y pone los resultados en un objeto de tipo TransactionResult
        /// </summary>
        /// <param name="response"></param>
        /// <returns></returns>
        public TransactionResult        ParseResponse           (   byte[] response                                             )
        {
            TransactionResult result = new TransactionResult();

            int index = 0;

            log.Info("--------------------------------");
            log.Info("ParseResponse");
            log.Info("--------------------------------");

            try
            {


                //--------------------------------
                // Message Identifier 3 bytes ASCII
                //--------------------------------
                byte[] temp = new byte[3];
                System.Array.Copy(response, index, temp, 0, temp.Length);

                log.Info("Identifier BCD    : [" + Utilidad.Bcd2Str(temp) + "]");

                result.Identifier = ASCIIEncoding.ASCII.GetString(temp);

                log.Info("Identifier ASCII  : [" + result.Identifier + "]");

                index += temp.Length;

                //--------------------------------
                // Result 2 bytes ASCII
                //--------------------------------
                temp = new byte[2];
                System.Array.Copy(response, index, temp, 0, temp.Length);

                log.Info("Operation Result    : [" + Utilidad.Bcd2Str(temp) + "]");

                int iResult = 0;

                if (Int32.TryParse(ASCIIEncoding.ASCII.GetString(temp), out iResult))
                {
                    result.Result = (OperationResult)iResult;
                }

                index += temp.Length;


                //--------------------------------
                // Longitud 2 bytes HEX
                //--------------------------------
                temp = new byte[2];
                Array.Copy(response, index, temp, 0, temp.Length);

                log.Info("Len HEX    : [" + Utilidad.Bcd2Str(temp) + "]");

                index += temp.Length;

                int longitudTotal = Convert.ToInt32(Utilidad.Bcd2Str(temp), 16);


                //--------------------------------
                // C1 - Host Response Code ASCII
                //--------------------------------
                log.Info("C1 - Host Response Code ASCII");
                temp = GetTag(response, ref index);

                if (null != temp)
                {
                    result.HostResponse = Utilidad.Bcd2Str(temp);
                }

                //--------------------------------
                // C1 - Authorization Code ASCII
                //--------------------------------
                log.Info("C1 - Authorization Code ASCII");
                temp = GetTag(response, ref index);

                if (null != temp)
                {
                    result.AuthorizationCode = ASCIIEncoding.ASCII.GetString(temp);
                }

                //--------------------------------
                // C1 - Response Code ASCII
                //--------------------------------
                log.Info("C1 - Response Code ASCII");
                temp = GetTag(response, ref index);

                if (null != temp)
                {
                    result.ResponseCode = ASCIIEncoding.ASCII.GetString(temp);
                }

                //--------------------------------
                // C1 - Transaction Date BCD
                //--------------------------------
                log.Info("C1 - Transaction Date BCD");
                temp = GetTag(response, ref index);

                if (null != temp)
                {
                    result.TransactionDate = Utilidad.Bcd2Str(temp);
                }

                //--------------------------------
                // C1 - Transaction Time BCD
                //--------------------------------
                log.Info("C1 - Transaction Time BCD");
                temp = GetTag(response, ref index);

                if (null != temp)
                {
                    result.TransactionTime = Utilidad.Bcd2Str(temp);
                }

                //--------------------------------
                // C1 - CardNumber BCD
                //--------------------------------
                log.Info(" C1 - CardNumber BCD");
                temp = GetTag(response, ref index);

                if (null != temp)
                {
                    result.CardNumber = Utilidad.Bcd2Str(temp);
                }

                //--------------------------------
                // C1 - CardHolderName ASCII
                //--------------------------------
                log.Info(" C1 - CardHolderName ASCII");
                temp = GetTag(response, ref index);

                if (null != temp)
                {
                    result.CardHolderName = ASCIIEncoding.ASCII.GetString(temp);
                }


                //--------------------------------
                // C1 - CardEntryMode ASCII
                //--------------------------------
                log.Info(" C1 - CardEntryMode ASCII");
                temp = GetTag(response, ref index);

                if (null != temp && temp.Length > 0)
                {
                    int entryMode = Convert.ToInt32(ASCIIEncoding.ASCII.GetString(temp));
                    result.EntryMode = (CardEntryMode)entryMode;
                }

                //--------------------------------
                // C1 - Voucher  ASCII
                //--------------------------------
                log.Info(" C1 - Voucher ASCII");
                temp = GetTag(response, ref index);

                if (null != temp)
                {
                    result.VoucherNumber = Utilidad.Bcd2Str(temp);
                }

                //--------------------------------
                // C1 - CardType  ASCII
                //--------------------------------
                log.Info(" C1 - CardType BCD");
                temp = GetTag(response, ref index);

                if (null != temp && temp.Length > 0)
                {
                    int cType = Convert.ToInt32(Utilidad.Bcd2Str(temp));
                    result.CardType = (CardType)cType;
                }

                //--------------------------------
                // C1 - CurrencyCode  BCD
                //--------------------------------
                log.Info(" C1 - CurrencyCode BCD");
                temp = GetTag(response, ref index);

                if (null != temp)
                {
                    result.CurrencyCode = Utilidad.Bcd2Str(temp);
                }

                //--------------------------------
                // C1 - Amount  BCD
                //--------------------------------
                log.Info(" C1 - Amount BCD");
                temp = GetTag(response, ref index);

                if (null != temp)
                {
                    result.AmountAuthorized = Utilidad.Bcd2Str(temp);
                }

                //--------------------------------
                // C1 - Software Verson  ASCII
                //--------------------------------
                log.Info(" C1 - Software Version ASCII");
                temp = GetTag(response, ref index);

                if (null != temp)
                {
                    result.SoftwareVersion = ASCIIEncoding.ASCII.GetString(temp);
                }

                //--------------------------------
                // C1 - Serial  ASCII
                //--------------------------------
                log.Info(" C1 - Serial ASCII");
                temp = GetTag(response, ref index);

                if (null != temp)
                {
                    result.SerialNumber = ASCIIEncoding.ASCII.GetString(temp);
                }

                //--------------------------------
                // C1 - ECR + POS SERIAL ASCII
                //--------------------------------
                log.Info(" C1 - ECR + SERIAL ASCII");
                temp = GetTag(response, ref index);

                if (null != temp)
                {
                    result.ECR_ID_SERIAL = ASCIIEncoding.ASCII.GetString(temp);
                }

                //--------------------------------
                // E1 - EMV BCD
                //--------------------------------

                log.Info(" E1 - EVM TAGs BCD");
                temp = GetTag(response, ref index);

                if (null != temp && temp.Length > 0)
                {
                    result.E1 = temp;
                }

                //--------------------------------
                // E2 - EMV BCD
                //--------------------------------

                log.Info(" E2 - EMV BCD");
                temp = GetTag(response, ref index);

                if (null != temp && temp.Length > 0)
                {
                    result.E2 = temp;
                }


                log.Info(result.ToString());

            }
            catch (Exception ex)
            {
                log.Error(ex);
                return result;
            }
            /*
            *done dynamically
            * 
            int innerIndex = 0;

            while (true)
            {

                if (innerIndex == longitudTotal)
                {
                    break;
                }

                if (response.Length > index)
                {
                   //----------------------
                   // tag c1, e1, e2, etc
                   //----------------------
                   temp = new byte[1];

                   Array.Copy(response, index, temp, 0, temp.Length);

                   log.Info("Tag " + ASCIIEncoding.ASCII.GetString(temp));

                   index       += temp.Length;
                   innerIndex  += temp.Length;

                   //----------------------
                   // tag length
                   //----------------------

                   int tagLen = response[index];

                   log.Info("Length: " + tagLen.ToString());

                   index       += 1;
                   innerIndex  += 1;
                   //----------------------
                   // tag value
                   //----------------------
                    temp = new byte[tagLen];

                    Array.Copy(response, index, temp, 0, temp.Length);

                    log.Info("Value BCD     " + Utilidad.Bcd2Str(temp));
                    log.Info("Value ASCII   " + ASCIIEncoding.ASCII.GetString(temp));

                    index       += temp.Length;
                    innerIndex  += temp.Length;
                }
               

            }*/

            return result;
        }

        /// <summary>
        /// Realiza un parsing de la respuesta que viene del POS 
        /// y pone los resultados en un objeto de tipo TransactionResult
        /// </summary>
        /// <param name="response"></param>
        /// <returns></returns>
        public TransactionResult        ParseResponseC53        (   byte[] response                                             )
        {
            TransactionResult result = new TransactionResult();

            int index = 0;

            log.Info("--------------------------------");
            log.Info("ParseResponse C53");
            log.Info("--------------------------------");

            try
            {


                //--------------------------------
                // Message Identifier 3 bytes ASCII
                //--------------------------------
                byte[] temp = new byte[3];
                System.Array.Copy(response, index, temp, 0, temp.Length);

                log.Info("Identifier BCD    : [" + Utilidad.Bcd2Str(temp) + "]");

                result.Identifier = ASCIIEncoding.ASCII.GetString(temp);

                log.Info("Identifier ASCII  : [" + result.Identifier + "]");

                index += temp.Length;

                //--------------------------------
                // Result 2 bytes ASCII
                //--------------------------------
                temp = new byte[2];
                System.Array.Copy(response, index, temp, 0, temp.Length);

                log.Info("Operation Result    : [" + Utilidad.Bcd2Str(temp) + "]");

                int iResult = 0;

                if (Int32.TryParse(ASCIIEncoding.ASCII.GetString(temp), out iResult))
                {
                    result.Result = (OperationResult)iResult;
                }

                index += temp.Length;


                //--------------------------------
                // Longitud 2 bytes HEX
                //--------------------------------
                temp = new byte[2];
                Array.Copy(response, index, temp, 0, temp.Length);

                log.Info("Len HEX    : [" + Utilidad.Bcd2Str(temp) + "]");

                index += temp.Length;

                int longitudTotal = Convert.ToInt32(Utilidad.Bcd2Str(temp), 16);


                //--------------------------------
                // C1 - Host Response Code ASCII
                //--------------------------------
                log.Info("C1 - PAN BCD");
                temp = GetTag(response, ref index);

                if (null != temp && temp.Length > 0)
                {
                    result.CardNumber = Utilidad.Bcd2Str(temp);
                    result.CardNumber = result.CardNumber.Replace("2A", "*");
                }

                //--------------------------------
                // C1 - CardHolder
                //--------------------------------
                log.Info("C1 - CardHolder ASCII");
                temp = GetTag(response, ref index);

                if (null != temp && temp.Length > 0)
                {
                    result.CardHolderName = ASCIIEncoding.ASCII.GetString(temp);
                }

                //--------------------------------
                // C1 - Track2  ASCII
                //--------------------------------
                log.Info("C1 - Track2 ASCII");
                temp = GetTag(response, ref index);

                if (null != temp && temp.Length > 0)
                {
                    result.Track2 = ASCIIEncoding.ASCII.GetString(temp);
                }

                //--------------------------------
                // C1 - Track 1
                //--------------------------------
                log.Info("C1 - Track 1 ASCII");
                temp = GetTag(response, ref index);

                if (null != temp && temp.Length > 0)
                {
                    result.Track1 = ASCIIEncoding.ASCII.GetString(temp);
                }

                //--------------------------------
                // C1 - CVV ASCII
                //--------------------------------
                log.Info("C1 - CVV ASCII");
                temp = GetTag(response, ref index);

                if (null != temp && temp.Length > 0)
                {
                    result.CVV = ASCIIEncoding.ASCII.GetString(temp);
                }

          
                //--------------------------------
                // C1 - CardEntryMode ASCII
                //--------------------------------

                log.Info(" C1 - CardEntryMode ASCII");
                temp = GetTag(response, ref index);

                if (null != temp && temp.Length > 0)
                {
                    int entryMode = Convert.ToInt32(ASCIIEncoding.ASCII.GetString(temp));
                    result.EntryMode = (CardEntryMode)entryMode;
                }

                //--------------------------------
                // E1 - EMV BCD
                //--------------------------------

                log.Info(" E1 - EVM TAGs BCD");
                temp = GetTag(response, ref index);

                if (null != temp && temp.Length > 0)
                {
                    result.E1 = temp;
                }

                //--------------------------------
                // E2 - EMV BCD
                //--------------------------------

                log.Info(" E2 - EMV BCD");
                temp = GetTag(response, ref index);

                if (null != temp && temp.Length > 0)
                {
                    result.E2 = temp;
                }

                //--------------------------------
                //TOKENS
                //--------------------------------

                int tokens_len = response.Length - index;

                byte[] bToken = new byte[tokens_len];

                Array.Copy(response, index, bToken, 0, tokens_len);

                String strToken = ASCIIEncoding.ASCII.GetString(bToken);

                if (null != strToken && strToken.Length > 0)
                {
                    String[] tokenArray = strToken.Split('!');

                    foreach (String token in tokenArray) 
                    {
                        if (null != token && token.Trim().Length > 0) 
                        {
                            if (token.Trim().StartsWith("ES")) 
                            {
                                result.ES = token.TrimStart();
                                continue;
                            }

                            if (token.Trim().StartsWith("EZ"))
                            {
                                result.EZ = token.TrimStart();
                                continue;
                            }

                            if (token.Trim().StartsWith("R1"))
                            {
                                result.R1 = token.TrimStart();
                                continue;
                            }


                            if (token.Trim().StartsWith("EY"))
                            {
                                result.EY = token.TrimStart();
                                continue;
                            }

                            if (token.Trim().StartsWith("CZ"))
                            {
                                result.CZ = token.TrimStart();
                                continue;
                            }
                        }
                    }
                }

                log.Info(result.ToString());

            }
            catch (Exception ex)
            {
                log.Error(ex);
                return result;
            }
            

            return result;
        }

        /// <summary>
        /// Realiza un parsing de la respuesta que viene del POS 
        /// y pone los resultados en un objeto de tipo TransactionResult
        /// </summary>
        /// <param name="response"></param>
        /// <returns></returns>
        public TransactionResult        ParseResponseC54        (   byte[] response                                             )    
        {
            TransactionResult result = new TransactionResult();

            int index = 0;

            log.Info("--------------------------------");
            log.Info("ParseResponse C53");
            log.Info("--------------------------------");

            try
            {

                //--------------------------------
                // Message Identifier 3 bytes ASCII
                //--------------------------------
                byte[] temp = new byte[3];
                System.Array.Copy(response, index, temp, 0, temp.Length);

                log.Info("Identifier BCD    : [" + Utilidad.Bcd2Str(temp) + "]");

                result.Identifier = ASCIIEncoding.ASCII.GetString(temp);

                log.Info("Identifier ASCII  : [" + result.Identifier + "]");

                index += temp.Length;

                //--------------------------------
                // Result 2 bytes ASCII
                //--------------------------------
                temp = new byte[2];
                System.Array.Copy(response, index, temp, 0, temp.Length);

                log.Info("Operation Result    : [" + Utilidad.Bcd2Str(temp) + "]");

                int iResult = 0;

                if (Int32.TryParse(ASCIIEncoding.ASCII.GetString(temp), out iResult))
                {
                    result.Result = (OperationResult)iResult;
                }

                index += temp.Length;


                //--------------------------------
                // Longitud 2 bytes HEX
                //--------------------------------
                temp = new byte[2];
                Array.Copy(response, index, temp, 0, temp.Length);

                log.Info("Len HEX    : [" + Utilidad.Bcd2Str(temp) + "]");

                index += temp.Length;

                int longitudTotal = Convert.ToInt32(Utilidad.Bcd2Str(temp), 16);

                //--------------------------------
                // E2 - EMV BCD
                //--------------------------------

                log.Info(" E2 - EMV BCD");
                temp = GetTag(response, ref index);

                if (null != temp && temp.Length > 0)
                {
                    result.E2 = temp;
                }

                log.Info(result.ToString());

            }
            catch (Exception ex)
            {
                log.Error(ex);
                return result;
            }


            return result;
        }


        /// <summary>
        /// Realizará una transacción basado en los Input de la propiedad Request 
        /// y retornará los datos de salida en la propiedad Response 
        /// </summary>
        /// <returns></returns>

        public TransactionResult        Authorization           (   byte[] instrucction                                         ) 
        {

            log.Info("----------------------------------");
            log.Info("Authorization");
            log.Info("----------------------------------");

            byte[] dataOut      = null;
            byte[] responseData = null;


            TransactionResult result = null;

            try
            {

                Utilidad.Init(); 

                //--------------------------------------------
                // Transaction ID
                //--------------------------------------------
                dataOut         = Utilidad.ConcatVar(dataOut,  instrucction);


                //--------------------------------------------
                // Message Len HEX
                //--------------------------------------------

                byte[] tags_c1  = BuildTagsC51();

                //------------------------------------
                // a la longitud le sumamos 1 del ETX
                //------------------------------------
                String hexString = (tags_c1.Length ).ToString("X4");
                byte[] bLen = Utilidad.ASCII_To_BCD(ASCIIEncoding.ASCII.GetBytes(hexString));

                dataOut = Utilidad.ConcatVar(dataOut,  bLen );
                //dataOut         = Utilidad.ConcatVar(dataOut, new byte[] { (byte) tags_c1.Length });

                //--------------------------------------------
                // Tags
                //--------------------------------------------

                dataOut = Utilidad.ConcatVar(dataOut, tags_c1);

                responseData = sendAndReceive(false, dataOut);

                //--------------------------------
                // Debmemos enviar ACK ?
                //--------------------------------
                if (SendACK)
                {
                    Send(new byte[] { 0x06 });
                }

                if (responseData != null)
                {
                    result = ParseResponseC53(responseData);
                }


            }
            catch (Exception ex)
            {
                log.Error("Authorization()", ex);
                return null;
            }


            return result;
        }


        public TransactionResult        FinishAuthorization     (                                                               )
        {

            log.Info("----------------------------------");
            log.Info("Finish Authorization");
            log.Info("----------------------------------");

            byte[] dataOut              = null;
            byte[] responseData         = null;

            TransactionResult result    = null;

            try
            {

                Utilidad.Init();

                //--------------------------------------------
                // Transaction ID
                //--------------------------------------------
                dataOut = Utilidad.ConcatVar(dataOut, Instructions.C54);


                //--------------------------------------------
                // Message Len HEX
                //--------------------------------------------

                byte[] tags_c1 = BuildTagsC54();

                //------------------------------------
                // a la longitud le sumamos 1 del ETX
                //------------------------------------
                String hexString = (tags_c1.Length).ToString("X4");
                byte[] bLen = Utilidad.ASCII_To_BCD(ASCIIEncoding.ASCII.GetBytes(hexString));

                dataOut = Utilidad.ConcatVar(dataOut, bLen);
                //dataOut         = Utilidad.ConcatVar(dataOut, new byte[] { (byte) tags_c1.Length });

                //--------------------------------------------
                // Tags
                //--------------------------------------------

                dataOut = Utilidad.ConcatVar(dataOut, tags_c1);

                responseData = sendAndReceive(false, dataOut);

                if (SendACK)
                {
                    Send(new byte[] { 0x06 });
                }

                if (responseData != null)
                {
                    result = ParseResponseC54(responseData);
                }

            }
            catch (Exception ex)
            {
                log.Error("FinishAuthorization()", ex);
                return null;
            }


            return result;
        }



        public TransactionResult        RequestBIN              (                                                               )
        {

            log.Info("----------------------------------");
            log.Info("Request BIN");
            log.Info("----------------------------------");

            byte[] dataOut = null;
            byte[] responseData = null;


            TransactionResult result = null;

            try
            {

                Utilidad.Init();

                //--------------------------------------------
                // Transaction ID
                //--------------------------------------------
                dataOut = Utilidad.ConcatVar(dataOut, Instructions.C50_Authorization);



                //--------------------------------
                //incluir timeout
                //--------------------------------

                byte[] tagsC1 = null;

                if (IncluirTimeout)
                { 
                        tagsC1 = Utilidad.ConcatVar(tagsC1, getTimeout() != null ? getTimeout() : empty_c1);
                }
                //--------------------------------
                //transaction date
                //--------------------------------
                tagsC1 = Utilidad.ConcatVar(tagsC1, getTransactionDate() != null ? getTransactionDate() : empty_c1);

                //--------------------------------
                //transaction time
                //--------------------------------
                tagsC1 = Utilidad.ConcatVar(tagsC1, getTransactionTime() != null ? getTransactionTime() : empty_c1);

                //--------------------------------
                //transaction type
                //--------------------------------
                tagsC1 = Utilidad.ConcatVar(tagsC1, getTransactionType() != null ? getTransactionType() : empty_c1);

                //--------------------------------
                // amount
                //--------------------------------
                tagsC1 = Utilidad.ConcatVar(tagsC1, getAmount() != null ? getAmount() : empty_c1_amount);

    
               String hexString = (tagsC1.Length).ToString("X4");

                byte[] bLen = Utilidad.ASCII_To_BCD(ASCIIEncoding.ASCII.GetBytes(hexString));

                dataOut = Utilidad.ConcatVar( dataOut, bLen );

                //--------------------------------------------
                // Tags
                //--------------------------------------------

                dataOut = Utilidad.ConcatVar(dataOut, tagsC1);

                responseData = sendAndReceive(false, dataOut);

                if (responseData != null)
                {
                    result = ParseResponse(responseData);
                }

            }
            catch (Exception ex)
            {
                log.Error("Authorization()", ex);
                return null;
            }


            return result;
        }

        /// <summary>
        /// Realizará una transacción basado en los Input de la propiedad Request 
        /// y retornará los datos de salida en la propiedad Response 
        /// </summary>
        /// <returns></returns>
        public TransactionResult        Authorization           (                                                               )
        {

            log.Info("----------------------------------");
            log.Info("Authorization");
            log.Info("----------------------------------");

            byte[] dataOut = null;
            byte[] responseData = null;


            TransactionResult result = null;

            try
            {

                Utilidad.Init();

                //--------------------------------------------
                // Transaction ID
                //--------------------------------------------
                dataOut = Utilidad.ConcatVar(dataOut, Instructions.C51_Authorization);


                //--------------------------------------------
                // Message Len HEX
                //--------------------------------------------

                byte[] tags_c1 = BuildTags();

                //------------------------------------
                // a la longitud le sumamos 1 del ETX
                //------------------------------------
                String hexString = (tags_c1.Length).ToString("X4");
                byte[] bLen = Utilidad.ASCII_To_BCD(ASCIIEncoding.ASCII.GetBytes(hexString));

                dataOut = Utilidad.ConcatVar(dataOut, bLen);
                //dataOut         = Utilidad.ConcatVar(dataOut, new byte[] { (byte) tags_c1.Length });

                //--------------------------------------------
                // Tags
                //--------------------------------------------

                dataOut = Utilidad.ConcatVar(dataOut, tags_c1);

                responseData = sendAndReceive(false, dataOut);

                //--------------------------------
                // Debmemos enviar ACK ?
                //--------------------------------
                if (SendACK)
                {
                    Send(new byte[] { 0x06 });
                }

                if (responseData != null)
                {
                    result = ParseResponse(responseData);
                }

            }
            catch (Exception ex)
            {
                log.Error("Authorization()", ex);
                return null;
            }


            return result;
        }

        /// <summary>
        /// Realizará una transacción de sincronizacion con el pinpad
        /// </summary>
        /// <returns></returns>

        public TransactionResult        Syncronization          (                                                               )
        {
            /*
            C1 
                03 
                10 12 31 
            C1 
                03 
                16 44 59 
            C1 
                01 
                10 
            C1 
                0A 
                30 30 30 30 30 30 30 30 30 31 03 7F
           */

            log.Info("----------------------------------");
            log.Info("Syncronization");
            log.Info("----------------------------------");

            byte[] dataOut      = null;
            byte[] responseData = null;


            TransactionResult result = null;

            try
            {

                Utilidad.Init();

                //--------------------------------------------
                // Transaction ID
                //--------------------------------------------
                dataOut = Utilidad.ConcatVar(dataOut, Instructions.C51_Authorization);


                //--------------------------------
                //transaction date
                //--------------------------------
                byte[] tags = null;
                
                tags =  Utilidad.ConcatVar(tags, getTransactionDate() != null ? getTransactionDate() : empty_c1);

                //--------------------------------
                //transaction time
                //--------------------------------
                tags = Utilidad.ConcatVar(tags, getTransactionTime() != null ? getTransactionTime() : empty_c1);

                //--------------------------------
                //trx type
                //--------------------------------

                setTransactionType(TransactionType.SYNC_ECR);
                tags = Utilidad.ConcatVar(tags, getTransactionType()  );



                //--------------------------------
                //transaction time
                //--------------------------------
                if (null != getECRId())
                {
                    tags = Utilidad.ConcatVar(tags, getECRId());
                }

                //------------------------------------
                // a la longitud le sumamos 1 del ETX
                //------------------------------------
                String hexString = (tags.Length + 1).ToString("X4");
                byte[] bLen = Utilidad.ASCII_To_BCD(ASCIIEncoding.ASCII.GetBytes(hexString));


                dataOut = Utilidad.ConcatVar(dataOut, bLen, tags);
               
                responseData = sendAndReceive(false, dataOut);

                if (responseData != null)
                {
                    result = ParseResponse(responseData);
                }

            }
            catch (Exception ex)
            {
                log.Error("Authorization()", ex);
                return null;
            }


            return result;
        }




        //-----------------------------------------------------------------
        // Mensaje en Pantalla 
        //-----------------------------------------------------------------
        public TransactionResult CancelServices()
        {
            log.Info("----------------------------------");
            log.Info("Message 72 -- CancelServices");
            log.Info("----------------------------------");

            byte[] dataOut      = null;
            byte[] responseData = null;


            TransactionResult result = null;

            try
            {

                Utilidad.Init();

                //--------------------------------------------
                // Transaction ID
                //--------------------------------------------
                dataOut = Utilidad.ConcatVar(dataOut, Instructions.Cancel_72);

                responseData = sendAndReceive(false, dataOut);

                if (responseData != null && responseData[0] == 0x06)
                {
                    result = new TransactionResult();
                    result.Result = OperationResult.Sucess;
                }
                else 
                {
                    result = new TransactionResult();
                    result.Result = OperationResult.Cancel;
                }

                //--------------------------------
                // Debmemos enviar ACK ?
                //--------------------------------
                if (SendACK)
                {
                    Send(new byte[] { 0x06 });
                }

            }
            catch (Exception ex)
            {
                log.Error("Cancel Services", ex);
                return null;
            }


            return result;
        }



        //-----------------------------------------------------------------
        // Mensaje en Pantalla 
        //-----------------------------------------------------------------
        public TransactionResult GetModel()
        {
            log.Info("----------------------------------");
            log.Info("Message Q8");
            log.Info("----------------------------------");

            byte[] dataOut = null;
            byte[] responseData = null;


            TransactionResult result = null;

            try
            {

                Utilidad.Init();

                //--------------------------------------------
                // Transaction ID
                //--------------------------------------------
                dataOut         = Utilidad.ConcatVar(   dataOut , Instructions.Q8);

                responseData    = sendAndReceive    (   false   , dataOut);


                result          = ParseResponseQ8   (   responseData );

                //--------------------------------
                // Debmemos enviar ACK ?
                //--------------------------------
                if (SendACK)
                {
                    Send(new byte[] { 0x06 });
                }

            }
            catch (Exception ex)
            {
                log.Error("Cancel Services", ex);
                return null;
            }


            return result;
        }



        //-----------------------------------------------------------------
        // Mensaje en Pantalla 
        //-----------------------------------------------------------------
        public TransactionResult        Z2              (       ) 
        {
            log.Info("----------------------------------");
            log.Info("Message Z2 -- DisplayText");
            log.Info("----------------------------------");

            byte[] dataOut = null;
            byte[] responseData = null;


            TransactionResult result = null;

            try
            {

                Utilidad.Init();

                //--------------------------------------------
                // Transaction ID
                //--------------------------------------------
                dataOut = Utilidad.ConcatVar(dataOut, Instructions.Z2);


                //--------------------------------
                //transaction date
                //--------------------------------

                // Substitución (1A= Limpiar display)

                dataOut = Utilidad.ConcatVar(dataOut, new byte[] { 0x1A}, getDisplayText());

                responseData = sendAndReceive(false, dataOut);

                if (responseData != null && responseData[0] == 0x06)
                {
                    result           = new TransactionResult();
                    result.Result   = OperationResult.Sucess;
                }
                else
                {
                    result          = new TransactionResult();
                    result.Result   = OperationResult.Cancel;
                }

                //--------------------------------
                // Debmemos enviar ACK ?
                //--------------------------------
                if (SendACK)
                {
                    Send(new byte[] { 0x06 });
                }

            }
            catch (Exception ex)
            {
                log.Error("Z2", ex);
                return null;
            }


            return result;
        }

        //-----------------------------------------------------------------
        // store bin id
        //-----------------------------------------------------------------
        public TransactionResult        Z3              (       )
        {
            log.Info("----------------------------------");
            log.Info("Message Z3 -- Store BIN ID        ");
            log.Info("----------------------------------");

            byte[] dataOut = null;
            byte[] responseData = null;


            TransactionResult result = null;

            try
            {

                Utilidad.Init();

                //--------------------------------------------
                // Transaction ID
                //--------------------------------------------
                dataOut = Utilidad.ConcatVar(dataOut, Instructions.Z3);

                dataOut = Utilidad.ConcatVar(dataOut, getBinTableId() );


                responseData = sendAndReceive(false, dataOut);

                if (responseData != null && responseData[0] == 0x06)
                {
                    result          = new TransactionResult();
                    result.Result   = OperationResult.Sucess;
                }
                else
                {
                    result          = new TransactionResult();
                    result.Result   = OperationResult.Cancel;
                }

                //--------------------------------
                // Debmemos enviar ACK ?
                //--------------------------------
                if (SendACK)
                {
                    Send(new byte[] { 0x06 });
                }

            }
            catch (Exception ex)
            {
                log.Error("Z3", ex);
                return null;
            }


            return result;
        }

        public TransactionResult        C14_BinTables           (       )
        {
            log.Info("----------------------------------");
            log.Info("Message C14 -- BinTables          ");
            log.Info("----------------------------------");

            byte[] dataOut      = null;
            byte[] responseData = null;


            TransactionResult result = null;

            try
            {

                Utilidad.Init();

                //--------------------------------------------
                // Transaction ID
                //--------------------------------------------
                dataOut = Utilidad.ConcatVar(dataOut, Instructions.C14_BinTables);


                //--------------------------------
                //transaction date
                //--------------------------------
                byte[] tags = null;

                // Substitución (1A= Limpiar display)

                tags = Utilidad.ConcatVar(tags, getET() );

                dataOut = Utilidad.ConcatVar(dataOut, tags);

                responseData = sendAndReceive(false, dataOut);

                if (responseData != null)
                {
                    result = ParseResponseZ2(responseData);
                }

            }
            catch (Exception ex)
            {
                log.Error("Z2", ex);
                return null;
            }


            return result;
        }


        public TransactionResult        RandomKeyRequest       (       ) 
        {
            log.Info("----------------------------------   ");
            log.Info("Message Z10 RandomKey Request        ");
            log.Info("----------------------------------   ");

            byte[] dataOut = null;
            byte[] responseData = null;


            TransactionResult result = null;

            try
            {

                Utilidad.Init();

                //--------------------------------------------
                // Transaction ID
                //--------------------------------------------
                dataOut = Utilidad.ConcatVar(dataOut, Instructions.Z10);

                responseData = sendAndReceive(false, dataOut);

               


                if (responseData != null)
                {
                    //--------------------------------
                    // Debmemos enviar ACK ?
                    //--------------------------------
                    if (SendACK)
                    {
                        Send(new byte[] { 0x06 });
                    }

                    result = ParseResponseZ10(responseData);
                }

            }
            catch (Exception ex)
            {
                log.Error("Z10 RandomKeyRequest", ex);
                return null;
            }


            return result;
        }

        public TransactionResult        SetInitialKey_DUKPT    (  String tokenEX     )
        {
            log.Info("----------------------------------   ");
            log.Info("Message Z11 Initial DUKPT Key        ");
            log.Info("----------------------------------   ");

            byte[] dataOut = null;
            byte[] responseData = null;


            TransactionResult result = null;

            try
            {

                Utilidad.Init();

                //--------------------------------------------
                // Transaction ID
                //--------------------------------------------
                dataOut = Utilidad.ConcatVar(dataOut, Instructions.Z11);

                dataOut = Utilidad.ConcatVar(dataOut, ASCIIEncoding.ASCII.GetBytes(tokenEX));

                responseData = sendAndReceive(false, dataOut);

                if (responseData != null)
                {
                    result = ParseResponseZ2(responseData);
                }

            }
            catch (Exception ex)
            {
                log.Error("Z10 RandomKeyRequest", ex);
                return null;
            }


            return result;
        }


        public TransactionResult Corresponsal( )
        {
            log.Info("----------------------------------        ");
            log.Info("Message C11 Corresponsal  Bancario        ");
            log.Info("----------------------------------        ");

            byte[] dataOut = null;
            byte[] responseData = null;


            TransactionResult result = null;

            try
            {

                Utilidad.Init();

                //--------------------------------------------
                // Transaction ID
                //--------------------------------------------
                dataOut = Utilidad.ConcatVar(dataOut, Instructions.CC1);


                byte[] dataOut2 = null;

                //--------------------------------
                //incluir timeout
                //--------------------------------

                if (IncluirTimeout)
                {
                    dataOut2 = Utilidad.ConcatVar(dataOut2, getTimeout() != null ? getTimeout() : empty_c1);
                }
                //--------------------------------
                //transaction date
                //--------------------------------
                dataOut2 = Utilidad.ConcatVar(dataOut2, getTransactionDate() != null ? getTransactionDate() : empty_c1);

                //--------------------------------
                //transaction time
                //--------------------------------
                dataOut2 = Utilidad.ConcatVar(dataOut2, getTransactionTime() != null ? getTransactionTime() : empty_c1);


                //--------------------------------
                // amount
                //--------------------------------
                dataOut2 = Utilidad.ConcatVar(dataOut2, getAmount() != null ? getAmount() : empty_c1_amount);

                //--------------------------------
                // tarjeta
                //--------------------------------
                dataOut2 = Utilidad.ConcatVar(dataOut2, getCardNumber() );

                //--------------------------------
                // operador
                //--------------------------------
                dataOut2 = Utilidad.ConcatVar(dataOut2, getOperatorName());

                //--------------------------------
                // referencia o n'umero de credito o  celular
                //--------------------------------
                dataOut2 = Utilidad.ConcatVar(dataOut2, getReference());

                //--------------------------------
                // id sucursal o tienda
                //--------------------------------
                dataOut2 = Utilidad.ConcatVar(dataOut2, getIdSucursal());

                //--------------------------------
                // id caja
                //--------------------------------
                dataOut2 = Utilidad.ConcatVar(dataOut2, getIdCaja());

                //--------------------------------
                // pos serial
                //--------------------------------
                dataOut2 = Utilidad.ConcatVar(dataOut2, getPOSSerial());

                //--------------------------------
                // id sucursal o tienda
                //--------------------------------
                dataOut2 = Utilidad.ConcatVar(dataOut2, getCifrarPagosTarjetaCorresponsal());



                //------------------------------------
                // a la longitud le sumamos 1 del ETX
                //------------------------------------
                String hexString = (dataOut2.Length).ToString("X4");
                byte[] bLen = Utilidad.ASCII_To_BCD(ASCIIEncoding.ASCII.GetBytes(hexString));

                dataOut = Utilidad.ConcatVar(dataOut, bLen);
                //dataOut         = Utilidad.ConcatVar(dataOut, new byte[] { (byte) tags_c1.Length });

                //--------------------------------------------
                // Tags
                //--------------------------------------------

                dataOut = Utilidad.ConcatVar(dataOut, dataOut2);

                responseData = sendAndReceive(false, dataOut);

                if (responseData != null)
                {
                    if (cifrarPagosTajeta)
                    {
                        result = ParseResponseC11(responseData);
                    }
                    else 
                    {
                        result = ParseResponseZ2(responseData);
                    }
               
                }

            }
            catch (Exception ex)
            {
                log.Error("C11 Corresponsal", ex);
                return null;
            }


            return result;
        }

        /// <summary>
        /// Envía y recibe los bytes al host. 
        /// Este método tiene que ser implementado por toda clase que herede de ésta. 
        /// En el caso que fuera conexión Ethernet, la clase hija tendrá que hacer todo 
        /// el procedimiento que conectarse al host vía tcp/ip, si fuera el caso. 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public virtual byte[] sendAndReceive(bool closeSocket, params byte[][] data)
        {
            return null;
        }


        public virtual bool CloseChannel() 
        {
            return false;
        }

        public virtual bool Send(byte[] data) 
        {
            return false;
        }

        /*
        public override string ToString()
        {
            StringBuilder builder = new StringBuilder();

            builder.AppendLine("Trace ");
            builder.AppendLine("Transaction Date    [" + Utilidad.Bcd2Str  (   getTransactionDate   ()  ) + "]" );
            builder.AppendLine("Transaction Time    [" + Utilidad.Bcd2Str  (   getTransactionTime   ()  ) + "]" );
            builder.AppendLine("Transaction Type    [" + Utilidad.Bcd2Str  (   getTransactionType   ()  ) + "]" );
            builder.AppendLine("Voucher             [" + Utilidad.Bcd2Str  (   getVoucherNumber     ()  ) + "]" );
            builder.AppendLine("Authorization       [" + Utilidad.Bcd2Str  (   getAuthorizationCode ()  ) + "]" );
            builder.AppendLine("Amount              [" + Utilidad.Bcd2Str  (   getAmount            ()  ) + "]" );
            builder.AppendLine("Cashback            [" + Utilidad.Bcd2Str  (   getCashback_Amount   ()  ) + "]" );
            builder.AppendLine("Tip Amount          [" + Utilidad.Bcd2Str  (   getTip_Amount        ()  ) + "]" );
            builder.AppendLine("Amount      USD     [" + Utilidad.Bcd2Str  (   getAmount_USD        ()  ) + "]" );
            builder.AppendLine("Cashback    USD     [" + Utilidad.Bcd2Str  (   getCashback_Amount_USD() ) + "]" );
            builder.AppendLine("Tip Amount  USD     [" + Utilidad.Bcd2Str  (   getTip_Amount_USD    ()  ) + "]" );
            builder.AppendLine("Currency Index      [" + Utilidad.Bcd2Str  (   getCurrencyIndex     ()  ) + "]" );
            builder.AppendLine("Merchant Decision   [" + Utilidad.Bcd2Str  (   getMerchantDecision  ()  ) + "]" );
            builder.AppendLine("Serial              [" + Utilidad.Bcd2Str  (   getECR_ID_SERIAL     ()  ) + "]" );
            builder.AppendLine("Emv Tags            [" + Utilidad.Bcd2Str  (   getEmvTags           ()  ) + "]" );
            return builder.ToString();
        }
        */
        #endregion

    }
}
