﻿using ECR_Veriphone_Lib.util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECR_Veriphone_Lib.core
{
    public class TransactionResult
    {
        public String           Identifier          { get; set; }

        public OperationResult  Result              { get; set; }

        public String           HostResponse        { get; set; }

        public String           AuthorizationCode   { get; set; }

        public String           ResponseCode        { get; set; }

        public String           TransactionDate     { get; set; }

        public String           TransactionTime     { get; set; }

        public String           CardNumber          { get; set; }

        public String           CardHolderName      { get; set; }

        public CardEntryMode    EntryMode           { get; set; }

        public String           VoucherNumber       { get; set; }

        public CardType         CardType            { get; set; }

        public String           CurrencyCode        { get; set; }

        public String           AmountAuthorized    { get; set; }

        public String           SoftwareVersion     { get; set; }

        public String           SerialNumber        { get; set; }

        public String           ECR_ID_SERIAL       { get; set; }

        public byte[]           E1                  { get; set; }
        public byte[]           E2                  { get; set; }

        public String           ES                  { get; set; }
        public String           R1                  { get; set; }

        public String           EZ                  { get; set; }
        public String           EY                  { get; set; }
        public String           Track1              { get; set; }
        public String           Track2              { get; set; }
        public String           CVV                 { get; set; }
        public String           EW                  { get; set; }
        public String           CZ                  { get; set; }


        public override string ToString()
        {
            StringBuilder builder = new StringBuilder();

            builder.AppendLine(String.Format("Identificador     : [{0}]", Identifier                                ));
            builder.AppendLine(String.Format("Result            : [{0}]", Result.ToString()                         ));
            builder.AppendLine(String.Format("Host Response     : [{0}]", HostResponse                              ));
            builder.AppendLine(String.Format("Authorization     : [{0}]", AuthorizationCode                         ));
            builder.AppendLine(String.Format("Response Code     : [{0}]", ResponseCode                              ));
            builder.AppendLine(String.Format("TransactionDate   : [{0}]", TransactionDate                           ));
            builder.AppendLine(String.Format("TransactionTime   : [{0}]", TransactionTime                           ));
            builder.AppendLine(String.Format("CardNumber        : [{0}]", CardNumber                                ));
            builder.AppendLine(String.Format("CardHolderName    : [{0}]", CardHolderName                            )); 
            builder.AppendLine(String.Format("EntryMode         : [{0}]", EntryMode.ToString()                      ));
            builder.AppendLine(String.Format("Track1            : [{0}]", Track1                                    ));
            builder.AppendLine(String.Format("Track2            : [{0}]", Track2                                    ));
            builder.AppendLine(String.Format("CardType          : [{0}]", CardType.ToString()                       ));
            
            builder.AppendLine(String.Format("CVV               : [{0}]", CVV                                       ));
            builder.AppendLine(String.Format("SoftwareVersion   : [{0}]", SoftwareVersion                           ));

            if (!String.IsNullOrEmpty(ECR_ID_SERIAL) && ECR_ID_SERIAL.Contains("\0")) 
            {
                builder.AppendLine(String.Format("ECR_ID_SERIAL     : [{0}]", ECR_ID_SERIAL.Replace("\0","_")));
            }
            else 
            {
                builder.AppendLine(String.Format("ECR_ID_SERIAL     : [{0}]", ECR_ID_SERIAL                             ));
            }

            builder.AppendLine(String.Format("E1                : [{0}]", E1 != null ? Utilidad.Bcd2Str(E1) : ""    ));
            builder.AppendLine(String.Format("E2                : [{0}]", E2 != null ? Utilidad.Bcd2Str(E2) : ""    ));

            builder.AppendLine(String.Format("ES                : [{0}]", ES    ));
            builder.AppendLine(String.Format("R1                : [{0}]", R1    ));
            builder.AppendLine(String.Format("EY                : [{0}]", EY    ));
            builder.AppendLine(String.Format("EZ                : [{0}]", EZ    ));
            builder.AppendLine(String.Format("CZ                : [{0}]", CZ    ));

            return builder.ToString();
        }
    }
}
