﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECR_Veriphone_Lib.core
{
    /// <summary>
    /// 
    /// 01 – Sale
    /// 02 – Void
    /// 03 – Refund
    /// 04 – Authorization 
    /// 05 – Auth-Only/Pre- Auth
    /// 06 – Reversal
    /// 07 – Installment
    /// 08 – Tip Adjust
    /// 09 – Capture
    /// 10 – Detail Report
    /// 11 – Summary Report 
    /// 12 – Server Report 
    /// 13 – Settlement
    /// 14 – PreAuth (Gas)
    /// 15 – Completion(Gas)
    /// 16 – Top-Up Auth
    /// 17 – Sale Offline
    /// 18 – Key Exchange
    /// 19 – Form Feed
    /// 20 – Sync with ECR
    /// 
    /// </summary>
    public enum TransactionType
    {
        SALE                =   1   , 
        VOID                =   2   , 
        REFUND              =   3   , 
        AUTHORIZATION       =   4   ,
        PRE_AUTHORIZATION   =   5   ,
        REVERSAL            =   6   ,
        INSTALLMENT         =   7   , 
        TIP_ADJUST          =   8   , 
        CAPTURE             =   9   ,
        DETAIL_REPORT       =   10  , 
        SUMMARY_REPORT      =   11  ,
        SERVER_REPORT       =   12  ,
        SETTLEMENT          =   13  ,
        PREAUTH_GAS         =   14  ,
        COMPLETION_GAS      =   15  ,
        TOP_UP_AUTH         =   16  ,
        SALE_OFFLINE        =   17  ,
        KEY_EXCHANGE        =   18  , 
        FORM_FEED           =   19  , 
        SYNC_ECR            =   20  , 
        CLSS                =   0xB7
    }
}
