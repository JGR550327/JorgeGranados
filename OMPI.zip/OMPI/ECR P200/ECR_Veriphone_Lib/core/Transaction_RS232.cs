﻿using ECR_Veriphone_Lib.communication;
using ECR_Veriphone_Lib.util;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static ECR_Veriphone_Lib.communication.PortHandler;

namespace ECR_Veriphone_Lib.core
{
    public class Transaction_RS232 : TransactionCore
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(Transaction_RS232));

        private static  byte[]  STX         = { 0x02 }  ;   //    Start of Text
        private static  byte[]  ETX         = { 0x03 }  ;   //    End   of Text

        public const    byte    ACK         = 0x06      ;
        public const    byte    NACK        = 0x15      ;
        public const    byte    NOTHING     = 0x01      ;
       

    
        public bool UseReceiveMethodAsString { get; set; }

        public Transaction_RS232()
        {
            Utilidad.Init();
        }

        /// <summary>
        /// Calcula el Latency Code Redundancy. 
        /// Para realizar este cálculo se realiza un XOR de todos los bytes. 
        /// </summary>
        /// <param name="bytes"></param>
        /// <returns></returns>
   

        /// <summary>
        /// Communication Port 
        /// </summary>
        public string ComPort { get; set; }

        /// <summary>
        /// Connection Speed
        /// </summary>
        public string Baudrate { get; set; }

        /// <summary>
        /// Parity Bits
        /// </summary>
        public string Parity { get; set; }

        /// <summary>
        /// Stop Bits
        /// </summary>
        public string StopBits { get; set; }

        /// <summary>
        /// Data Bits
        /// </summary>
        public string DataBits { get; set; }

        /// <summary>
        /// Objeto para realizar la conexión Serial a la terminal PAX
        /// </summary>
        public PortHandler portComm { get; set; }


        public override bool Send(byte[] data)
        {
            bool dataSent = false;

            if (null == portComm) 
            {
                return dataSent;
            }

            if (portComm.IsOpen())
            {

                //portComm.SendACK(); 
                portComm.SendData(data);
                dataSent = true;

                log.Info("ACK was sent ");
            }
            else 
            {
                log.Info("Port not opened");
            }

            return dataSent;
        }

        /// <summary>
        /// Realiza el envío y recepción de los bytes usando el canal de comunicación SERIAL
        /// </summary>
        /// <param name="closeSocket">Indica si cierra el canal</param>
        /// <param name="data"></param>
        /// <returns></returns>
        public override byte[] sendAndReceive(bool closeSocket, params byte[][] data)
        {

#if WAIT_ACK

            int tries = 1;

#endif

            log.Info(String.Format("Lib Version = {0}", AppVersion.GetVersion()));
            log.Info(String.Format("Lib Build   = {0}", AppVersion.GetRevision()));

            log.Info(String.Format("Puerto COM  = [{0}]", ComPort   )   );
            log.Info(String.Format("BaudRate    = [{0}]", Baudrate  )   );
            log.Info(String.Format("DataBits    = [{0}]", DataBits  )   );
            log.Info(String.Format("Parity      = [{0}]", Parity    )   );
            log.Info(String.Format("StopBits    = [{0}]", StopBits  )   );
            log.Info(String.Format("Timeout     = [{0}]", Timeout   )   );
            log.Info(String.Format("StopOnACK   = [{0}]", StopOnACK  == true ? "Si" : "No"));
            log.Info(String.Format("VerifyCheckSum   = [{0}]", verifyCheckSum == true ? "Si" : "No"));

            String  LocalCommunicationErrorMessage = "";
            bool    LocalCommunicationError = false;


            if (portComm == null)
            {

                portComm                            = new PortHandler   (   )       ;
                portComm.Baudrate                   = Baudrate                  ;
                portComm.ComPort                    = ComPort                   ;
                portComm.DataBits                   = DataBits                  ;
                portComm.Parity                     = Parity                    ;
                portComm.StopBits                   = StopBits                  ;
                portComm.TimeOut                    = Timeout                   ;
                portComm.UseReceivedMethodString    = UseReceiveMethodAsString  ;
                portComm.IsSpecialConnection        = false                     ;
              
            }

            portComm.verifyCheckSum     = verifyCheckSum;
            portComm.StopOnAck          = StopOnACK;

            try
            {



                //String strLen   = "0"       ;

                byte[] subdata  = data[0]   ;  

                byte[] script1  =  
                    Utilidad.ConcatVar
                                        (
                                            subdata     ,   //data to send
                                            ETX          //end of trace                            
                                        );


                byte[] LCR = Utilidad.CalculateLCR(
                                            script1
                                          );          //LCR (XOR)

                script1 = Utilidad.ConcatVar
                                    (
                                        STX     ,
                                        script1 ,
                                        LCR                          
                                    );


               

                ERR_SERIAL_PORT portError = PortHandler.ERR_SERIAL_PORT.ERR_NO_ERROR;


                if (!portComm.IsOpen())
                {
                    portError = (ERR_SERIAL_PORT)portComm.OpenPort();
                }

                if (portError == PortHandler.ERR_SERIAL_PORT.ERR_PORT_OPEN)
                {

                    String trace = Utilidad.Bcd2str(script1, 0, script1.Length * 2, false);

                    if (!String.IsNullOrEmpty(trace))
                    {

                        log.Info(String.Format("Sending Data = {0} ", trace));

                        log.Info("Sent >>>> ");

                        log.Info(HexDump.dumpHexString(script1));

                        log.Info(this.ToString());
                        //log.Info( Utilidad.HexDump ( data ));

                    }


                    LocalCommunicationErrorMessage = "ERROR OPENING PORT DATA. COM PORT MAY BE LOCKED";
                    LocalCommunicationError         = true;

                    log.Error(LocalCommunicationErrorMessage);

                    LocalCommunicationErrorMessage  = "-10";
                    Success = false;

                    return null;
                }



                portComm.ReceivedBuffer = null;

                LocalCommunicationError = false;


#if WAIT_ACK
                while (  tries <= 3 )
                {
                
                    log.Info (String.Format("Transaction try = {0}", tries));

#endif

                if (portComm.SendData(script1))
                {

                    
                    log.Info(this.ToString());
#if WAIT_ACK
                        byte controlByte = portComm.WaitACK();

                        switch( controlByte )
                        {
                            case ACK:
                                //=========================================================================
                                // Continue normal process 
                                //=========================================================================

                                log.Info ("We have received a ACK");
#endif
                    if (portComm.ReceiveDataAsyncronous() > 0)
                    {
                        // portComm.SendACK();
                    }
                    else
                    {
                        LocalCommunicationErrorMessage = "ERROR READING DATA. CABLE MAY BE DISCONNECTED.";
                        LocalCommunicationError = true;

                        log.Error(LocalCommunicationErrorMessage);

                        if (!portComm.AckReceived)
                        {
                            LocalCommunicationErrorMessage = "-11"; //local Timeout
                        }

                        //portComm.ResetPort  (   );  

                    }


                } //end if 

#if WAIT_ACK
                } //end while
#endif

                if (closeSocket)
                {
                    portComm.ClosePort();
                }

                if (LocalCommunicationError)
                {
                    Success = false;
                    return null;
                }

                if (portComm.ReceivedBuffer != null)
                {

                    ResponseBytes = portComm.ReceivedBuffer;

                    int     longitudDeControl   = 0     ;
                    bool    AckRead             = false ;
                    bool    nackRead            = false ;

                    AckRead     = portComm.ReceivedBuffer[0] == 0x06 ? true : false;

                    nackRead    = portComm.ReceivedBuffer[0] == 0x15 ? true : false;

                    if (nackRead) 
                    {
                        log.Info("NACK READ");
                        return portComm.ReceivedBuffer;
                    }

                    if (AckRead && StopOnACK)
                    {
                        log.Info("Stop ACK");
                        return portComm.ReceivedBuffer;
                    }


                    if (AckRead)
                    {
                        longitudDeControl = 4; //ACK-STX-ETX-LCR (4 bytes)
                    }
                    else
                    {
                        longitudDeControl = 3; //STX-ETX-LCR (3 bytes)
                    }

                    byte[] _buffer = new byte[portComm.ReceivedBuffer.Length - longitudDeControl]; //we take off STX-ETX-LCR (3 bytes)

                    System.Array.Copy(portComm.ReceivedBuffer, (AckRead ? 2 : 1), _buffer, 0, portComm.ReceivedBuffer.Length - longitudDeControl);

                    portComm.Buffer = new byte[_buffer.Length];

                    portComm.Buffer = _buffer;

                    log.Info(String.Format("Final Buffer = '{0}'", Utilidad.Bcd2Str(_buffer)));




                    try
                    {
                        if (portComm.Buffer.Length > 3)
                        {
                            
                            if (portComm.Buffer[4] == 0x30 && portComm.Buffer[5] == 0x30)
                            {
                                Success = true;
                            }
                            else
                            {
                                Success = false;
                            }


                            //DCL_ResponseCode = Utilidad.Bcd2Str(new byte[] { portComm.Buffer[2], portComm.Buffer[3] });

                        }
                        else
                        {
                            Success = false;
                            //DCL_ResponseCode = "";
                        }

                    }
                    catch (Exception ex)
                    {
                        log.Error(ex);
                        Success = false;
                    }

                }

                portComm.ReceivedBuffer = portComm.Buffer;

                return portComm.Buffer;
            }
            catch (Exception ex)
            {
                portComm.ClosePort();
                log.Error("SendAndReceive", ex);
                Success = false;
                return null;
            }
        }

        public override bool CloseChannel()
        {
            bool closed = false;

            try
            {
                if (portComm != null)
                {
                    portComm.ClosePort();
                }

                closed = true;
            }
            catch (Exception ex)
            {

                log.Error("CloseChannel", ex);
                closed = false;
            }

            return closed;
        }

    }
}

