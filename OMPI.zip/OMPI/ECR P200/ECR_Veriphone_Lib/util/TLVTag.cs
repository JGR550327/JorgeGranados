﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECR_Veriphone_Lib.util
{
    public class TLVTag : TLVData
    {
        /// <summary>
        /// Parses out a single TLVData object from the supplied data
        /// </summary>
        /// <remarks>
        /// The full data supplied may or may not be used, as only the first TLV object is parsed out
        /// </remarks>
        public static TLVTag Parse(byte[] data)
        {
            TLVTag tlvData = new TLVTag();
            tlvData.ParseSingle(data);
            return tlvData;
        }

        public static List<TLVTag> ParseAll(byte[] data)
        {
            List<TLVTag> tags = new List<TLVTag>();
            int offset = 0;
            while (offset >= 0)
            {
                TLVTag tag = new TLVTag();
                tag.Parse(data, ref offset);
                tags.Add(tag);
            }

            return tags;
        }

        /// <summary>
        /// Create a TLV tag 
        /// </summary>
        /// <param name="tag">The tag name</param>
        /// <param name="data">The tag data</param>
        public static TLVTag Create(byte[] tagName, byte[] data)
        {
            TLVTag tag = new TLVTag();
            tag.Tag = tagName;
            tag.DataObjectType = TLVDataObjectType.PrimitiveDataObject;
            tag.Value = data;

            return tag;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Tag:       " + BitConverter.ToString(Tag));
            sb.AppendLine("Length:    " + Length.ToString());
            sb.AppendLine("Value(raw):" + BitConverter.ToString(Value));
            sb.AppendLine("Value:     " + Encoding.ASCII.GetString(Value).Replace("\a", "|"));

            return sb.ToString();
        }
    }
}
