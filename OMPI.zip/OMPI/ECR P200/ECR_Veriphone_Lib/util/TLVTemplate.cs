﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECR_Veriphone_Lib.util
{
    public class TLVTemplate : TLVData
    {
        public List<TLVTemplate> ChildTemplates { get; set; }
        public List<TLVTag> Tags { get; set; }

        public TLVTemplate()
            : base()
        {
            ChildTemplates = new List<TLVTemplate>();
            Tags = new List<TLVTag>();
        }

        /// <summary>
        /// Parses out a TLVTemplate object from the supplied data. This recursively parses any 'nested' templates and tags from the data-portion
        /// </summary>
        /// <remarks>
        /// The full data supplied may or may not be used, as only the first TLV object is parsed out
        /// </remarks>
        public static List<TLVTemplate> ParseAll(byte[] data)
        {
            List<TLVTemplate> templates = new List<TLVTemplate>();

            int valueOffset = 0;
            while (valueOffset < data.Length && valueOffset != -1)
            {
                TLVTemplate tlvTemplate = new TLVTemplate();
                tlvTemplate.Parse(data, ref valueOffset);

                // Parse out any tags
                int offset = 0;
                while (offset >= 0)
                {
                    TLVTag tag = new TLVTag();
                    int offs = tag.Parse(tlvTemplate.Value, ref offset);
                    tlvTemplate.Tags.Add(tag);
                }

                templates.Add(tlvTemplate);
            }

            return templates;
        }

        public static TLVTemplate Create(byte[] templateName, List<TLVTag> tags)
        {
            TLVTemplate template = new TLVTemplate();
            template.Tag = templateName;
            template.Tags = tags;
            return template;
        }

        public new byte[] Serialize()
        {
            List<byte> templateData = new List<byte>();

            List<byte> tagData = new List<byte>();
            foreach (TLVTag tag in Tags)
            {
                tagData.AddRange(tag.Serialize());
            }

            this.Value = tagData.ToArray();

            return base.Serialize();
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Template:  " + BitConverter.ToString(Tag));
            sb.AppendLine("Length:    " + Length.ToString());
            sb.AppendLine("Value(raw):" + BitConverter.ToString(Value));
            sb.AppendLine("Value:     " + Encoding.ASCII.GetString(Value));
            sb.AppendLine(" ** Tags ** ");
            foreach (TLVTag tag in Tags)
            {
                sb.AppendLine("---------------------------");
                sb.Append(tag.ToString());
            }

            return sb.ToString();
        }
    }
}
