﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OMPI
{
    public class CardDataOMPI
    {
    public string EntryMode { get; set; }
        public string CZ { get; set; }
        public string ES { get; set; }
        public string R1 { get; set; }
        public int EntryCapability { get; set; }
        public string GetValue(string value, bool throwIfNotFound)
        {
            string result = "";
            switch(value)
            {
                case "EntryMode":
                    result = $"{EntryMode}{EntryCapability}";
                    break;
                case "CZ":
                    result = CZ;
                    break;
                case "ES":
                    result = ES;
                    break;
                case "R1":
                    result = R1;
                    break;
                default:
                    if (throwIfNotFound)
                        throw new ArgumentException("Propiedad no encontrada");
                    else
                        result = "";
                    break;
            }

            return result;
        }
    }
}
