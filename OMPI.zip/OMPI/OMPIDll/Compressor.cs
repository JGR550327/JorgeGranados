﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OMPI
{
    //---------------------------------------*
    // Name         : Compressor
    // Description  : Clase tipo extensi'on para cadenas 
    // Parameters   : 
    // Author       : Jorge Granados
    // Date         : 09/11/2020
    //---------------------------------------*
    public static class Compressor
    {
        //---------------------------------------*
        // Name         : Compress
        // Description  : Comprime un texto usando GZIP
        // Parameters   : string text -> Texto a comprimir
        // Author       : Jorge Granados
        // Date         : 09/11/2020
        //---------------------------------------*
        public static string Compress(this string text)
        {
            var buffer = Encoding.UTF8.GetBytes(text);
            var memoryStream = new MemoryStream();

            using (var stream = new GZipStream(memoryStream, CompressionMode.Compress, true))
            {
                stream.Write(buffer, 0, buffer.Length);
            }

            memoryStream.Position = 0;
            var compressed = new byte[memoryStream.Length];

            memoryStream.Read(compressed, 0, compressed.Length);

            var gZipBuffer = new byte[compressed.Length + 4];

            Buffer.BlockCopy(compressed, 0, gZipBuffer, 4, compressed.Length);

            Buffer.BlockCopy(BitConverter.GetBytes(buffer.Length), 0, gZipBuffer, 0, 4);

            return Convert.ToBase64String(gZipBuffer);
        }

        //---------------------------------------*
        // Name         : Decompress
        // Description  : Descomprime un texto usando GZIP
        // Parameters   : string text -> Texto a descomprimir
        // Author       : Jorge Granados
        // Date         : 09/11/2020
        //---------------------------------------*
        public static string Decompress(this string compressedText)
        {
            var gZipBuffer = Convert.FromBase64String(compressedText);

            using (var memoryStream = new MemoryStream())
            {

                int dataLength = BitConverter.ToInt32(gZipBuffer, 0);

                memoryStream.Write(gZipBuffer, 4, gZipBuffer.Length - 4);

                var buffer = new byte[dataLength];
                memoryStream.Position = 0;

                using (var gZipStream = new GZipStream(memoryStream, CompressionMode.Decompress))
                {
                    gZipStream.Read(buffer, 0, buffer.Length);
                }

                return Encoding.UTF8.GetString(buffer);
            }
        }
    }
}