﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Xml;

namespace OMPI
{
    public class DataLogicSKUDictionary
    {
      public  List<DataLogicService> DataLogicServices = new List<DataLogicService>();


      public static DataLogicSKUDictionary LoadFromXml(XmlNode baseNode)
      {

          DataLogicSKUDictionary result = new DataLogicSKUDictionary();

          if (!baseNode.Name.Equals("DataLogicSKUDictionary"))
              throw new Exception(string.Format("Unexpected node name '{0}'", baseNode.Name));
          
          List<DataLogicService> DataLogicServices = new List<DataLogicService>();
          XmlNode current = baseNode;

          

          current = current.FirstChild;
          while (current != null)
          {
              if (current.Name.Equals("Service", StringComparison.InvariantCultureIgnoreCase))
                  DataLogicServices.Add(DataLogicService.LoadFromXml(current));
              else
                  throw new Exception(string.Format("Unexpected node '{0}'", current.Name));

                  current = current.NextSibling;
          }

          result.DataLogicServices = DataLogicServices;

          return result;
      }

    }
}
