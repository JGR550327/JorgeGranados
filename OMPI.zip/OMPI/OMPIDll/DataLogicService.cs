﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace OMPI
{
    public class DataLogicService
    {
        private string sku;

        public string SKU
        {
            get { return sku; }
            
        }

        private string description;

        public string Description
        {
            get { return description; }
            
        }

        public DataLogicService( string sku, string description)
        {
            this.description = description;
            this.sku = sku;
        }

        public static DataLogicService LoadFromXml(XmlNode baseNode)
        {
            XmlAttribute attr;
            string sku;
          
            string description;

        

            if ((attr = baseNode.Attributes["Description"]) == null)
                throw new Exception(string.Format("Missing attribute 'Description'"));
            else
                description = attr.Value;

            if ((attr = baseNode.Attributes["SKU"]) == null)
                throw new Exception(string.Format("Missing attribute 'Sku'"));
            else
                sku = attr.Value;


            DataLogicService result = new DataLogicService(sku, description);

            XmlNode current = baseNode.FirstChild;

            
            return result;

        }
        

    }
}
