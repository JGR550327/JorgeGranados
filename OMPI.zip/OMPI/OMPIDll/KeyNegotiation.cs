﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace MessageSecurity
{
    public class KeyNegotiation
    {
        //private const int KEY_SIZE = 8192;
        private const int KEY_SIZE = 2048;

        public static RSACryptoServiceProvider GetNewAsymmetricKey()
        {
            //Generate a public/private key pair.
            return new RSACryptoServiceProvider(KEY_SIZE);
        }

        public static RSACryptoServiceProvider GetRSA(string rsaXml)
        {
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
            rsa.FromXmlString(rsaXml);

            return rsa;        
        }

        public static string GetAsymmetricKeyData(RSACryptoServiceProvider rsa)
        {
            return rsa.ToXmlString(false);
        }

        public static string ExportKey(RSACryptoServiceProvider rsa, byte[] rsaKek, bool includePrivateParameters)
        {
            byte[] keyBlob = rsa.ExportCspBlob(includePrivateParameters);

            if (includePrivateParameters)
                return EncryptKey(rsaKek, keyBlob);
            else
                return Convert.ToBase64String(keyBlob);
        }

        public static RSACryptoServiceProvider ImportKey(string key, byte[] rsaKek, bool includePrivateParameters)
        {
            RSACryptoServiceProvider result = new RSACryptoServiceProvider();

            byte[] keyBlob = null;
            if (includePrivateParameters)
                keyBlob = DecryptKey(rsaKek, key);
            else
                keyBlob = Convert.FromBase64String(key);

            result.ImportCspBlob(keyBlob);

            return result;
        }

        public static string EncryptKey(byte[] kek, byte[] keyBlob)
        {
            return Convert.ToBase64String(MessageCipher.Encrypt(kek, keyBlob));
        }

        public static byte[] DecryptKey(byte[] kek, string key)
        {
            return MessageCipher.Decrypt(kek, Convert.FromBase64String(key));
        }



    }
}
