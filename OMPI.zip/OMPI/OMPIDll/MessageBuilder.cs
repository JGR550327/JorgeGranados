﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Security.Cryptography.Xml;

using PinPadCommunication;

namespace OMPI
{
    public class MessageBuilder
    {

        private static void buildMessage(MessageDirections msgDirection, string operationCode, MsgConfiguration msgCfg, MsgAttributes msgAttr, CardData cardData, MessageData inReqSrcMessage, MessageData inReqSnkMessage, MessageData inRspSnkMessage, CardDataOMPI cardDataOMPI, out MessageData outMessage)
        {
            outMessage = null;

            MsgOperation operation;

            //string mti = null;

            if ((operation = msgCfg.GetMessageOperation(operationCode)) == null)
                throw new Exception(string.Format("Message operation '{0}' was not found in configuration", operationCode));
            else
            {
                MsgTransaction msgTransaction;
                MsgStructure outStructure = null;
                MsgDefinitionTypes outDefinitionType = MsgDefinitionTypes.Xml;
                Dictionary<string, MsgField> outFields = null;
                Dictionary<string, MsgFieldDefinition> outFieldDefinitions = null;
                MsgGeneralParameters mgp = msgCfg.GeneralParameters;


                string header = null;
                string mti = null;

                switch (msgDirection)
                {
                    case MessageDirections.Request:
                        msgTransaction = operation.Request;
                        mti = msgTransaction.Mti;
                        outDefinitionType = msgCfg.SinkMessageDefinition.MessageDefinitionType;
                        outFieldDefinitions = msgCfg.SinkMessageDefinition.Fields;
                        outStructure = msgTransaction.SnkMsgStructure;
                        outFields = outStructure.Fields;
                        header = msgCfg.SinkMessageDefinition.RequestHeader;
                        break;
                    case MessageDirections.Response:
                        msgTransaction = operation.Response;
                        mti = msgTransaction.Mti;
                        outDefinitionType = msgCfg.SourceMessageDefinition.MessageDefinitionType;
                        outFieldDefinitions = msgCfg.SourceMessageDefinition.Fields;
                        outStructure = msgTransaction.SrcMsgStructure;
                        outFields = outStructure.Fields;
                        header = msgCfg.SourceMessageDefinition.ResponseHeader;
                        break;
                    case MessageDirections.Reversal:
                        msgTransaction = operation.Reversal;
                        mti = msgTransaction.Mti;
                        outDefinitionType = msgCfg.SinkMessageDefinition.MessageDefinitionType;
                        outFieldDefinitions = msgCfg.SinkMessageDefinition.Fields;
                        outStructure = msgTransaction.SnkMsgStructure;
                        outFields = outStructure.Fields;
                        header = msgCfg.SinkMessageDefinition.RequestHeader;
                        break;
                }


                outMessage = new MessageData(outDefinitionType, header, mti);

                Dictionary<string, string> inReqSrcDict = null;
                Dictionary<string, string> inReqSnkDict = null;
                Dictionary<string, string> inRspSnkDict = null;

                if (inReqSrcMessage != null)
                    inReqSrcDict = inReqSrcMessage.FieldValues;
                if (inReqSnkMessage != null)
                    inReqSnkDict = inReqSnkMessage.FieldValues;
                if (inRspSnkMessage != null)
                    inRspSnkDict = inRspSnkMessage.FieldValues;

                foreach (KeyValuePair<string, MsgField> kvp in outFields)
                {
                    MsgField mf = kvp.Value;
                    bool valueIsMandatory = mf.GetMandatory(mgp, msgAttr, cardData, inReqSrcDict, inReqSnkDict, inRspSnkDict, cardDataOMPI);

                    string fieldValue = mf.GetValue(false, mgp, msgAttr, outFieldDefinitions, cardData, inReqSrcDict, inReqSnkDict, inRspSnkDict, cardDataOMPI);

                    if (fieldValue == null)
                    {
                        if (valueIsMandatory)
                            throw new Exception(string.Format("Could not retrieve value for mandatory field '{0}'", mf.Key));
                    }
                    else
                    {
                        outMessage.FieldValues.Add(mf.Key, fieldValue);
                    }
                }
            }
        }


        public static void BuildRequestMessage(string operationCode, MsgConfiguration msgCfg, MsgAttributes msgAttr, CardData cardData, MessageData inMessage, CardDataOMPI cardDataOMPI, out MessageData outMessage)
        {
            buildMessage(MessageDirections.Request, operationCode, msgCfg, msgAttr, cardData, inMessage, null, null, cardDataOMPI, out outMessage);
        }

        public static void BuildResponseMessage(string operationCode, MsgConfiguration msgCfg, MsgAttributes msgAttr, CardData cardData, MessageData inReqSrcMessage, MessageData inReqSnkMessage, MessageData inRspSnkMessage, CardDataOMPI cardDataOMPI, out MessageData outMessage)
        {
            buildMessage(MessageDirections.Response, operationCode, msgCfg, msgAttr, cardData, inReqSrcMessage, inReqSnkMessage, inRspSnkMessage, cardDataOMPI, out outMessage);
        }

        public static void BuildReversalMessage(string operationCode, MsgConfiguration msgCfg, MsgAttributes msgAttr, CardData cardData, MessageData inReqSrcMessage, MessageData inReqSnkMessage, MessageData inRspSnkMessage, CardDataOMPI cardDataOMPI, out MessageData outMessage)
        {
            buildMessage(MessageDirections.Reversal, msgAttr.OperationCode, msgCfg, msgAttr, cardData, inReqSrcMessage, inReqSnkMessage, inRspSnkMessage, cardDataOMPI, out outMessage);
        }


        //public static void BuildReversalMessage(MsgConfiguration msgCfg, CardData cardData, MessageData reqSnkMessage, MessageData outMessage)
        //{ 
        //    MsgType srcMsgType = msgCfg.GetMessageType(reqSnkMessage.Mti);

        //    outMessage = null;


        //    Dictionary<string, string> outFields = reqSnkMessage.FieldValues;

        //    MsgDefinitionTypes outDefinitionType = msgCfg.SinkMessageDefinition.MessageDefinitionType;
        //    string msgId = msgCfg.Id;
        //    string header = msgCfg.SinkMessageDefinition.Header;
        //    string mti = srcMsgType.ReversalMti;

        //    outMessage = new MessageData(outDefinitionType, msgId, header, mti);

        //    foreach (KeyValuePair<string, string> kvp in outFields)
        //    {
        //        //TODO: remove sensitive data
        //        outMessage.FieldValues.Add(kvp.Key, kvp.Value);
        //    }
        //}

        public static string BuildErrorMessage(string operationCode, string errorType, string errorDescription)
        {
            XmlDocument xmlDoc = new XmlDocument();

            XmlElement current = (XmlElement)xmlDoc.AppendChild(xmlDoc.CreateElement("Response"));

            current.SetAttribute("Operation_Code", operationCode);

            current = (XmlElement)current.AppendChild(xmlDoc.CreateElement("error"));

            XmlAttribute attr = xmlDoc.CreateAttribute("type");
            attr.Value = errorType;
            current.Attributes.Append(attr);

            current.InnerText = errorDescription;

            return xmlDoc.OuterXml;

        }


        private static bool verifyXml(XmlDocument xmlDocument, RSA rsaKey)
        {
            bool result = false;

            // Check arguments
            if (xmlDocument == null)
                throw new ArgumentException("xmlDocument");

            if (rsaKey == null)
                result = true;
            else
            {

                SignedXml signedXml = new SignedXml(xmlDocument);
                XmlNodeList nodeList = xmlDocument.GetElementsByTagName("Signature");

                // Throw an exception if no signature was found
                if (nodeList.Count == 1)
                {
                    // Load the first <DocumentSignature> node  
                    signedXml.LoadXml((XmlElement)nodeList[0]);

                    // Check the signature and return the result
                    result = signedXml.CheckSignature(rsaKey);
                }
            }

            return result;
        }

        public static Dictionary<string, MsgConfiguration> LoadConfiguration(string xmlFile, RSACryptoServiceProvider rsaKey)
        {
            Dictionary<string, MsgConfiguration> result = new Dictionary<string, MsgConfiguration>();

            XmlReaderSettings xrs = new XmlReaderSettings();
            xrs.IgnoreComments = true;
            xrs.IgnoreWhitespace = false;

            using (XmlReader reader = XmlReader.Create(xmlFile, xrs))
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(reader);

                if (!verifyXml(doc, rsaKey))
                    throw new Exception("Invalid document signature");

                XmlNode root = doc.FirstChild.NextSibling;
                XmlNode current;

                if (!root.Name.Equals("Messages"))
                    throw new Exception("Invalid XML structure");

                if (!root.Attributes["version"].Value.Equals("1.0"))
                    throw new Exception("Unexpected file version");

                current = root.FirstChild;

                while (current != null)
                {
                    switch (current.Name)
                    {
                        case "MessageFactory":
                            string id = current.Attributes["id"].Value;

                            MsgConfiguration msg = MsgConfiguration.LoadFromXml(current, rsaKey);
                            result.Add(id, msg);
                            break;

                        case "Signature":
                            // Ignore
                            break;
                        default:
                            throw new Exception(string.Format("Unexpected node '{0}'", current.Name));
                    }



                    current = current.NextSibling;
                }
            }

            return result;
        }
    }
}
