﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace MessageSecurity
{

    public class MessageCipher
    {

        public enum KeyLength
        {
            Unknown = 0,
            Single = 1,
            Double = 2,
            Triple = 3
        }


        private const int KEYSIZE = 256;
        private static ReadOnlyCollection<byte> DEFAULT_IV = new ReadOnlyCollection<byte>(new List<byte>() { 0xF8, 0xF4, 0x72, 0x30, 0x2B, 0x98, 0x6A, 0x40, 0xC9, 0xD5, 0xAF, 0x47, 0xE4, 0xDE, 0xD5, 0x2A });

        public static AesManaged GetNewSymmetricProvider()
        {
            RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();

            byte[] newKey = new byte[KEYSIZE / 8];
            rng.GetBytes(newKey);

            return GetSymmetricProvider(newKey);
        }

        public static AesManaged GetSymmetricProvider(byte[] key)
        {
            AesManaged aesProvider = new AesManaged();

            // Thanks a lot WP....
            //aesProvider.Padding = PaddingMode.PKCS7;
            aesProvider.BlockSize = 128;
            aesProvider.KeySize = KEYSIZE;
            //aesProvider.Mode = CipherMode.CBC;
            aesProvider.Key = key;
            aesProvider.IV = DEFAULT_IV.ToArray<byte>();

            return aesProvider;
        }

        public static byte[] Encrypt(byte[] key, byte[] plainBytes)
        {
            byte[] result = null;

            using (AesManaged aesProvider = GetSymmetricProvider(key))
            {   
                result = aesProvider.CreateEncryptor().TransformFinalBlock(plainBytes, 0, plainBytes.Length);
            }

            return result;
        }

        public static string Encrypt(byte[] key, string plainMessage)
        {
            byte[] plainBytes = Encoding.UTF8.GetBytes(plainMessage);

            byte[] result = Encrypt(key, plainBytes);

            return Convert.ToBase64String(result);
        }

        public static byte[] Decrypt(byte[] key, byte[] cipherBytes)
        {
            byte[] result = null;

            using (AesManaged aesProvider = GetSymmetricProvider(key))
            {
                result = aesProvider.CreateDecryptor().TransformFinalBlock(cipherBytes, 0, cipherBytes.Length);
            }

            return result;
        }

        public static string Decrypt(byte[] key, string cipherMessage)
        {
            byte[] cipherBytes = Convert.FromBase64String(cipherMessage);

            byte[] result = Decrypt(key, cipherBytes);

            return Encoding.UTF8.GetString(result);
        }

        public static string EncryptComponent(RSACryptoServiceProvider rsa, byte[] key)
        {
            byte[] aux = rsa.Encrypt(key, false);

            return Convert.ToBase64String(aux);
        }

        public static byte[] DecryptComponent(RSACryptoServiceProvider rsa, string key)
        {
            byte[] aux = Convert.FromBase64String(key);

            return rsa.Decrypt(aux, false);
        }

        public static byte[] GetRandomComponent(KeyLength length)
        {
            RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();

            byte[] result = new byte[(int)length * 16];

            rng.GetBytes(result);

            return result;
        }

        public static KeyLength GetComponentLength(byte[] src)
        {
            KeyLength result = KeyLength.Unknown;

            switch (src.Length)
            {
                case 16:
                    result = KeyLength.Single;
                    break;
                case 32:
                    result = KeyLength.Double;
                    break;
                case 48:
                    result = KeyLength.Triple;
                    break;
                default:
                    throw new Exception(string.Format("Invalid key length ({0})", src.Length));
            }

            return result;
        }

        public static byte[] CompoundKey(byte[] componentA, byte[] componentB)
        {
            if (componentA.Length != componentB.Length)
                throw new Exception("Keys must be the same length");
        
            byte[] result = new byte[componentA.Length];
            for (int i = 0; i < componentA.Length; i++)
                result[i] = (byte)(componentA[i] ^ componentB[i]);

            return result;
        }

    }
}
