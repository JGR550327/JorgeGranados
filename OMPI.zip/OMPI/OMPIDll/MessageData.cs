﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
using System.Xml;

namespace OMPI
{
    [Serializable()]
    public class MessageData
    {
        MsgDefinitionTypes msgDefinitionType;

        private string header;
        private string mti;
        private Dictionary<string, string> fieldValues;

        public MessageData(MsgDefinitionTypes msgDefinitionType, string header, string mti)
        {
            this.msgDefinitionType = msgDefinitionType;
            this.header = header;
            this.mti = mti;

            fieldValues = new Dictionary<string, string>();
        }

        public MessageData(MsgDefinitionTypes msgDefinitionType, string header, string mti, Dictionary<string, string> fieldValues)
            : this(msgDefinitionType, header, mti)
        {
            // I'd rather copy dictionary contents instead of just referencing them...
            foreach (KeyValuePair<string, string> kvp in fieldValues)
            {
                this.fieldValues.Add(kvp.Key, kvp.Value);
            }
        }

        public string Header
        {
            get { return header; }
        }

        public string Mti
        {
            get { return mti; }
        }

        public Dictionary<string, string> FieldValues
        {
            get { return fieldValues; }
        }


        private string getMessageTransakcio()
        {
            char fieldSeparator = '\x1c';
            StringBuilder sb = new StringBuilder();

            sb.Append(header);
            //CSR 20120816 NO FIELD SEPARATOR BETWEEN HEADER AND MTI
            //sb.Append(fieldSeparator);

            sb.Append(mti);
            //sb.Append(fieldSeparator);

            foreach (KeyValuePair<string, string> kvp in fieldValues)
            {
                string bitKey = kvp.Key;
                string value = kvp.Value;

                if (!string.IsNullOrEmpty(value))
                {
                    sb.Append(fieldSeparator);
                    sb.AppendFormat("{0:D3}", Int32.Parse(bitKey, CultureInfo.InvariantCulture));
                    sb.Append(value);
                }
            }

            sb.Append('\x03');
            //sb.Append('\x03');

            return sb.ToString();

        
        }



        public static string GetFieldValueISO8583(MsgFieldDefinition mfd, string value)
        {
            if (mfd.VariableLength)
            {
                string zeros = new string('0', mfd.LenLength);
                string format = "{0:" + zeros + "}";
                return string.Concat(string.Format(format, value.Length), value);
            }
            else
                return value;
        }

        private static void parseFieldValueISO8583(MsgFieldDefinition mfd, string msg, int pos, out string parsedValue, out int parsedLength)
        {
            int fieldLength;
            int lenLength = 0;

            if (mfd.VariableLength)
            {
                lenLength = mfd.LenLength;

                if (pos + mfd.LenLength > msg.Length)
                    throw new Exception("Message is too short");
                else if (!Int32.TryParse(msg.Substring(pos, mfd.LenLength), out fieldLength))
                    throw new Exception(string.Format("Error trying to read variable field length ({0}) for key {1}", msg.Substring(pos, mfd.LenLength), mfd.Key));

                if (fieldLength > mfd.Length)
                    throw new Exception(string.Format("Specified length is longer than the maximum ({0} > {1}) for key {1}", fieldLength, mfd.Length, mfd.Key));
            }
            else
                fieldLength = mfd.Length;

            string value = null;

            if (pos + lenLength + fieldLength > msg.Length)
                throw new Exception("Message is too short");
            else
            {
                value = msg.Substring(pos + lenLength, fieldLength);

                if (!mfd.ValidateData(value))
                    throw new Exception(string.Format("Field content does not comply with field definition ({0}): ({1}) for key {2}", mfd.DataType, value.Substring(0, (value.Length > 50 ? 50 : value.Length)), mfd.Key));
                else
                    parsedLength = lenLength + fieldLength;
            }

            parsedValue = value;

        }

        private string getMessageISO8583(MsgDefinition msgDefinition)
        {
            StringBuilder sbHeader = new StringBuilder();
            StringBuilder sbValues = new StringBuilder();

            bool useSecondaryBitmap = false;
            int lastInt = 8;

            int[] bitmap = new int[16];
            for (int i = 0; i < 16; i++)
                bitmap[i] = 0;

            for (int bit = 0; bit < 128; bit++)
            {
                string f = bit.ToString(CultureInfo.InvariantCulture);
                string value;

                if (fieldValues.TryGetValue(f, out value) && (value != null))
                {
                    int currentByte = (bit % 8 == 0) ? (bit / 8 - 1) : (bit / 8);
                    bitmap[currentByte] |= (1 << (8 * (currentByte + 1) - bit));


                    MsgFieldDefinition mfd;
 
                    if(msgDefinition.Fields.ContainsKey(f))
                       mfd = msgDefinition.Fields[f];
                    else
                        throw new Exception(string.Format("Key not found {0}",f));

                    sbValues.Append(GetFieldValueISO8583(mfd, value));

                    if (bit > 64)
                        useSecondaryBitmap = true;
                }
            
            }


            if (useSecondaryBitmap)
            {
                bitmap[0] |= (1 << 7);
                lastInt = 16;
            }

            if (header != null)
                sbHeader.Append(header);

            sbHeader.Append(mti);

            if (msgDefinition.BitmapType == BitmapTypes.HEX)
            {
                for (int i = 0; i < lastInt; i++)
                    sbHeader.Append(string.Format("{0:X2}", bitmap[i]));
            }
            else
                throw new Exception("Binary bitmap not implemented yet");

            return string.Concat(sbHeader.ToString(), sbValues.ToString());
        }

        private static void fromMessageTransakcio(string message, out string messageId, out MessageData result)
        {
            messageId = null;

            const char FIELD_SEPARATOR = '\x1c';
            const char END_TEXT = '\x03';

            int lastSeparatorIndex;

            try
            {
                int separatorIndex = message.IndexOf(FIELD_SEPARATOR);
                string header = message.Substring(0, separatorIndex - 5);
                lastSeparatorIndex = separatorIndex;

                //separatorIndex = message.IndexOf(fieldSeparator, lastSeparatorIndex + 1);
                //string mti = message.Substring(lastSeparatorIndex + 1, separatorIndex - lastSeparatorIndex - 1);
                string mti = message.Substring(separatorIndex - 4, 4);

                lastSeparatorIndex = separatorIndex;

                result = new MessageData(MsgDefinitionTypes.ISO8583_Transakcio, header, mti);

                separatorIndex = message.IndexOf(FIELD_SEPARATOR, lastSeparatorIndex + 1);

                bool lastField = false;
                while (separatorIndex > -1)
                {
                    if (separatorIndex - lastSeparatorIndex - 1 <= 0)
                        break;

                    string fieldData = message.Substring(lastSeparatorIndex + 1, separatorIndex - lastSeparatorIndex - 1);

                    string bitKey = Int32.Parse(fieldData.Substring(0, 3), CultureInfo.InvariantCulture).ToString(CultureInfo.InvariantCulture);
                    string value = fieldData.Substring(3);

                    result.fieldValues.Add(bitKey, value);

                    lastSeparatorIndex = separatorIndex;

                    if ((message[separatorIndex] == END_TEXT) || lastField)
                        break;

                    if ((separatorIndex = message.IndexOf(FIELD_SEPARATOR, lastSeparatorIndex + 1)) <= -1)
                    {
                        separatorIndex = message.IndexOf(END_TEXT, lastSeparatorIndex + 1);
                        lastField = true;
                    }
                }
            }
            catch (Exception ex)
            { 
                throw new Exception(string.Format("Error en mensaje [{0}], {1}", message, ex));
            }

        }



        private static int parseBitmapHex(string msg, int pos, int primaryBitmapSize, int secondaryBitmapSize, out List<int> result)
        {
            int bitmaps = 0;
            int finalByte = 8;

            result = new List<int>();


            bool nextBitmap = true;


            while (nextBitmap)
            {
                bitmaps++;
                int nextBitmapBit = 1;
                int charOffset = 0;

                if (bitmaps == 1)
                {
                    charOffset = 0;
                    nextBitmapBit = 1;
                    finalByte = primaryBitmapSize;
                }
                else if (bitmaps == 2)
                {
                    charOffset = 2 * primaryBitmapSize;
                    nextBitmapBit = 8 * primaryBitmapSize + 1;
                    finalByte = secondaryBitmapSize;
                }
                else
                {
                    charOffset = 2 * primaryBitmapSize + 2 * secondaryBitmapSize * (bitmaps - 1);
                    nextBitmapBit = 8 * primaryBitmapSize + 8 * secondaryBitmapSize * (bitmaps - 1) + 1;
                    finalByte = secondaryBitmapSize;
                }

                for (int i = 0; i < finalByte; i++)
                {
                    string hexNum = msg.Substring(pos + charOffset + 2 * i, 2);
                    byte b = byte.Parse(hexNum, System.Globalization.NumberStyles.AllowHexSpecifier);

                    for (int bit = 7; bit >= 0; bit--)
                    {
                        if ((b & (1 << bit)) != 0)
                        {
                            if ((8 * (i + 1) - bit + nextBitmapBit - 1) != nextBitmapBit)
                                result.Add(8 * (i + 1) - bit + nextBitmapBit - 1);
                        }
                    }
                }

                nextBitmap = ((byte.Parse(msg.Substring(pos + charOffset, 2), System.Globalization.NumberStyles.AllowHexSpecifier) & (1 << 7)) != 0);
            }

            if (bitmaps == 1)
                return 2 * primaryBitmapSize;
            else
                return 2 * (primaryBitmapSize + secondaryBitmapSize * (bitmaps - 1));

        }

        private static void fromMessageISO8583(MessageDirections msgDirection, MsgDefinition msgDefinition, string message, out string messageId, out MessageData result)
        {
            int pos = 0;
            List<int> fields;
            
            messageId = null;

            string header;

            switch (msgDirection)
            { 
                case MessageDirections.Request:
                    header = msgDefinition.RequestHeader;
                    break;
                case MessageDirections.Response:
                    header = msgDefinition.ResponseHeader;
                    break;
                default:
                    throw new Exception(string.Format("Unexpected message direction '{0}'", msgDirection));
            }

            if (!string.IsNullOrEmpty(header))
            {
                if (!message.StartsWith(header))
                    throw new Exception("Unexpected message header");

                pos += header.Length;
            }

            string parsedMti = message.Substring(pos, 4);
            pos += 4;

            int bitmapSize = parseBitmapHex(message, pos, 8, 8, out fields);

            pos += bitmapSize;

            result = new MessageData(MsgDefinitionTypes.ISO8583, header, parsedMti);

            Dictionary<string, MsgFieldDefinition> fieldDict = msgDefinition.Fields;

            foreach (int b in fields)
            {
                string f = b.ToString(CultureInfo.InvariantCulture);
                    
                MsgFieldDefinition mfd;
                if (!fieldDict.TryGetValue(f, out mfd))
                    throw new Exception(string.Format("Undefined field '{0}'", b));

                int fieldSize;
                string parsedValue;

                parseFieldValueISO8583(mfd, message, pos, out parsedValue, out fieldSize);

                result.fieldValues.Add(f, parsedValue);

                pos += fieldSize;
            }

        }


        private static string beautifyXml(XmlDocument doc)
        {
            StringBuilder sb = new StringBuilder();
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.OmitXmlDeclaration = true;
            settings.Indent = true;
            settings.IndentChars = "  ";
            settings.NewLineChars = "\r\n";
            settings.NewLineHandling = NewLineHandling.Replace;
            XmlWriter writer = XmlWriter.Create(sb, settings);
            doc.Save(writer);
            writer.Close();
            return sb.ToString();
        }

        private string getMessageXml()
        {
            XmlDocument xmlDoc = new XmlDocument();
            //xmlDoc.CreateXmlDeclaration("1.0", "utf-8", "yes");


            XmlElement current = (XmlElement)xmlDoc.AppendChild(xmlDoc.CreateElement("Response"));

            current.SetAttribute("Message_Type", mti);

            current = (XmlElement)current.AppendChild(xmlDoc.CreateElement("Fields"));

            foreach (KeyValuePair<string, string> kvp in fieldValues)
            {
                string fieldKey = kvp.Key;
                string value = kvp.Value;

                if (value != null)
                {
                    current.AppendChild(xmlDoc.CreateElement(fieldKey)).InnerText = value;
                }
            }

            return beautifyXml(xmlDoc);
        }



        private static MessageData fromMessageXml(string message, out string messageId, out MessageData result)
        {
            result = null;
            messageId = null;

            throw new Exception("NOT IMPLEMENTED");

            //string operationCode = null;

            //XmlDocument xmlDoc = new XmlDocument();
            //xmlDoc.LoadXml(message);

            //XmlNode current = xmlDoc.FirstChild;

            //if (!current.Name.Equals("Request", StringComparison.InvariantCultureIgnoreCase))
            //    throw new Exception(string.Format("Invalid XML structure.  Expected node '{0}', but node '{1}' was found.", "Request", current.Name));

            //XmlAttribute attr;

            //if ((attr = current.Attributes["Message_Id"]) == null)
            //    throw new Exception(string.Format("Invalid XML structure.  Node '{0}' must define attribute '{1}'.", "Request", "Message_Id"));
            //else
            //    messageId = attr.Value;

            //if ((attr = current.Attributes["Operation_Code"]) == null)
            //    throw new Exception(string.Format("Invalid XML structure.  Node '{0}' must define attribute '{1}'.", "Request", "Operation_Code"));
            //else
            //    operationCode = attr.Value;


            //result = new MessageData(MsgDefinitionTypes.Xml, null, mti);
            //Dictionary<string, string> fieldValues = result.fieldValues;

            //current = current.FirstChild;

            //if (!current.Name.Equals("Fields", StringComparison.InvariantCultureIgnoreCase))
            //    throw new Exception(string.Format("Invalid XML structure.  Expected node '{0}', but node '{1}' was found.", "Fields", current.Name));

            //current = current.FirstChild;

            //while (current != null)
            //{
            //    fieldValues.Add(current.Name, current.InnerXml);
            //    current = current.NextSibling;
            //}

            //return result;
        }




        public string GetMessage(MsgDefinition msgDefinition)
        {
            string result = null;


            switch (msgDefinitionType)
            {
                case MsgDefinitionTypes.Xml:
                    result = getMessageXml();
                    break;
                case MsgDefinitionTypes.ISO8583_Transakcio:
                    result = getMessageTransakcio();
                    break;
                case MsgDefinitionTypes.ISO8583:
                    result = getMessageISO8583(msgDefinition);
                    break;
                default:
                    throw new Exception(string.Format("NOT IMPLEMENTED FOR DEFINTION TYPE '{0}'", msgDefinitionType));
            }


            return result;
        }


        public static void FromXmlRequestMessage(string message, out string messageId, out MessageData result)
        {
            result = null;
            messageId = null;

            fromMessageXml(message, out messageId, out result);
        }

        public static void FromMessage(MessageDirections msgDirection, MsgDefinition msgDefinition, string message, out string messageId, out MessageData result)
        {
            result = null;
            messageId = null;

            switch (msgDefinition.MessageDefinitionType)
            {
                case MsgDefinitionTypes.Xml:
                    fromMessageXml(message, out messageId, out result);
                    break;
                case MsgDefinitionTypes.ISO8583_Transakcio:
                    fromMessageTransakcio(message, out messageId, out result);
                    break;
                case MsgDefinitionTypes.ISO8583:
                    fromMessageISO8583(msgDirection, msgDefinition, message, out messageId, out result);
                    break;
                default:
                    throw new Exception(string.Format("NOT IMPLEMENTED FOR DEFINTION TYPE '{0}'", msgDefinition.MessageDefinitionType));
            }

        }


        public int Validate(MsgDefinition msgDefinition, MsgStructure msgStructure, MsgGeneralParameters generalParameters, MsgAttributes msgAttr, out string errorDescription, CardDataOMPI cardDataOMPI)
        {
            int res = 0;
            errorDescription = null;

            Dictionary<string, MsgFieldDefinition> fieldDef = msgDefinition.Fields;
            MsgFieldDefinition mfd;

            // Verify that all fields are defined AND contain valid values
            foreach (KeyValuePair<string, string> kvp in fieldValues)
            {
                string fieldKey = kvp.Key;
                string value = kvp.Value;

                if (!fieldDef.TryGetValue(fieldKey, out mfd))
                {
                    errorDescription = string.Format("Undefined field '{0}'", fieldKey);
                    res = -1;
                    break;
                }
                else if (!msgStructure.Fields.ContainsKey(fieldKey) && msgStructure.ErrorWhenUnexpectedField)
                {
                    errorDescription = string.Format("Unexpected field '{0}'", fieldKey);
                    res = -1;
                    break;
                }
                else if (!mfd.ValidateData(value))
                {
                    errorDescription = string.Format("Invalid data in field '{0}' - '{1}'", fieldKey, value);
                    res = -2;
                    break;
                }
            }

            if (res == 0)
            {
                // Check there are no missing mandatory fields
                foreach (KeyValuePair<string, MsgField> kvp in msgStructure.Fields)
                {
                    string fieldKey = kvp.Key;
                    MsgField mf = kvp.Value;

                    bool mandatory = mf.GetMandatory(generalParameters, msgAttr, null, fieldValues, fieldValues, fieldValues, cardDataOMPI);

                    if (mandatory)
                    { 
                        string value;
                        if (!fieldValues.TryGetValue(fieldKey, out value))
                        {
                            errorDescription = string.Format("Missing field '{0}'", fieldKey);
                            res = -3;
                            break;
                        }
                        else if (string.IsNullOrEmpty(value))
                        {
                            errorDescription = string.Format("Field '{0}' is empty", fieldKey);
                            res = -4;
                            break;
                        }
                    }
                }
            }

            return res;
        }

    }
}
