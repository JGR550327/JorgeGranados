﻿//#define NOPINPAD
using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Sockets;
using PinPadCommunication;
using OMPITcpClient;
using PinPadCommunicationEGlobal;
using System.IO;
using System.Runtime.Serialization;
using System.Xml;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;
using System.Security.Cryptography;
using MessageSecurity;
using System.Security.AccessControl;
using ECR_Veriphone_Lib.core;
using ECR_Veriphone_Lib.util;
using NLog;
using System.Reflection;

namespace OMPI
{
    public enum MessageDirections
    {
        Request = 0,
        Response = 1,
        Reversal = 2
    }

    public enum MessageSides
    {
        Sink = 0,
        Source = 1
    }

    public enum MessageFlowErrors
    {
        NoError = 0,
        RequestValidationError = -1000,
        CommunicationError = -2000,
        ResponseValidationError = -3000,
        TrxErrorAndReverseCommunicationError = -4000,
        TrxErrorAndReverseError = -5000,
        TrxErrorAndReverseSuccessful = -6000,
        PinpadNeedNewKeys = -7000,
        PinpadError = -8000,
        ExceptionError = -9000,
        PublicKeyError = -9010
    }
    [Serializable()]
    public class MessageFlow
    {
        private MessageFlowErrors mfe;
        private bool mustReverse;
        private MessageData reqSrc;
        private MessageData reqSnk;
        private MessageData rspSrc;
        private MessageData rspSnk;

        private string sentReq;
        private string recvRsp;


        private string errMessage;
        public static bool initKey = false;
        public static string initKeyValue = "";

        public static bool setBinTable = false;
        public static string tokenET = "";

        public static Logger log = LogManager.GetCurrentClassLogger();

        //----------------------------------------------------------
        // this is a file list
        //----------------------------------------------------------
        public static string keyFlagFile = "C:\\Omnipays\\KeyFlagFile.txt";
        public static string tokenETFile = "C:\\Omnipays\\TokenET.txt";
        public static String binTableIdFile = "C:\\Omnipays\\BinTableId.txt";

        public static string terminalId = "";

        public MessageFlowErrors MessageFlowError { get { return mfe; } }
        public bool MustReverse { get { return mustReverse; } }
        public MessageData RequestSource { get { return reqSrc; } }
        public MessageData RequestSink { get { return reqSnk; } }
        public string SentRequest { get { return sentReq; } }
        public string ReceivedResponse { get { return recvRsp; } }
        public MessageData ResponseSink { get { return rspSnk; } }
        public MessageData ResponseSource { get { return rspSrc; } }

        public string ErrorMessage { get { return errMessage; } }

        private static Tcp_ClientBase.MessageFormats getMessageFormat(bool useLength)
        {
            if (useLength)
                return Tcp_ClientBase.MessageFormats.AddMessageLength;
            else
                return Tcp_ClientBase.MessageFormats.Raw;
        }

        private static bool sendMessage(MsgConfiguration msgConfig, string message, out string response, out Exception resultException)
        {
            bool mustReverse = false;
            response = null;
            resultException = null;

            UTF8Encoding encoder = new UTF8Encoding();

            Tcp_ClientBase tcpClient = null;

            try
            {
                string hostname = msgConfig.GeneralParameters.ConnectionInfo.Host;
                int port = msgConfig.GeneralParameters.ConnectionInfo.Port;
                int sendTimeout = msgConfig.GeneralParameters.ConnectionInfo.SendTimeout;
                int recvTimeout = msgConfig.GeneralParameters.ConnectionInfo.RecvTimeout;

                bool useSsl = msgConfig.GeneralParameters.ConnectionInfo.UseSsl;

                string sslCertificateName = null;
                if (useSsl)
                    sslCertificateName = msgConfig.GeneralParameters.ConnectionInfo.SslCertificateName;

                bool requestUseLength = msgConfig.SinkMessageDefinition.RequestUseLength;
                bool responseUseLength = msgConfig.SinkMessageDefinition.ResponseUseLength;

                byte[] messageStream = encoder.GetBytes(message);
                byte[] responseStream;

                tcpClient = Tcp_ClientBase.GetTcpClient(hostname, port, useSsl, sslCertificateName);
                tcpClient.OpenConnection();

                mustReverse = true;

                tcpClient.Send(messageStream, getMessageFormat(requestUseLength));
                responseStream = tcpClient.Receive(recvTimeout, getMessageFormat(responseUseLength));
                StringBuilder sb = new StringBuilder();

                UTF8Encoding responseEncoder = new UTF8Encoding();
                response = responseEncoder.GetString(responseStream);
                //foreach (var item in responseStream)
                //{
                //    sb.Append(Convert.ToChar(item));
                //}

                //response = sb.ToString(); ;
            }
            catch (SocketException ex)
            {

                resultException = new Exception(
                    string.Format("Ha ocurrido un error durante la comunicación con el servidor"));
            }
            catch (Exception ex)
            {
                resultException = ex;
            }
            finally
            {
                if (tcpClient != null)
                    tcpClient.CloseConnection();
            }

            return mustReverse;
        }


        public static ReversalResults ReverseMessage(string operationCode, MsgConfiguration msgConfig, string reversalMessage, out string errorDescription, CardDataOMPI cardDataOMPI)
        {
            ReversalResults result = ReversalResults.ExceptionError;

            try
            {
                string dummy;
                errorDescription = null;
                MessageData reqMsgData;

                MessageData.FromMessage(MessageDirections.Request, msgConfig.SinkMessageDefinition, reversalMessage, out dummy, out reqMsgData);

                MsgTransaction reqMsgType = msgConfig.GetMessageOperation(operationCode).Reversal;
                if ((reqMsgData.Validate(msgConfig.SinkMessageDefinition, reqMsgType.SnkMsgStructure, msgConfig.GeneralParameters, null, out errorDescription, cardDataOMPI)) < 0)
                {
                    // Cannot send a message that doesn't comply with validation...
                    result = ReversalResults.SourceMessageError;
                }
                else
                {
                    string snkRspMessage;
                    string rspMti = reqMsgType.ResponseMti;

                    Exception resultEx;
                    sendMessage(msgConfig, reversalMessage, out snkRspMessage, out resultEx);

                    if (resultEx != null)
                    {
                        errorDescription = resultEx.Message;
                        result = ReversalResults.CommunicationError;
                    }
                    else
                    {
                        MessageData rspSnkData;
                        MessageData.FromMessage(MessageDirections.Response, msgConfig.SinkMessageDefinition, snkRspMessage, out dummy, out rspSnkData);

                        MsgTransaction rspMsgType = msgConfig.GetMessageOperation(operationCode).ReversalResponse;
                        if ((rspSnkData.Validate(msgConfig.SinkMessageDefinition, rspMsgType.SnkMsgStructure, msgConfig.GeneralParameters, null, out errorDescription, cardDataOMPI)) < 0)
                        {
                            // Response doesn't even comply with validation...
                            result = ReversalResults.SinkMessageError;
                        }
                        else if (rspSnkData.FieldValues["39"].Equals("00"))
                            result = ReversalResults.Ok;
                        else if (rspSnkData.FieldValues["39"].Equals("91"))
                            result = ReversalResults.CommunicationError;
                        else
                            result = ReversalResults.Rejected;
                    }
                }
            }
            catch (Exception ex)
            {
                result = ReversalResults.ExceptionError;
                errorDescription = ex.Message;
            }

            return result;
        }


        public static ReversalResults ReverseMessage(string operationCode, MsgConfiguration msgConfig, MsgAttributes msgAttr, MessageData reqSrcData, MessageData reqSnkData, MessageData rspSnkData, CardData cardData, CardDataOMPI cardDataOMPI, out string errorDescription)
        {
            ReversalResults result = ReversalResults.ExceptionError;

            try
            {
                MessageData reversalData;
                MessageBuilder.BuildReversalMessage(operationCode, msgConfig, msgAttr, cardData, reqSrcData, reqSnkData, rspSnkData, cardDataOMPI, out reversalData);

                string reversalMessage = reversalData.GetMessage(msgConfig.SinkMessageDefinition);

                string snkMessage = reqSnkData.GetMessage(msgConfig.SinkMessageDefinition);

                result = ReverseMessage(operationCode, msgConfig, snkMessage, out errorDescription, cardDataOMPI);
            }
            catch (Exception ex)
            {
                result = ReversalResults.ExceptionError;
                errorDescription = ex.Message;
            }

            return result;
        }




        public static string FormatAmount(String amount)
        {
            amount = amount.Replace(",", "").Replace(".", "");

            amount = Utilidad.FillStringWith(amount, '0', 8, true);

            return amount;

        }



        /// <summary>
        /// Transacción para realizar una venta 
        /// </summary>
        public static TransactionResult performTransaction(byte trxType, Transaction_RS232 transaction,
                        String strMonto,
                        String strCashback,
                        String strTip,
                        String strMontoUSD,
                        String strCashbackUSD,
                        String strTipUSD

                        )
        {

            {

                //---------------------------------------------------------------------
                // Core Transaction
                //---------------------------------------------------------------------

                transaction.IncluirTimeout = true;

                DateTime rigth_now = DateTime.Now;


                transaction.setTransactionDate(rigth_now.ToString("yyMMdd"));
                transaction.setTransactionTime(rigth_now.ToString("HHmmss"));
                transaction.setVoucherNumber("12345678");
                transaction.setAmount(FormatAmount(strMonto));
                transaction.setCashback_Amount(FormatAmount(strCashback));
                transaction.setTip_Amount(FormatAmount(strTip));
                transaction.setAmount_USD(FormatAmount(strMontoUSD));
                transaction.setCashback_Amount_USD(FormatAmount(strCashbackUSD));
                transaction.setTip_Amount_USD(FormatAmount(strTipUSD));


                transaction.setTransactionType(trxType);
                transaction.setCurrencyIndex("01");
                transaction.setCurrencyCode("0484");

                transaction.EnmascararPAN = true;

                String E1 = "5F2A8284959A9C9F029F039F099F109F1A9F1E9F269F279F339F349F359F369F379F419F539F6E";

                transaction.setEmvTags(E1);
                transaction.setTransactionType(trxType);
                transaction.setAuthorizationCode("000000");

                //-----------------------------------------------------------------------------
                // Request BIN
                //-----------------------------------------------------------------------------

                TransactionResult trxResult = null;


                transaction.SendACK = true;

                log.Info($"Initiating Pinpad operation (Acquirence)");

                trxResult = transaction.Authorization(Instructions.C51_Authorization);

                log.Info($"Pinpad operation finished with ResponseCode: {trxResult.ResponseCode} ");

                return trxResult;

            }


        }
        /// <summary>
        /// Transacción para realizar una venta 
        /// </summary>
        public static TransactionResult performC14Command(Transaction_RS232 transaction,
                        String strTokenET)
        {

            {

                //---------------------------------------------------------------------
                // Core Transaction
                //---------------------------------------------------------------------

                transaction.IncluirTimeout = false;

                //-----------------------------------------------------------------------------
                // Request BIN
                //-----------------------------------------------------------------------------

                TransactionResult trxResult = null;


                transaction.SendACK = false;
                transaction.setET(strTokenET);
                transaction.verifyCheckSum = true;
                trxResult = transaction.C14_BinTables();

                return trxResult;

            }


        }

        public static TransactionResult performGugaTransaction(Transaction_RS232 transaction,
                        String strMonto,
                        String SKU,
                        String tarjeta,
                        String operador,
                        String terminalId,
                        String trxTime
                        )
        {

            {

                //---------------------------------------------------------------------
                // Core Transaction
                //---------------------------------------------------------------------

                transaction.IncluirTimeout = true;

                DateTime rigth_now = DateTime.Now;

                transaction.setTransactionDate(rigth_now.ToString("yyMMdd"));
                transaction.setTransactionTime(trxTime);
                transaction.setAmount(FormatAmount(strMonto));
                transaction.setCardNumber(tarjeta);
                transaction.setOperatorName(operador);
                transaction.setReference("");
                transaction.setIdSucursal(terminalId.Substring(0, 4));
                transaction.setIdCaja(terminalId.Substring(4));
                transaction.setCifrarPagosTarjetaCorresponsal(true);

                string serial;
                transaction.verifyCheckSum = true;

                transaction.SendACK = true;
                TransactionResult trxResult = transaction.GetModel();


                if (trxResult.ES != null && trxResult.ES.Length > 50)
                    serial = trxResult.ES.Substring(30, 20);
                else
                    serial = "                    ";

                transaction.verifyCheckSum = false;
                transaction.setPOSSerial(serial);

                transaction.SendACK = true;

                log.Info("Initiating Pinpad operation (Correspondant)");
                trxResult = transaction.Corresponsal();
                log.Info($"Pinpad operation finished with ResponseCode: {trxResult.ResponseCode} ");
                //-----------------------------------------------------------------------------
                // Request BIN
                //-----------------------------------------------------------------------------
                return trxResult;

            }


        }

        public static TransactionResult finishSaleTransaction(
                                        Transaction_RS232 transaction,
                                        TransactionResult trxResult,
                                        String responseCode,
                                        String autorizado,
                                        String issuerAuth,
                                        String E2)
        {

            TransactionResult trxResultFinish = null;
            if (null != trxResult &&
                (trxResult.Result == OperationResult.Sucess || trxResult.Result == OperationResult.Contactless || trxResult.Result == OperationResult.Use_MagCard)
                )
            {
                transaction.setResponseCode(responseCode);
                transaction.setAuthorizationCode(autorizado);
                transaction.setIssuerAuthenticationData(issuerAuth);

                DateTime rigth_now = DateTime.Now;

                transaction.setTransactionDate(rigth_now.ToString("yyMMdd"));
                transaction.setTransactionTime(rigth_now.ToString("HHmmss"));
                transaction.setE2(E2);


                trxResultFinish = transaction.FinishAuthorization();
            }


            return trxResult;
        }


        public static bool SendTableId(Transaction_RS232 transaction, String tableIdFile)
        {
            bool sent = false;

            if (null == transaction)
            {
                return false;
            }

            if (String.IsNullOrEmpty(tableIdFile))
            {
                return false;
            }

            bool fileExists = File.Exists(tableIdFile);

            if (!fileExists)
            {
                return false;
            }

            String tableId = File.ReadAllText(tableIdFile);

            transaction.StopOnACK = true;

            log.Info($"Setting BIN Table Id on PinPad: {tableId}");

            transaction.setBinTableId(tableId);

            TransactionResult transResult = transaction.Z3();

            if (transResult != null && transResult.Result == OperationResult.Sucess)
            {
                sent = true;

                File.Copy(tableIdFile, tableIdFile.Replace(".txt", ".BAK"), true);
                File.Delete(tableIdFile);
                log.Info($"BIN Table Id setting result: OK");
            }
            else
            {
                log.Info($"BIN Table Id setting result: FAILED");
            }

            return sent;

        }

        public static bool SendBinTable(Transaction_RS232 transaction, String tokenETFile)
        {
            bool sent = false;

            if (null == transaction)
            {
                return false;
            }

            if (String.IsNullOrEmpty(tokenETFile))
            {
                return false;
            }

            bool fileExist = File.Exists(tokenETFile);

            if (false == fileExist)
            {
                return false;
            }

            String tokenET = File.ReadAllText(tokenETFile);

            transaction.verifyCheckSum = true;

            transaction.setET(tokenET);

            log.Info($"Sending BIN Table to PinPad (TOKEN ET): {tokenET}");

            TransactionResult transResult = transaction.C14_BinTables();

            if (transResult != null && transResult.Result == OperationResult.Sucess)
            {
                sent = true;

                File.Copy(tokenETFile, tokenETFile.Replace(".txt", ".BAK"));
                File.Delete(tokenETFile);
                log.Info("Sending BIN Table to PinPad result: OK");
            }
            log.Info("Sending BIN Table to PinPad result: FAILED");

            return sent;
        }

        private static MessageFlow ServeMessage(MsgConfiguration msgConfig, MsgAttributes msgAttr, Dictionary<string, string> reqSrcDataFields, out CardData cardData, out CardDataOMPI cardDataOMPI, CardBrands cardBrand)
        {
            log.Info($"Entering ServeMessage");

            terminalId = reqSrcDataFields["TERMINAL_ID"];

            Exception resultEx = null;

            bool mustReverse = false;
            MessageFlow result = new MessageFlow();
            result.mfe = MessageFlowErrors.NoError;

            MessageData reqSnkData = null;
            MessageData rspSnkData = null;
            MessageData rspSrcData = null;
            cardData = null;
            cardDataOMPI = null;

            string operationCode = msgAttr.OperationCode;
            var trxStatus = true;

            // Check if there is a pending key initialization
            if (System.IO.File.Exists(keyFlagFile) && operationCode != "9999")
            {
                if (System.IO.File.ReadAllText(keyFlagFile) == "1")
                {
                    var reqSrcDataFieldsKeys = new Dictionary<string, string>();
                    reqSrcDataFieldsKeys.Add("POS_TRACE_NUMBER", new Random().Next(1, 999999).ToString());
                    reqSrcDataFieldsKeys.Add("LOCAL_TIME", reqSrcDataFields["LOCAL_TIME"]);
                    reqSrcDataFieldsKeys.Add("LOCAL_DATE", reqSrcDataFields["LOCAL_DATE"]);
                    reqSrcDataFieldsKeys.Add("TERMINAL_ID", reqSrcDataFields["TERMINAL_ID"]);
                    reqSrcDataFieldsKeys.Add("OPERATOR_ID", reqSrcDataFields["OPERATOR_ID"]);

                    MsgAttributes msgAttrI = new MsgAttributes("9999");

                    log.Info("Excuting pending key initialization");

                    var InitializationResult = MessageFlow.ProcessMessage(msgConfig, msgAttrI, reqSrcDataFieldsKeys);
                    if (InitializationResult.ResponseSink != null
                        && InitializationResult.ResponseSink.FieldValues.ContainsKey("39")
                        )
                    {
                        InitializationResult.ResponseSource.FieldValues["RESPONSE_CODE"] = InitializationResult.ResponseSink.FieldValues["39"];
                        log.Info($"Key Initialization ResponseCode: {InitializationResult.ResponseSource.FieldValues["RESPONSE_CODE"]}");
                    }

                    return InitializationResult;
                }
                else
                {
                    log.Info($"**** There is a suggested pinpad Key initialization pending... ****");
                    saveFile(keyFlagFile, "1"); //Flag to force next key loading
                }
            }

            var isKeysInitialization = operationCode == "9999";
            var isCardRequired = msgConfig.GetMessageOperation(operationCode).CardDataRequired;

            log.Info($"IsCardRequired: {isCardRequired}");

            TransactionResult trxResult = null;
            Transaction_RS232 transaction = null;
            string trxAmount = "";
            String tokenE2 = "";

            if (isCardRequired)
            {
                //-----------------------------------------------------------------------------------------
                // Configuracion de nuevo pinpad
                //-----------------------------------------------------------------------------------------
                transaction = new Transaction_RS232();
                transaction.ComPort = msgConfig.GeneralParameters.PinPadInfo.CommPort;
                transaction.Baudrate = "115200";
                transaction.DataBits = "8";
                transaction.StopBits = "1";
                transaction.Parity = "None";
                transaction.Timeout = 20000;
                transaction.IncluirTimeout = true;
                DateTime rigth_now = DateTime.Now;
                //--------------------------------------------------------------------------------
                // BinTable Checking 
                //--------------------------------------------------------------------------------

                SendTableId(transaction, binTableIdFile);


                //--------------------------------------------------------------------------------
                // BinTable Checking 
                //--------------------------------------------------------------------------------
                transaction.verifyCheckSum = false;
                transaction.StopOnACK = false;

                SendBinTable(transaction, tokenETFile);


                tokenE2 = "9F269F279F36959F109F379BA8";

                //if (isCardRequired)
                //{
                var pinpadOperationType = msgConfig.GetMessageOperation(operationCode).PinpadOperationType;

                trxAmount = isKeysInitialization ? "0" : "";
                if (reqSrcDataFields.ContainsKey("TrxAmount"))
                    trxAmount = reqSrcDataFields["TrxAmount"];
                else if (reqSrcDataFields.ContainsKey("TRX_AMOUNT"))
                    trxAmount = reqSrcDataFields["TRX_AMOUNT"];
                else if (isKeysInitialization)
                    trxAmount = "0";
                else
                    trxAmount = "0.01";


                int startTrxResult = -1;

                if (!string.IsNullOrEmpty(trxAmount))
                {

                    switch (pinpadOperationType)
                    {
                        case MsgOperation.PinPadOperationType.Venta:
                        case MsgOperation.PinPadOperationType.DevolucionNormal:
                        case MsgOperation.PinPadOperationType.CancelacionVenta:
                            switch (operationCode)
                            {
                                case "5102":
                                    trxAmount = GetGugaValues(reqSrcDataFields["XML_INFO_DATA"])["MONTO"];
                                    string trxTime = reqSrcDataFields["LOCAL_TIME"];
                                    if (!trxAmount.Contains(".") && !trxAmount.Contains(","))
                                        trxAmount += ".00";
                                    trxResult = performGugaTransaction(transaction, trxAmount, reqSrcDataFields["SKU"], reqSrcDataFields["SERVICE_REFERENCE"], reqSrcDataFields["OPERATOR_ID"], reqSrcDataFields["TERMINAL_ID"], trxTime);
                                    startTrxResult = processResponse(transaction, trxResult, msgConfig, out cardData, out cardDataOMPI);
                                    break;
                                default:
                                    trxResult = performTransaction(0x37, transaction, trxAmount, "00", "00", "00", "00", "00");
                                    startTrxResult = processResponse(transaction, trxResult, msgConfig, out cardData, out cardDataOMPI);
                                    break;
                            }
                            break;
                        /*
                    case MsgOperation.PinPadOperationType.CancelacionCredito:
                        startTrxResult = pinpad.StartTransaction("202", trxAmount, "0", 0, cardBrand == CardBrands.AmericanExpress ? 1 : 0, out cardData);
                        break;
                    case MsgOperation.PinPadOperationType.PostPropina:

                        startTrxResult = pinpad.StartTransaction("006", trxAmount, "0", 0, cardBrand == CardBrands.AmericanExpress ? 1 : 0, out cardData);
                        break;
                    case MsgOperation.PinPadOperationType.CancelacionPostpropina:
                        startTrxResult = pinpad.StartTransaction("206", trxAmount, "0", 0, cardBrand == CardBrands.AmericanExpress ? 1 : 0, out cardData);
                        break;
                        */
                        case MsgOperation.PinPadOperationType.CargaLlaves:
                            //transaction.StopOnACK = true;
                            transaction.SendACK = true;
                            transaction.verifyCheckSum = true;
                            //transaction.CancelServices();
                            //transaction.StopOnACK = false;
                            trxResult = transaction.RandomKeyRequest();
                            if (null != trxResult &&
                                (trxResult.Result == OperationResult.Sucess)
                              )
                            {
                                //transaction.Send(new byte[] { 0x06 });
                                startTrxResult = 0;

                                //---------------------------------------------------
                                // hacemos un substring (8) porque el pos nos retorn
                                // la longitud de 5 y 2 digitos del token .
                                //---------------------------------------------------
                                cardData = new CardData(
                                                        trxResult.ES.Substring(8),
                                                        trxResult.EW.Substring(8)
                                                        );

                            }

                            break;
                        default:
                            trxResult = performTransaction(0x37, transaction, trxAmount, "00", "00", "00", "00", "00");
                            startTrxResult = processResponse(transaction, trxResult, msgConfig, out cardData, out cardDataOMPI);
                            break;
                    }

                }
                else
                {
                    startTrxResult = 999;
                }

                if (startTrxResult != 00 && startTrxResult != 999)
                {
                    trxStatus = false;

                    result.errMessage = "";//pinpad.ResponseDescription;
                                           //#else
                                           //result.errMessage = pinpad.ResponseDescription;
                                           //#endif

                    result.mfe = MessageFlowErrors.PinpadError;
                }
                else
                {
                    if (startTrxResult == 999 && !isKeysInitialization)
                    {
                        trxStatus = false;
                        result.errMessage = "No se ha introducido un monto o el valor indicado no es válido";
                        result.mfe = MessageFlowErrors.PinpadError;
                    }
                }
            }
            else
            {
                cardData = null;
            }

            if (trxStatus)
            {

                try
                {
                    string errorDescription;

                    MsgDefinitionTypes defType = msgConfig.SourceMessageDefinition.MessageDefinitionType;
                    string header = msgConfig.SourceMessageDefinition.RequestHeader;
                    string mti = msgConfig.GetMessageOperation(operationCode).Request.Mti;


                    MessageData reqSrcData = new MessageData(defType, header, mti, reqSrcDataFields);

                    result.reqSrc = reqSrcData;

                    // Validate received message
                    if (reqSrcData.Validate(msgConfig.SourceMessageDefinition, msgConfig.GetMessageOperation(operationCode).Request.SrcMsgStructure, msgConfig.GeneralParameters, msgAttr, out errorDescription, cardDataOMPI) < 0)
                    {
                        result.mfe = MessageFlowErrors.RequestValidationError;
                        result.errMessage = MessageBuilder.BuildErrorMessage(operationCode, "SRC_VALIDATION", errorDescription);
                        result.mustReverse = mustReverse;
                    }
                    else
                    {
                        // Translate message from source to sink protocol

                        MessageBuilder.BuildRequestMessage(operationCode, msgConfig, msgAttr, cardData, reqSrcData, cardDataOMPI, out reqSnkData);

                        if (operationCode == "5102")
                        {
                            long.TryParse(trxAmount.Replace(",", "").Replace(".", ""), out long amt);
                            reqSnkData.FieldValues["4"] = $"{amt:000000000000}";

                            reqSnkData.FieldValues["12"] = reqSrcData.FieldValues["LOCAL_TIME"];
                        }

                        result.reqSnk = reqSnkData;
                        string branch;
                        try
                        {
                            branch = result.reqSrc.FieldValues["TERMINAL_ID"].Substring(0, 4);
                        }
                        catch
                        {
                            branch = "";  //Dummy Branch 
                        }

                        string snkMessage = reqSnkData.GetMessage(msgConfig.SinkMessageDefinition);

                        log.Info($"** Request to OMNIPAYS ({snkMessage.Length}): {snkMessage}");

                        //bool compressed = msgConfig.GetMessageOperation(operationCode).CompressedMessage;

                        //if (compressed) //compression forced
                        if (operationCode != "9010" && !string.IsNullOrEmpty(branch))
                            snkMessage = ($"[GZip]{Compressor.Compress(snkMessage)}");

                        log.Info($"Message compressed. Length: {snkMessage.Length} ");

                        bool ciphered = msgConfig.GetMessageOperation(operationCode).CipheredMessage;
                        //if (ciphered)
                        if (operationCode != "9010" && !string.IsNullOrEmpty(branch))  //Encryption forced for all messages JGR May 2021
                        {
                            string encryptFinal = "";
                            StreamReader pFile = null;
                            if (!Directory.Exists("C:\\Omnipays"))
                            {
                                string dirName = @"C:\Omnipays";
                                Directory.CreateDirectory(dirName);
                            }

                            if (!File.Exists(@"C:\Omnipays\OMPI.key"))  // try to get a RSA public key from server
                            {
                                pFile = GetRSAPublicKey(result.reqSrc.FieldValues["TERMINAL_ID"], msgConfig);
                                if (pFile == null)
                                {
                                    result.mfe = MessageFlowErrors.PublicKeyError;
                                    result.errMessage = MessageBuilder.BuildErrorMessage(operationCode, "CIPHERING", "Public Cipher Key is Missing");
                                }
                            }
                            else
                                pFile = new StreamReader(@"C:\Omnipays\OMPI.key");

                            string pKey = pFile.ReadToEnd();

                            while (snkMessage.Length > 50)
                            {
                                byte[] byteEnc = Encrypt(pKey, Encoding.UTF8.GetBytes(snkMessage.Substring(0, 50)));
                                encryptFinal += "##PART##" + BitConverter.ToString(byteEnc);
                                snkMessage = snkMessage.Substring(50);
                            }
                            if (snkMessage.Length > 0)
                            {
                                encryptFinal += "##PART##" + BitConverter.ToString(Encrypt(pKey, Encoding.UTF8.GetBytes(snkMessage)));
                            }
                            snkMessage = $"[Ciphered]{branch}{encryptFinal.Replace("-", "").Substring(8)}";
                        }

                        log.Info($"Message ciphered. Length: {snkMessage.Length}");

                        // Send translated message and get a response
                        string snkRspMessage;

                        mustReverse = sendMessage(msgConfig, snkMessage, out snkRspMessage, out resultEx);

                        log.Info($"** Response from OMNIPAYS : {snkRspMessage}");

                        if (resultEx != null)
                        {
                            result.mfe = MessageFlowErrors.CommunicationError;
                            result.errMessage = MessageBuilder.BuildErrorMessage(operationCode, "COMMUNICATION", resultEx.Message);
                            result.mustReverse = mustReverse;
                            log.Error($"{result.errMessage}");
                        }
                        else
                        {
                            mustReverse = true;
                            result.recvRsp = snkRspMessage;

                            string dummy;
                            MessageData.FromMessage(MessageDirections.Response, msgConfig.SinkMessageDefinition, snkRspMessage, out dummy, out rspSnkData);
                            result.rspSnk = rspSnkData;

                            if (rspSnkData.Validate(msgConfig.SinkMessageDefinition, msgConfig.GetMessageOperation(operationCode).Response.SnkMsgStructure, msgConfig.GeneralParameters, msgAttr, out errorDescription, cardDataOMPI) < 0)
                            {
                                result.mfe = MessageFlowErrors.ResponseValidationError;
                                result.errMessage = MessageBuilder.BuildErrorMessage(operationCode, "SNK_VALIDATION", errorDescription);
                                result.mustReverse = mustReverse;
                            }
                            else
                            {
                                MessageBuilder.BuildResponseMessage(operationCode, msgConfig, msgAttr, cardData, reqSrcData, reqSnkData, rspSnkData, cardDataOMPI, out rspSrcData);
                                result.rspSrc = rspSrcData;
                                result.mustReverse = false;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    result.mfe = MessageFlowErrors.ExceptionError;
                    result.errMessage = MessageBuilder.BuildErrorMessage(operationCode, "EXCEPTION", ex.ToString());
                    result.mustReverse = mustReverse;
                    log.Error($"{ex.StackTrace}");
                }

                if (result.mustReverse && resultEx != null && msgConfig.GetMessageOperation(operationCode).ReversalSupported)
                {

                    //var reversalMessage = buildReversalMessage(msgConfig, msgAttr, cardData, result.reqSrc, reqSnkData, rspSnkData, cardDataOMPI);
                    string responseMessage = string.Empty;
                    var rr = ReverseResponse(msgConfig, msgAttr, cardBrand, cardData, result.reqSrc, reqSnkData, rspSnkData, cardDataOMPI, out responseMessage);

                    switch (rr)
                    {
                        case ReversalResults.Ok:
                            result.mfe = MessageFlowErrors.TrxErrorAndReverseSuccessful;
                            break;
                        case ReversalResults.CommunicationError:
                            result.mfe = MessageFlowErrors.TrxErrorAndReverseCommunicationError;
                            break;
                        default:
                            result.mfe = MessageFlowErrors.TrxErrorAndReverseError;
                            break;
                    }
                }


                //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
                // Response 
                //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

                initKey = false;
                setBinTable = false;


                string ResponseCode = "";
                string authorizationNumber = "";
                string iccdata = "";
                string TokenET = "";
                string TokenER = "";
                string TokenEX = "";
                int endTrxResult = -1;
                if (result.errMessage == null)
                {
                    if (resultEx == null)
                    {

                        ResponseCode = result.ResponseSink.FieldValues["39"] ?? "";


                        if (result.ResponseSource != null)
                        {
                            //------------------------------------------------------------------------------------
                            // FIXED: F_GZIP
                            // Vamos a tratar de saber si viene una trama con compresión 
                            //------------------------------------------------------------------------------------
                            String field69 = "";

                            if (result.ResponseSource.FieldValues.ContainsKey("XML_INFO_DATA"))
                            {
                                String field69GZip = result.ResponseSource.FieldValues["XML_INFO_DATA"];
                                if (result.ResponseSource.FieldValues.ContainsKey("XML_INFO_DATA")) ;

                                int ix = field69GZip.IndexOf("[GZip]");

                                if (ix > -1)
                                {
                                    field69 = field69GZip.Remove(ix, 6);
                                    var dVal = Compressor.Decompress(field69.Substring(ix));
                                    field69 = $"{dVal.Length:00000}{dVal}";

                                    // Actualizamos el valor con el nuevo valor con la descompresi'on
                                    result.ResponseSource.FieldValues["XML_INFO_DATA"] = field69;
                                }

                            }

                            //------------------------------------------------------------------------------------
                            // END FIXED F_GZIP
                            //------------------------------------------------------------------------------------
                            try
                            {
                                ResponseCode = result.ResponseSource.FieldValues.ContainsKey("RESPONSE_CODE") ? result.ResponseSource.FieldValues["RESPONSE_CODE"] : "";
                                authorizationNumber = result.ResponseSource.FieldValues.ContainsKey("AUTHORIZATION_ID") ? result.ResponseSource.FieldValues["AUTHORIZATION_ID"] : "";
                                iccdata = result.ResponseSink.FieldValues.ContainsKey("55") ? result.ResponseSink.FieldValues["55"] ?? "" : "";
                                if (result.rspSnk.FieldValues.ContainsKey("63"))
                                {
                                    TokenET = MsgField.GetParse_Token(result.rspSnk.FieldValues["63"], "ET") ?? "";
                                    TokenER = MsgField.GetParse_Token(result.rspSnk.FieldValues["63"], "ER") ?? "";
                                    TokenEX = MsgField.GetParse_Token(result.rspSnk.FieldValues["63"], "EX") ?? "";
                                    if (TokenEX != null && TokenEX != "")
                                        TokenEX = TokenEX.Replace("! EX", "");
                                    else
                                        TokenEX = "";

                                    if (TokenER != null && TokenER != "")
                                    {
                                        TokenER = TokenER.Substring(10);
                                        initKeyValue = TokenER.Substring(0, 1);
                                        if (TokenER.Substring(0, 1) != "0")
                                        {
                                            initKey = true;
                                        }
                                        if (TokenER.Substring(1) == "1")
                                        {
                                            tokenET = TokenET;
                                            setBinTable = true;
                                            saveFile(tokenETFile, TokenET);
                                        }
                                    }
                                    else
                                        TokenER = "";

                                    if (TokenET != null && TokenET != "")
                                        TokenET = TokenET.Substring(4);
                                    else
                                        TokenET = "";

                                    if (operationCode != "9999")
                                    {
                                        // Temporal. Wincor no reconoce Contactless
                                        if (result.ResponseSource.FieldValues["POS_ENTRY_MODE"].StartsWith("07"))
                                            result.ResponseSource.FieldValues["POS_ENTRY_MODE"] = result.ResponseSource.FieldValues["POS_ENTRY_MODE"].Replace("07", "05");

                                        if (!cardData.RequiresSignature)
                                        {
                                            result.ResponseSource.FieldValues["POS_ENTRY_MODE"]
                                                = result.ResponseSource.FieldValues["POS_ENTRY_MODE"].Remove(2, 1).Insert(2, "2");
                                        }
                                        else
                                            result.ResponseSource.FieldValues["POS_ENTRY_MODE"]
                                                = result.ResponseSource.FieldValues["POS_ENTRY_MODE"].Remove(2, 1).Insert(2, "1");
                                    }
                                }
                                endTrxResult = 1;
                            }
                            catch (Exception ex)
                            {
                                log.Error($"{ex.StackTrace}");
                                authorizationNumber = "000000";
                            }
                        }

                        if (transaction != null)
                        {
                            if (!isKeysInitialization)
                            {
                                try
                                {
                                    TransactionResult endResult = finishSaleTransaction(transaction, trxResult, ResponseCode, authorizationNumber, "", tokenE2);
                                    if (null != endResult && (endResult.Result == OperationResult.Sucess || endResult.Result == OperationResult.Contactless || trxResult.Result == OperationResult.Use_MagCard))
                                    {
                                        endTrxResult = 0;
                                    }
                                }
                                catch (Exception ex)
                                {
                                    log.Error($"{ex.StackTrace}");
                                }
                                finally
                                {

                                }
                            }

                            else

                            {
                                //----------------------------------------------------------
                                // seteamos la llave inicial dukpt que viene en el tokenEX
                                //----------------------------------------------------------
                                if (string.IsNullOrEmpty(TokenEX))
                                {
                                    transaction.StopOnACK = true;
                                    transaction.SendACK = false;
                                    transaction.CancelServices();
                                }
                                else
                                {
                                    transaction.verifyCheckSum = true;
                                    transaction.Timeout = 2000;
                                    TransactionResult endResult = transaction.SetInitialKey_DUKPT($"! EX{TokenEX}");
                                    if (null != endResult && endResult.Result == OperationResult.Sucess)
                                    {
                                        endTrxResult = 0;
                                    }
                                }

                                if (System.IO.File.Exists(keyFlagFile) && operationCode == "9999")
                                {
                                    rspSnkData.FieldValues["39"] = "99";
                                    result.errMessage = MessageBuilder.BuildErrorMessage(operationCode, "Se realizó Carga de Llaves pendiente. Repita la Operación", "");
                                    System.IO.File.Delete(keyFlagFile);
                                }
                            }
                        }

                        //if (isCardRequired && transaction != null)
                        if (transaction != null)
                        {
                            transaction.StopOnACK = true;
                            transaction.SendACK = false;
                            transaction.Timeout = 2000;
                            transaction.CancelServices();
                            transaction.CloseChannel();
                        }

                        if (rspSnkData != null && rspSnkData.FieldValues.ContainsKey("39") && rspSnkData.FieldValues["39"] != "91" || rspSnkData == null)
                            if (isCardRequired && cardData.ReadMode == CardReadMode.Inserted)
                            {
                                if (endTrxResult != 0)
                                {
                                    if (endTrxResult == 54 && rspSnkData.FieldValues.ContainsKey("39") && reqSnkData.FieldValues.ContainsKey("55")) //&& pinpad.GetReverseData() != "36363636363636363636363636363636")
                                    {
                                        reqSnkData.FieldValues["55"] = ""; // pinpad.GetReverseData(); ;
                                        rspSnkData.FieldValues["39"] = "40";
                                    }
                                    else
                                        if (endTrxResult == 54 && rspSnkData.FieldValues.ContainsKey("39") && reqSnkData.FieldValues.ContainsKey("55")) //&& pinpad.GetReverseData() == "36363636363636363636363636363636")
                                    {
                                        reqSnkData.FieldValues["55"] = null;
                                        rspSnkData.FieldValues["39"] = "22";
                                    }

                                    var reversalMessage = buildReversalMessage(msgConfig, msgAttr, cardData, result.reqSrc, reqSnkData, rspSnkData, cardDataOMPI);
                                    string responseMessage = string.Empty;
                                    var rr = ReverseResponse(msgConfig, msgAttr, cardBrand, cardData, result.reqSrc, reqSnkData, rspSnkData, cardDataOMPI, out responseMessage);
                                    switch (rr)
                                    {
                                        case ReversalResults.Ok:
                                            result.mfe = MessageFlowErrors.TrxErrorAndReverseSuccessful;
                                            break;
                                        case ReversalResults.CommunicationError:
                                            result.mfe = MessageFlowErrors.TrxErrorAndReverseCommunicationError;
                                            break;
                                        default:
                                            result.mfe = MessageFlowErrors.TrxErrorAndReverseError;
                                            break;
                                    }


                                    result.errMessage = MessageBuilder.BuildErrorMessage(operationCode, "Declined by PindPad", "");

                                    //   result.errMessage = MessageBuilder.BuildErrorMessage(operationCode, "Declined by PindPad", pinpad.ResponseDescription);

                                }

                            }
                    }
                    else
                    {
                        result.errMessage = resultEx.Message;
                    }
                }
            }

            return result;
        }

        private static Dictionary<string, string> GetGugaValues(string gugaXml)
        {
            Dictionary<string, string> result = new Dictionary<string, string>();

            XmlDocument doc = new XmlDocument();

            doc.LoadXml(gugaXml);

            XmlNode current = doc.FirstChild.FirstChild;

            while (current != null)
            {
                XmlNode valueNodes = current.FirstChild;

                string name = null;
                string value = null;

                while (valueNodes != null)
                {
                    if (valueNodes.Name.Equals("sCampo"))
                        name = valueNodes.InnerText;
                    else if (valueNodes.Name.Equals("sValor"))
                        value = valueNodes.InnerText;

                    valueNodes = valueNodes.NextSibling;
                }

                if ((name != null) && (value != null))
                    result.Add(name, value);

                current = current.NextSibling;
            }

            return result;
        }

        private static void saveFile(string fileName, string data)
        {
            System.IO.File.WriteAllText(fileName, data);
        }

        private static StreamReader GetRSAPublicKey(string branch, MsgConfiguration msgConfig)
        {
            Dictionary<string, string> reqSrcDataFields = new Dictionary<string, string>();
            reqSrcDataFields.Add("TERMINAL_ID", branch);

            CardData cardData;
            CardDataOMPI cardDataOMPI;

            MessageFlow result = null;
            MsgAttributes msgAttr = new MsgAttributes("9010");

            result = ServeMessage(msgConfig, msgAttr, reqSrcDataFields, out cardData, out cardDataOMPI, CardBrands.VisaMastercard);
            if (result.ResponseSource.FieldValues.ContainsKey("ZC_XML_DATA"))
            {
                string key = result.ResponseSource.FieldValues["ZC_XML_DATA"];
                using (StreamWriter wtr = new StreamWriter(@"C:\Omnipays\OMPI.key"))
                {
                    wtr.Write(key);
                }
                return new StreamReader(@"C:\Omnipays\OMPI.key");
            }
            else
            {
                return null;
            }
        }

        private static string buildReversalMessage(MsgConfiguration msgConfig, MsgAttributes msgAttr, CardData cardData, MessageData reqSrcData, MessageData reqSnkData, MessageData rspSnkData, CardDataOMPI cardDataOMPI)
        {
            MessageData reversalData;
            MessageBuilder.BuildReversalMessage(msgAttr.OperationCode, msgConfig, msgAttr, cardData, reqSrcData, reqSnkData, rspSnkData, cardDataOMPI, out reversalData);

            string reversalMessage = reversalData.GetMessage(msgConfig.SinkMessageDefinition);

            return reversalMessage;
        }

        private static ReversalResults ReverseResponse(MsgConfiguration msgConfig, MsgAttributes msgAttr, CardBrands cardBrand, CardData cardData, MessageData reqSrcData, MessageData reqSnkData, MessageData rspSnkData, CardDataOMPI cardDataOMPI, out string responseMessage)
        {
            responseMessage = "";
            string reversalMessage = buildReversalMessage(msgConfig, msgAttr, cardData, reqSrcData, reqSnkData, rspSnkData, cardDataOMPI);

            string errorDescription;
            return MessageFlow.ReverseMessage(msgAttr.OperationCode, msgConfig, reversalMessage, out errorDescription, cardDataOMPI);


        }

        public static string PropertyList(object obj)
        {
            var props = obj.GetType().GetProperties();
            var sb = new StringBuilder();
            foreach (var p in props)
            {
                sb.AppendLine(p.Name + ": " + p.GetValue(obj, null));
            }
            return sb.ToString();
        }
        public static MessageFlow ProcessMessage(MsgConfiguration msgConfig, MsgAttributes msgAttr, Dictionary<string, string> reqSrcDataFields)
        {
            CardData cardData;
            CardDataOMPI cardDataOMPI;

            MessageFlow result = null;
            try
            {

                log.Info($"=========== New Incoming Operation {msgAttr.OperationCode}-{msgConfig.GetMessageOperation(msgAttr.OperationCode).Description} ==========");
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("** Request fields from POS **");
                foreach (KeyValuePair<string, string> i in reqSrcDataFields)
                {
                    sb.AppendLine($"{i.Key} = {i.Value}");
                }
                log.Info(sb.ToString());

                result = ServeMessage(msgConfig, msgAttr, reqSrcDataFields, out cardData, out cardDataOMPI, CardBrands.VisaMastercard);

                bool isAcquiringOperation = msgAttr.OperationCode.StartsWith("0");
                bool isResponse71 = (result.ResponseSink != null
                       && result.ResponseSink.FieldValues.ContainsKey("39")
                       && (result.ResponseSink.FieldValues["39"]) == "71");

                bool isTokenER2 = (result.ResponseSink != null
                        && result.ResponseSink.FieldValues.ContainsKey("63")
                        && MsgField.GetParse_Token(result.rspSnk.FieldValues["63"], "ER") != null
                        && MsgField.GetParse_Token(result.rspSnk.FieldValues["63"], "ER")[10] == '2');
                bool isTokenER1 = (result.ResponseSink != null
                        && result.ResponseSink.FieldValues.ContainsKey("63")
                        && MsgField.GetParse_Token(result.rspSnk.FieldValues["63"], "ER") != null
                        && MsgField.GetParse_Token(result.rspSnk.FieldValues["63"], "ER")[10] == '1');


                bool isDataLogicOperation = msgAttr.OperationCode.StartsWith("50");

                List<string> queryOperations = new List<string> { "1006", "1007", "1008", "1009" };

                bool isQueryOperation = queryOperations.Contains(msgAttr.OperationCode);

                if (isAcquiringOperation
                    && (isResponse71
                       ||
                       isTokenER2))
                {
                    var reqSrcDataFieldsKeys = new Dictionary<string, string>();
                    reqSrcDataFieldsKeys.Add("POS_TRACE_NUMBER", new Random().Next(1, 999999).ToString());
                    reqSrcDataFieldsKeys.Add("LOCAL_TIME", reqSrcDataFields["LOCAL_TIME"]);
                    reqSrcDataFieldsKeys.Add("LOCAL_DATE", reqSrcDataFields["LOCAL_DATE"]);
                    reqSrcDataFieldsKeys.Add("TERMINAL_ID", reqSrcDataFields["TERMINAL_ID"]);
                    reqSrcDataFieldsKeys.Add("OPERATOR_ID", reqSrcDataFields["OPERATOR_ID"]);

                    MsgAttributes msgAttrI = new MsgAttributes("9999");

                    var InitializationResult = MessageFlow.ProcessMessage(msgConfig, msgAttrI, reqSrcDataFieldsKeys);
                    if (InitializationResult.ResponseSink != null
                        && InitializationResult.ResponseSink.FieldValues.ContainsKey("39")
                        && InitializationResult.ResponseSink.FieldValues["39"] == "00"
                        )
                    {
                        if (result.ResponseSink != null && result.ResponseSource.FieldValues.ContainsKey("POS_TEXT"))
                        {
                            result.ResponseSource.FieldValues["POS_TEXT"] = "Aprobada y se inicializaron llaves automáticamente.";
                        }
                    }
                }
                else if (isAcquiringOperation
                   && (isResponse71
                      ||
                      isTokenER1))
                {
                    result.ResponseSource.FieldValues["POS_TEXT"] = "Aprobada y se requiere inicializar llaves cuando sea posible.";
                    saveFile(keyFlagFile, "2");
                }

                if (isDataLogicOperation)
                {
                    if (result.ResponseSink != null
                        && result.ResponseSink.FieldValues != null
                        && result.ResponseSink.FieldValues.ContainsKey("39")
                        && result.ResponseSink.FieldValues["39"] != "00")
                        if (result.ResponseSink != null
                            && result.ResponseSink.FieldValues != null
                            && result.ResponseSink.FieldValues.ContainsKey("69"))
                        {
                            var xmlInfo = result.ResponseSink.FieldValues["69"];
                            XmlDocument xdoc = new XmlDocument();
                            xdoc.LoadXml(xmlInfo);
                            if (xdoc.GetElementsByTagName("SERVICE_POS_TXT").Count > 0)
                            {
                                var pos_text = xdoc.GetElementsByTagName("SERVICE_POS_TXT").Item(0).InnerText;
                                result.ResponseSource.FieldValues["POS_TEXT"] = pos_text;
                            }
                        }
                }

                if (isQueryOperation)
                {
                    if (result.ResponseSink != null
                        && result.ResponseSink.FieldValues != null
                        )
                        if (result.ResponseSink != null
                            && result.ResponseSink.FieldValues != null
                            && result.ResponseSink.FieldValues.ContainsKey("69"))
                        {
                            var xmlInfo = result.ResponseSink.FieldValues["69"];
                            XmlDocument xdoc = new XmlDocument();
                            xdoc.LoadXml(xmlInfo);
                            if (xdoc.GetElementsByTagName("POS_TEXT").Count > 0)
                            {
                                var pos_text = xdoc.GetElementsByTagName("POS_TEXT").Item(0).InnerText;

                                result.ResponseSource.FieldValues["POS_TEXT"] = pos_text;
                            }
                        }
                }
            }
            catch (Exception ex)
            {
                log.Error($"{ex.StackTrace}");
            }

            try
            {
                if (result.ResponseSource != null)
                {
                    StringBuilder sb = new StringBuilder();
                    sb.AppendLine("** Response fields to POS **");
                    foreach (KeyValuePair<string, string> i in result.ResponseSource.FieldValues)
                    {
                        sb.AppendLine($"{i.Key} = {i.Value}");
                    }
                    log.Info(sb.ToString());
                }
                else
                    log.Error("*** NULL RESPONSE FROM OmniPays ****");
            }
            catch (Exception ex)
            {
                log.Error($"*** ERROR PARSING RESPONSE FROM OmniPays ***\n{ex.StackTrace}");

            }
            return result;

        }

        private static byte[] Encrypt(string publicKey, byte[] plain)
        {
            byte[] encrypted = new byte[50];
            RSACryptoServiceProvider rsa2 = KeyNegotiation.ImportKey(publicKey, null, false);
            rsa2.PersistKeyInCsp = false;
            encrypted = rsa2.Encrypt(plain, true);
            return encrypted;
        }

        public static int processResponse(Transaction_RS232 transaction, TransactionResult trxResult, MsgConfiguration msgConfig, out CardData cardData, out CardDataOMPI cardDataOMPI)
        {
            log.Info("Processing Pinpad Response");
            int startTrxResult = -1;

            cardData = null;
            cardDataOMPI = null;

            if (null != trxResult &&
                                (
                                    trxResult.Result == OperationResult.Sucess ||
                                    trxResult.Result == OperationResult.Contactless ||
                                    trxResult.Result == OperationResult.Use_MagCard
                                )
               )
            {

                startTrxResult = 0;

                CardEntryMode entryMode = trxResult.EntryMode;
                String cardNumber = "";
                String track1 = "";
                String track2 = "";
                String cardholderName = trxResult.CardHolderName;
                String aid = "";
                String arqc = "";
                String product = "";
                String tokenEZ = trxResult.EZ;
                String tokenEY = trxResult.EY;
                String tokenES = trxResult.ES;
                String cardSequenceNumber = "";
                String signatureFlag = "";


                if (!string.IsNullOrEmpty(trxResult.CardNumber))
                {
                    if (!trxResult.CardNumber.StartsWith("9999")) // NOT WaldosPass
                        cardNumber = trxResult.CardNumber.Length < 16 ? trxResult.CardNumber.Replace("***", "******") : trxResult.CardNumber;
                    else
                    {
                        cardNumber = trxResult.Track2.Substring(0, 16);
                    }
                }
                string datosEMV = "";

                String cardEntryMode = "";

                List<TLVTag> lstTAGs = null;

                if (null != trxResult.E1)
                {
                    lstTAGs = TLVTag.ParseTags(trxResult.E1);
                }

                String AppLabel = "";

                if (null != lstTAGs && lstTAGs.Count > 0)
                {
                    foreach (TLVTag tag in lstTAGs)
                    {
                        if (tag.TagName.ToUpper() == "9F26")
                        {
                            arqc = Utilidad.Bcd2Str(tag.Value);
                            continue;
                        }

                        if (tag.TagName.ToUpper() == "50")
                        {
                            AppLabel = Encoding.GetEncoding("ISO-8859-1").GetString(tag.Value);
                            continue;
                        }

                        //if (tag.TagName.ToUpper() == "84")
                        if (tag.TagName.ToUpper() == "4F")
                        {
                            aid = Utilidad.Bcd2Str(tag.Value);
                            continue;
                        }

                        if (tag.TagName.ToUpper() == "9F12")
                        {
                            product = Encoding.GetEncoding("ISO-8859-1").GetString(tag.Value);
                            continue;
                        }

                        if (tag.TagName.ToUpper() == "5F34")
                        {
                            cardSequenceNumber = Utilidad.Bcd2Str(tag.Value);
                            continue;
                        }
                        if (tag.TagName.ToUpper() == "C2")
                        {
                            signatureFlag = Utilidad.Bcd2Str(tag.Value).Substring(1);
                            continue;
                        }
                    }
                }

                cardEntryMode = string.Format("{0:00}", (int)entryMode);

                if (cardEntryMode == "00")  // cifrado Corresponsal 
                {
                    datosEMV = "";
                    cardNumber = "0000000000000000";
                    cardEntryMode = "010";
                }

                else if (cardEntryMode.StartsWith("05"))
                {
                    byte[] arrByte = new byte[trxResult.E2.Length - 3];
                    System.Array.Copy(trxResult.E2, 0, arrByte, 0, arrByte.Length);
                    datosEMV = Encoding.GetEncoding("iso-8859-1").GetString(arrByte);
                }
                else if (cardEntryMode.StartsWith("07"))
                {
                    datosEMV = Encoding.GetEncoding("iso-8859-1").GetString(trxResult.E2);
                }
                if (trxResult.EZ != null && trxResult.EZ.Length > 8)
                    tokenEZ = trxResult.EZ.Substring(8);
                else
                    tokenEZ = "";

                if (trxResult.EY != null && trxResult.EY.Length > 8)
                    tokenEY = trxResult.EY.Substring(8);
                else
                    tokenEY = "";

                if (trxResult.ES != null && trxResult.ES.Length > 8)
                    tokenES = trxResult.ES.Substring(8);
                else
                    tokenES = "";

                log.Info($"{datosEMV}");

                cardData = new CardData(
                                            cardEntryMode,
                                            cardNumber.Replace("*", "0"),
                                            track1,
                                            track2,
                                            cardholderName,
                                            aid,
                                            arqc,
                                            product,
                                            tokenEZ,
                                            tokenEY,
                                            tokenES,
                                            cardSequenceNumber,
                                            datosEMV
                                        );

                cardData.RequiresSignature = signatureFlag == "1";

                cardDataOMPI = new CardDataOMPI();
                if (trxResult.CZ != null && trxResult.CZ.Length > 8)
                    cardDataOMPI.CZ = trxResult.CZ.Substring(8);
                if (trxResult.ES != null && trxResult.ES.Length > 8)
                    cardDataOMPI.ES = trxResult.ES.Substring(8);
                if (trxResult.R1 != null && trxResult.R1.Length > 8)
                    cardDataOMPI.R1 = trxResult.R1.Substring(8);
                cardDataOMPI.EntryMode = cardEntryMode;
                cardDataOMPI.EntryCapability = (int)msgConfig.GeneralParameters.PinPadInfo.EntryCapability;
                //cardData.Field55 = datosEMV;

            }
            else
            {
                transaction.Send(new byte[] { 0x06 }); //SEND NACK
                transaction.CloseChannel();
            }

            log.Info($"Pinpad startTrxResult: {startTrxResult}");
            return startTrxResult;
        }
    }
}
