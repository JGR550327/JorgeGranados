﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMPI
{
    public class MsgAttributes
    {
        private DateTime localDateTime;
        private DateTime utcDateTime;
        //private string originalMti;
        private string operationCode;
        private bool cipheredMessage;
        private bool compressedMessage;

        //public MsgAttributes(DateTime localDateTime, DateTime utcDateTime, string originalMti)
        //{
        //    this.localDateTime = localDateTime;
        //    this.utcDateTime = utcDateTime;
        //    //this.originalMti = originalMti;
        //}

        public MsgAttributes(string operationCode)
        {
            DateTime current = DateTime.Now;

            this.localDateTime = current;
            this.utcDateTime = current.ToUniversalTime();

            //this.originalMti = originalMti;
            this.operationCode = operationCode;
        }
        public MsgAttributes(string operationCode, bool ciphered = false, bool compressed = false)
        {
            DateTime current = DateTime.Now;

            this.localDateTime = current;
            this.utcDateTime = current.ToUniversalTime();

            //this.originalMti = originalMti;
            this.operationCode = operationCode;
            this.cipheredMessage = ciphered;
            this.compressedMessage = compressed;
        }

        public DateTime LocalDateTime { get { return localDateTime; } }
        public DateTime UtcDateTime { get { return utcDateTime; } }
        //public string OriginalMti { get { return originalMti; } }
        public string OperationCode { get { return operationCode; } }
        public bool CipheredMessage { get { return cipheredMessage; } }
        public bool CompressedMessage { get { return compressedMessage; } }
    }
}
