﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace OMPI
{
    public class MsgCondition
    {
        private string key;
        private string function;

        public MsgCondition(string key, string function)
        {
            this.key = key;
            this.function = function;
        }

        public string Key { get { return key; } }
        public string Function { get { return function; } }


        public static MsgCondition LoadFromXml(XmlNode baseNode)
        {
            if (!baseNode.Name.Equals("Condition", StringComparison.InvariantCultureIgnoreCase))
                throw new Exception("Invalid XML structure");

            string key = baseNode.Attributes["key"].Value;
            string function = baseNode.Attributes["function"].Value;

            return new MsgCondition(key, function);

        }


    }
}
