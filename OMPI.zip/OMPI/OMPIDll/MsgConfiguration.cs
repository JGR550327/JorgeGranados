﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Security.Cryptography;
using System.Security.Cryptography.Xml;
using System.Linq;

namespace OMPI
{
    public class MsgConfiguration
    {
        private MsgGeneralParameters generalParameters;
        private MsgDefinition sourceMessageDefinition;
        private MsgDefinition sinkMessageDefinition;
        private Dictionary<string, MsgOperation> messageOperations;
        private DataLogicSKUDictionary datalogicServices = new DataLogicSKUDictionary();

        public enum RemittanceCompany
        {
            Unknown = 0,
            MoneyGram = 1,
            WesternUnion = 2,
            BTS = 3,
            Appriza = 4,
            Sigue = 5
        }

        public static RemittanceCompany GetRemittanceCompanyFromMTCN(string MTCN)
        {
            RemittanceCompany result;

            if (MTCN.StartsWith("SG") || MTCN.StartsWith("REY"))
            {
                result = RemittanceCompany.Sigue;
                return result;
            }

            long val;

            if (long.TryParse(MTCN, out val))
            {
                switch (MTCN.Length)
                {
                    case 10:
                        result = RemittanceCompany.WesternUnion;
                        break;
                    case 8:
                        result = RemittanceCompany.MoneyGram;
                        break;
                    case 11:
                        result = RemittanceCompany.BTS;
                        break;
                    case 12:
                        result = RemittanceCompany.Appriza;
                        break;
                    default:
                        result = RemittanceCompany.Unknown;
                        break;
                }
            }
            else
            {
                result = RemittanceCompany.Unknown;
            }

            return result;
        }

        //public static string GetInformationFromPostalCode(MsgConfiguration msgConfig, string postalCode)
        //{
        //    var result = "";
        //    MsgAttributes msgAttr = new MsgAttributes("9998");
        //    Dictionary<string, string> reqSrcDataFields = new Dictionary<string, string>();



        //    reqSrcDataFields.Add("POS_TRACE_NUMBER", TraceNumber.GetPosNumber());
        //    reqSrcDataFields.Add("LOCAL_TIME", DateTime.Now.ToString("HHmmss"));
        //    reqSrcDataFields.Add("LOCAL_DATE", DateTime.Now.ToString("MMdd"));
        //    reqSrcDataFields.Add("TERMINAL_ID", "40020001");
        //    reqSrcDataFields.Add("OPERATOR_ID", "VCR123");
        //    //Se envía la información a la OMPI y esta se 

        //    MessageFlow.ProcessMessage(msgConfig, msgAttr, reqSrcDataFields);

        //    return result;
        //}


        public MsgConfiguration()
        {
            messageOperations = new Dictionary<string, MsgOperation>();
        }

        public MsgGeneralParameters GeneralParameters { get { return generalParameters; } }
        public MsgDefinition SourceMessageDefinition { get { return sourceMessageDefinition; } }
        public MsgDefinition SinkMessageDefinition { get { return sinkMessageDefinition; } }
        //public DataLogicSKUDictionary DatalogicServices { get { return datalogicServices; } }
 
        private static void loadMessageDefinitions(MsgConfiguration msg, XmlNode baseNode)
        {
            XmlNode current = baseNode.FirstChild;

            while (current != null)
            {
                string name = current.Name;

                if (current.Name.Equals("SourceMessageDefinition"))
                    msg.sourceMessageDefinition = MsgDefinition.LoadFromXml(current);
                else if (current.Name.Equals("SinkMessageDefinition"))
                    msg.sinkMessageDefinition = MsgDefinition.LoadFromXml(current);
                else
                    throw new Exception(string.Format("Unexpected node '{0}'", current.Name));

                current = current.NextSibling;
            }


        }


        public List<DataLogicService> GetDataLogicAvailableServices()
        {

            return datalogicServices.DataLogicServices;
        }

        public List<ServiceItem> GetAvalaibleServices()
        {

            return (from operation in messageOperations
                    select new ServiceItem(operation.Value.Key
                        , operation.Value.Code
                        , operation.Value.Description
                          )).ToList();
        }


        public Dictionary<string, KeyValuePair<string, List<string>>> GetOperationsFieldsData()
        {
            Dictionary<string, KeyValuePair<string, List<string>>> operationsData = new Dictionary<string, KeyValuePair<string, List<string>>>();

            foreach (var operation in messageOperations)
            {
                string title = operation.Value.Code; //string.Format("{0} - {1}", operation.Value.Code.Trim(), operation.Value.Description.Trim()) ;
                List<string> fields = (from field in operation.Value.Request.SrcMsgStructure.Fields
                                       select field.Key).ToList();
                operationsData.Add(title, new KeyValuePair<string, List<string>>(operation.Value.Description, fields));
            }

            return operationsData;
        }


        public static MsgConfiguration LoadFromXml(XmlNode baseNode, RSACryptoServiceProvider rsaKey)
        {
            if (!baseNode.Name.Equals("MessageFactory"))
                throw new Exception(string.Format("Unexpected node name '{0}'", baseNode.Name));

            XmlNode current = baseNode;

            MsgConfiguration result = new MsgConfiguration();

            current = current.FirstChild;
            while (current != null)
            {
                if (current.Name.Equals("GeneralParams", StringComparison.InvariantCultureIgnoreCase))
                    result.generalParameters = MsgGeneralParameters.LoadFromXml(current, rsaKey);
                else if (current.Name.Equals("MessageDefinitions", StringComparison.InvariantCultureIgnoreCase))
                    loadMessageDefinitions(result, current);
                else if (current.Name.Equals("Operation", StringComparison.InvariantCultureIgnoreCase))
                {
                    MsgOperation msgOperation = MsgOperation.LoadFromXml(current);

                    result.messageOperations.Add(msgOperation.Code, msgOperation);
                }
                else if (current.Name.Equals("DataLogicSKUDictionary", StringComparison.InvariantCultureIgnoreCase))
                {
                    DataLogicSKUDictionary dict = DataLogicSKUDictionary.LoadFromXml(current);
                    result.datalogicServices = dict;
                }
                else
                    throw new Exception(string.Format("Unexpected node '{0}'", current.Name));

                current = current.NextSibling;
            }

            return result;
        }


        public MsgOperation GetMessageOperation(string code)
        {
            MsgOperation result = null;

            if (!messageOperations.TryGetValue(code, out result))
                throw new Exception(string.Format("Undefined operation '{0}'", code));

            return result;
        }



    }
}
