﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace OMPI
{
    public class MsgConnectionInfo
    {
        private string host;
        private int port;
        private bool useSsl;
        private string sslCertificateName;
        private int sendTimeout;
        private int recvTimeout;

        private MsgConnectionInfo(string host, int port, bool useSsl, string sslCertificateName, int sendTimeout, int recvTimeout)
        {
            this.host = host;
            this.port = port;
            this.useSsl = useSsl;
            this.sslCertificateName = sslCertificateName;
            this.sendTimeout = sendTimeout;
            this.recvTimeout = recvTimeout;
        }

        public string Host { get { return host; } }
        public int Port { get { return port; } }
        public bool UseSsl { get { return useSsl; } }
        public string SslCertificateName { get { return sslCertificateName; } }
        public int SendTimeout { get { return sendTimeout; } }
        public int RecvTimeout { get { return recvTimeout; } }


        public static MsgConnectionInfo LoadFromXml(XmlNode baseNode)
        {
            XmlNode current = baseNode;
            string host = null;
            bool useSsl = true;
            string sslCertificateName = null;
            int port = 0;
            int sendTimeout = 5000;
            int recvTimeout = 5000;

            XmlAttribute attr;

            if ((attr = current.Attributes["host"]) != null)
                host = attr.Value;

            if ((attr = current.Attributes["port"]) != null)
                port = Int32.Parse(attr.Value);

            if ((attr = current.Attributes["useSsl"]) != null)
                useSsl = bool.Parse(attr.Value);

            if (useSsl)
            {
                if ((attr = current.Attributes["sslCertificateName"]) == null)
                    throw new Exception("SslCertificateName is required");
    
                sslCertificateName = attr.Value;
            }

            if ((attr = current.Attributes["sendTimeout"]) != null)
                sendTimeout = Int32.Parse(attr.Value);

            if ((attr = current.Attributes["recvTimeout"]) != null)
                recvTimeout = Int32.Parse(attr.Value);
            
            return new MsgConnectionInfo(host, port, useSsl, sslCertificateName, sendTimeout, recvTimeout);
        }

    }
}
