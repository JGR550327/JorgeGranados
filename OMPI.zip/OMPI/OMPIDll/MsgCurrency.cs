﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace OMPI
{
    public class MsgCurrency
    {
        private string code;
        private string key;
        private string name;
        private string symbol;
        private string membershipNumber;
        private string terminalId;

        public string Code { get { return code; } }
        public string Key { get { return key; } }
        public string Name { get { return name; } }
        public string Symbol { get { return symbol; } }
        public string MembershipNumber { get { return membershipNumber; } }
        public string TerminalId { get { return terminalId; } }

        public MsgCurrency(string key, string code, string name, string symbol, string membershipNumber, string terminalId)
        {
            this.key = key;
            this.code = code;
            this.name = name;
            this.symbol = symbol;
            this.membershipNumber = membershipNumber;
            this.terminalId = terminalId;
        }

        public static MsgCurrency LoadFromXml(XmlNode baseNode)
        {
            if (!baseNode.Name.Equals("Currency", StringComparison.InvariantCultureIgnoreCase))
                throw new Exception("Invalid XML structure");

            string key = baseNode.Attributes["key"].Value;
            string code = baseNode.Attributes["code"].Value;
            string name = baseNode.Attributes["name"].Value;
            string symbol = baseNode.Attributes["symbol"].Value;
            string membershipNumber = baseNode.Attributes["membershipNumber"].Value;
            string terminalId = baseNode.Attributes["terminalId"].Value;

            return new MsgCurrency(key, code, name, symbol, membershipNumber, terminalId);
        }
    }
}
