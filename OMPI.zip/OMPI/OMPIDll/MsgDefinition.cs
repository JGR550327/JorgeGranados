﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace OMPI
{
    public enum MsgDefinitionTypes
    {
        Xml = 0,
        ISO8583 = 1,
        ISO8583_Transakcio = 2
    }

    public enum BitmapTypes
    {
        None = 0,
        ASCII = 1,
        HEX = 2
    }

    public class MsgDefinition
    {
        private MsgDefinitionTypes messageDefinitionType;
        private string requestHeader;
        private string responseHeader;
        private bool requestUseLength;
        private bool responseUseLength;
        private BitmapTypes bitmapType;
        private bool errorWhenUnexpectedField;
        private Dictionary<string, MsgFieldDefinition> fields;

        public MsgDefinition(MsgDefinitionTypes messageDefinitionType, string requestHeader, string responseHeader, bool requestUseLength, bool responseUseLength, BitmapTypes bitmapType, bool errorWhenUnexpectedField)
        {
            this.messageDefinitionType = messageDefinitionType;
            this.requestHeader = requestHeader;
            this.responseHeader = responseHeader;
            this.requestUseLength = requestUseLength;
            this.responseUseLength = responseUseLength;
            this.bitmapType = bitmapType;
            this.errorWhenUnexpectedField = errorWhenUnexpectedField;

            fields = new Dictionary<string, MsgFieldDefinition>();
        }

        public MsgDefinitionTypes MessageDefinitionType
        {
            get { return messageDefinitionType; }
        }

        public string RequestHeader
        {
            get { return requestHeader; }
        }

        public string ResponseHeader
        {
            get { return responseHeader; }
        }

        public bool RequestUseLength
        {
            get { return requestUseLength; }
        }

        public bool ResponseUseLength
        {
            get { return responseUseLength; }
        }

        public BitmapTypes BitmapType
        {
            get { return bitmapType; }
        }

        public bool ErrorWhenUnexpectedField
        {
            get { return errorWhenUnexpectedField; }
        }

        public Dictionary<string, MsgFieldDefinition> Fields
        {
            get { return fields; }
        }


        public static MsgDefinition LoadFromXml(XmlNode baseNode)
        {
            MsgDefinitionTypes definitionType = (MsgDefinitionTypes)Enum.Parse(typeof(MsgDefinitionTypes), baseNode.Attributes["type"].Value, true);

            bool errorWhenUnexpectedField;
            string requestHeader;
            string responseHeader;
            bool requestUseLength;
            bool responseUseLength;
            BitmapTypes bitmapType;

            XmlAttribute attr;

            if ((attr = baseNode.Attributes["errorWhenUnexpectedField"]) != null)
                errorWhenUnexpectedField = bool.Parse(attr.Value);
            else
                errorWhenUnexpectedField = true;

            if ((attr = baseNode.Attributes["requestHeader"]) != null)
                requestHeader = attr.Value;
            else
                requestHeader = null;

            if ((attr = baseNode.Attributes["responseHeader"]) != null)
                responseHeader = attr.Value;
            else
                responseHeader = null;

            if ((attr = baseNode.Attributes["requestUseLength"]) != null)
                requestUseLength = bool.Parse(attr.Value);
            else
                requestUseLength = true;

            if ((attr = baseNode.Attributes["responseUseLength"]) != null)
                responseUseLength = bool.Parse(attr.Value);
            else
                responseUseLength = true;

            if ((attr = baseNode.Attributes["bitmapType"]) != null)
                bitmapType = (BitmapTypes)Enum.Parse(typeof(BitmapTypes), attr.Value, true);
            else
                bitmapType = BitmapTypes.None;

            if ((definitionType != MsgDefinitionTypes.Xml) && (requestHeader == null))
                throw new Exception(string.Format("Attribute 'requestHeader' is required for definition type '{0}', even if it is empty", definitionType));

            if ((definitionType != MsgDefinitionTypes.Xml) && (responseHeader == null))
                throw new Exception(string.Format("Attribute 'responseHeader' is required for definition type '{0}', even if it is empty", definitionType));

            if ((definitionType == MsgDefinitionTypes.ISO8583) && (bitmapType == BitmapTypes.None))
                    throw new Exception(string.Format("Attribute 'bitmapType' is required for definition type '{0}'", definitionType));

            MsgDefinition result = new MsgDefinition(definitionType, requestHeader, responseHeader, requestUseLength, responseUseLength, bitmapType, errorWhenUnexpectedField);

            XmlNode current = baseNode.FirstChild;

            if (!current.Name.Equals("Fields", StringComparison.InvariantCultureIgnoreCase))
                throw new Exception("Invalid XML structure");

            current = current.FirstChild;

            while (current != null)
            {
                MsgFieldDefinition mfd = MsgFieldDefinition.LoadFromXml(current);

                result.fields.Add(mfd.Key, mfd);

                current = current.NextSibling;
            }

            return result;
        
        }
    }
}
