﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Globalization;
using FieldDataClassLib;
using PinPadCommunication;

namespace OMPI
{
    public enum DataSources
    {
        None = 0,
        Fixed = 1,
        Echo = 2,
        CopyReqSrc = 3,
        CopyReqSnk = 4,
        CopyRspSnk = 5,
        UTCDateTime = 6,
        LocalDateTime = 7,
        Function = 8,
        Conditional = 9,
        Tokens = 10,
        CardData = 11,
        Composite = 12,
        Constructed = 13,
        Fields = 14,
        User = 15,
        XmlData = 16,
        OperationCode = 17,
        CardDataOMPI = 18
    }

    public enum MandatoryTypes
    {
        False = 0,
        True = 1,
        Conditional = 2
    }

    public class MsgField
    {
        private string key;
        private MandatoryTypes mandatory;
        private string mandatoryCondition;
        private DataSources dataSource;
        private string dataSourceInfo;
        private string format;
        private bool ignoreWhitespace;
        private List<MsgFieldValueCondition> valueConditions;
        private Dictionary<string, MsgTokens> tokens;
        private Dictionary<string, MsgField> childFields;

        public MsgField(string key, MandatoryTypes mandatory, string mandatoryCondition, DataSources dataSource, string dataSourceInfo, string format, bool ignoreWhitespace)
        {
            this.key = key;
            this.mandatory = mandatory;
            this.mandatoryCondition = mandatoryCondition;
            this.dataSource = dataSource;
            this.dataSourceInfo = dataSourceInfo;
            this.format = format;
            this.ignoreWhitespace = ignoreWhitespace;

        }

        public string Key { get { return key; } }
        public MandatoryTypes Mandatory { get { return mandatory; } }
        public string MandatoryCondition { get { return mandatoryCondition; } }
        public DataSources DataSource { get { return dataSource; } }
        public string DataSourceInfo { get { return dataSourceInfo; } }
        public string Format { get { return format; } }
        public bool IgnoreWhitespace { get { return ignoreWhitespace; } }

        public static MsgField LoadFromXml(XmlNode baseNode, Dictionary<string, MsgCondition> conditions)
        {
            if (!baseNode.Name.Equals("Field", StringComparison.InvariantCultureIgnoreCase))
                throw new Exception("Invalid XML structure");

            string key = baseNode.Attributes["key"].Value;

            XmlAttribute attr = baseNode.Attributes["mandatory"];

            MandatoryTypes mandatory = MandatoryTypes.True;
            if (attr != null)
                mandatory = (MandatoryTypes)Enum.Parse(typeof(MandatoryTypes), attr.Value, true);

            XmlAttribute aux;
            string mandatoryCondition;
            string format;
            bool ignoreWhitespace;
            DataSources dataSource;

            if ((aux = baseNode.Attributes["mandatoryCondition"]) != null)
            {
                MsgCondition msgCondition;
                if (!conditions.TryGetValue(aux.Value, out msgCondition))
                    throw new Exception(string.Format("Undefined condition '{0}'", aux.Value));

                mandatoryCondition = msgCondition.Function;
            }
            else
                mandatoryCondition = null;

            if ((aux = baseNode.Attributes["format"]) != null)
                format = aux.Value;
            else
                format = null;

            if ((aux = baseNode.Attributes["ignoreWhitespace"]) != null)
                ignoreWhitespace = bool.Parse(aux.Value);
            else
                ignoreWhitespace = false;

            if ((aux = baseNode.Attributes["dataSource"]) != null)
                dataSource = (DataSources)Enum.Parse(typeof(DataSources), aux.Value, true);
            else
                dataSource = DataSources.None;

            string dataSourceInfo = null;
            if (dataSource != DataSources.Conditional)
                dataSourceInfo = baseNode.InnerXml;


            MsgField result = new MsgField(key, mandatory, mandatoryCondition, dataSource, dataSourceInfo, format, ignoreWhitespace);
            XmlNode current;

            switch (dataSource)
            {
                case DataSources.Conditional:
                    result.valueConditions = new List<MsgFieldValueCondition>();

                    current = baseNode.FirstChild;

                    while (current != null)
                    {
                        MsgFieldValueCondition mfvc = MsgFieldValueCondition.LoadFromXml(current, conditions);

                        result.valueConditions.Add(mfvc);

                        current = current.NextSibling;
                    }

                    break;
                case DataSources.Tokens:
                    result.tokens = new Dictionary<string, MsgTokens>();

                    current = baseNode.FirstChild;

                    while (current != null)
                    {
                        MsgTokens mt = MsgTokens.LoadFromXml(current, conditions);

                        result.tokens.Add(mt.Key, mt);

                        current = current.NextSibling;
                    }

                    break;
                case DataSources.Composite:
                case DataSources.Constructed:
                case DataSources.Fields:
                case DataSources.XmlData:
                    result.childFields = new Dictionary<string, MsgField>();

                    current = baseNode.FirstChild;

                    while (current != null)
                    {
                        MsgField mf = MsgField.LoadFromXml(current, conditions);

                        result.childFields.Add(mf.key, mf);

                        current = current.NextSibling;
                    }

                    break;

            }

            return result;
        }


        public static string GetDateTime(DataSources dataSource, MsgAttributes msgAttr, string format)
        {
            DateTime dt;

            if (format == null)
                throw new Exception("Format cannot be null for datetime data sources");
            if (dataSource == DataSources.LocalDateTime)
                dt = msgAttr.LocalDateTime;
            else
                dt = msgAttr.UtcDateTime;

            string result = format;

            string strYear = string.Format("{0:0000}", dt.Year);

            if (result.IndexOf('C') > -1)
                result = result.Replace("CC", strYear.Substring(0, 2));
            if (result.IndexOf('Y') > -1)
                result = result.Replace("YY", strYear.Substring(2, 2));
            if (result.IndexOf('M') > -1)
                result = result.Replace("MM", string.Format("{0:00}", dt.Month));
            if (result.IndexOf('D') > -1)
                result = result.Replace("DD", string.Format("{0:00}", dt.Day));
            if (result.IndexOf('h') > -1)
                result = result.Replace("hh", string.Format("{0:00}", dt.Hour));
            if (result.IndexOf('m') > -1)
                result = result.Replace("mm", string.Format("{0:00}", dt.Minute));
            if (result.IndexOf('s') > -1)
                result = result.Replace("ss", string.Format("{0:00}", dt.Second));

            return result;
        }

        public static string GetOperationCode(MsgAttributes msgAttr)
        {
            return msgAttr.OperationCode;
        }

        public static string GetTrue()
        {
            return "true";
        }

        public static string GetStarts_With(string value1, string value2)
        {
            if (value1.StartsWith(value2, StringComparison.InvariantCulture))
                return "true";
            else
                return "false";
        }

        public static string GetEnds_With(string value1, string value2)
        {
            if (value1.EndsWith(value2, StringComparison.InvariantCulture))
                return "true";
            else
                return "false";
        }

        public static string GetCheck_Equals(string value1, string value2)
        {
            if (value1.Equals(value2, StringComparison.InvariantCulture))
                return "true";
            else
                return "false";
        }

        public static string GetCheck_In(List<string> parameterValues)
        {
            string checkValue = parameterValues[0];

            for (int i = 1; i < parameterValues.Count; i++)
            {
                if (parameterValues[i].Equals(checkValue))
                    return "true";
            }

            return "false";
        }

        public static string GetCheck_Not_In(List<string> parameterValues)
        {
            string checkValue = parameterValues[0];

            for (int i = 1; i < parameterValues.Count; i++)
            {
                if (parameterValues[i].Equals(checkValue))
                    return "false";
            }

            return "true";
        }

        public static string GetAmount_To_Iso(string userData)
        {
            string converted;
            double dblData;

            if (!double.TryParse(userData, NumberStyles.Number, CultureInfo.InvariantCulture, out dblData))
                throw new Exception("Format error");

            int dotIndex;
            if ((dotIndex = userData.IndexOf('.')) > -1)
            {
                int decimalLength = userData.Length - dotIndex - 1;

                if (decimalLength == 1)
                    converted = userData.Substring(0, dotIndex) + userData.Substring(dotIndex + 1) + "0";
                else if (decimalLength == 2)
                    converted = userData.Substring(0, dotIndex) + userData.Substring(dotIndex + 1);
                else
                    throw new Exception("Format error");
            }
            else
                converted = userData + "00";

            return converted;
        }

        public static string GetIso_To_Amount(string userData)
        {
            int iData;

            if (!Int32.TryParse(userData, NumberStyles.Number, CultureInfo.InvariantCulture, out iData))
                throw new Exception("Format error");

            // Remove leading zeros
            int pos = 0;
            int maxPos = userData.Length - 1;

            while ((pos < maxPos) && (userData[pos] == '0'))
                pos++;

            if (pos == userData.Length)
            {
                // Just zeros
                return "0.00";
            }
            else
            {
                string aux = userData.Substring(pos);
                int auxLength = aux.Length;

                if (aux.Length > 2)
                    return aux.Substring(0, auxLength - 2) + "." + aux.Substring(auxLength - 2);
                else if (aux.Length == 2)
                    return "0." + aux;
                else if (aux.Length == 1)
                    return "0.0" + aux;
                else
                    return "0.00";
            }
        }

        public static string GetNot(string userData)
        {
            return (!bool.Parse(userData)).ToString(CultureInfo.InvariantCulture);
        }

        public static string GetAnd(List<string> parameterValues)
        {
            for (int i = 1; i < parameterValues.Count; i++)
            {
                if (!bool.Parse(parameterValues[i]))
                    return "false";
            }

            return "true";
        }

        public static string GetOr(List<string> parameterValues)
        {
            for (int i = 1; i < parameterValues.Count; i++)
            {
                if (bool.Parse(parameterValues[i]))
                    return "true";
            }

            return "false";
        }

        public static string GetIsDefined(string parameterValue)
        {
            if (parameterValue != null)
                return "true";

            return "false";
        }

        public static string GetSum(List<string> parameterValues)
        {
            long result = 0;

            for (int i = 0; i < parameterValues.Count; i++)
            {
                int iParam;
                checkParameterValueInt("Sum", parameterValues, i, out iParam);

                result += iParam;
            }

            return result.ToString(CultureInfo.InvariantCulture);
        }

        public static string GetHexToDec(string hexValue)
        {
            long value = Int64.Parse(hexValue, NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture);

            return value.ToString(CultureInfo.InvariantCulture);
        }

        public static string GetReadHexString(string src, int lenPos, int lenLength)
        {
            if (lenPos + lenLength <= src.Length + 1)
            {
                string hexValue = src.Substring(lenPos, lenLength);
                int lenValue = 2 * Int32.Parse(hexValue, NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture);

                if (lenPos + lenLength + lenValue <= src.Length + 1)
                    return src.Substring(lenPos + lenLength, lenValue);
            }

            return null;
        }

        public static string GetReadDecString(string src, int lenPos, int lenLength)
        {
            if (lenPos + lenLength <= src.Length + 1)
            {
                string decValue = src.Substring(lenPos, lenLength);
                int lenValue = 2 * Int32.Parse(decValue, CultureInfo.InvariantCulture);

                if (lenPos + lenLength + lenValue <= src.Length + 1)
                    return src.Substring(lenPos + lenLength, lenValue);
            }

            return null;
        }


        public static string GetScriptAmex(string field55)
        {
            if (field55.StartsWith("C1C7D5E20001"))
            {
                if (field55.Length > 14)
                {
                    // Skip Issuer Authentication Data
                    string hexLenValue;
                    int lenValue;
                    int pos = 12;

                    hexLenValue = field55.Substring(pos, 2);
                    lenValue = 2 * Int32.Parse(hexLenValue, NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture);

                    if (field55.Length > 14 + lenValue + 2)
                    {
                        pos += lenValue + 2;

                        hexLenValue = field55.Substring(pos, 2);
                        lenValue = 2 * Int32.Parse(hexLenValue, NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture);

                        if (field55.Length >= pos + lenValue + 2)
                            return field55.Substring(pos + 2, lenValue);
                    }
                }
            }

            return null;
        }



        public static string GetComposite(bool throwIfNotEvaluable, string fieldKey, Dictionary<string, MsgFieldDefinition> fieldDefinitions, Dictionary<string, MsgField> childFields, MsgGeneralParameters generalParameters, MsgAttributes msgAttr, 
            CardData cardData, Dictionary<string, string> reqSrcValues, Dictionary<string, string> reqSnkValues, Dictionary<string, string> rspSnkValues, CardDataOMPI cardDataOMPI)
        {
            StringBuilder sbHeader = new StringBuilder();
            StringBuilder sbValues = new StringBuilder();

            bool useSecondaryBitmap = false;
            int lastInt = 8;

            int[] bitmap = new int[16];
            for (int i = 0; i < 16; i++)
                bitmap[i] = 0;

            for (int bit = 0; bit < 128; bit++)
            {
                string f = bit.ToString(CultureInfo.InvariantCulture);
                MsgField mf;
                MsgFieldDefinition mfd;

                if (childFields.TryGetValue(f, out mf) && (mf != null))
                {
                    if (fieldDefinitions.TryGetValue(f, out mfd) && (mfd != null))
                    {
                        string value = getValue(true, f, mf.dataSource, mf.dataSourceInfo, mfd.ChildFields, mf.childFields, mf.valueConditions, mf.tokens, mf.format, generalParameters, msgAttr, cardData, reqSrcValues, reqSnkValues, rspSnkValues, cardDataOMPI);

                        if (!string.IsNullOrEmpty(value))
                        {
                            // Add to bitmap
                            int currentByte = (bit % 8 == 0) ? (bit / 8 - 1) : (bit / 8);
                            bitmap[currentByte] |= (1 << (8 * (currentByte + 1) - bit));

                            sbValues.Append(MessageData.GetFieldValueISO8583(mfd, value));

                            if (bit > 64)
                                useSecondaryBitmap = true;
                        }
                    }
                }
            }


            if (useSecondaryBitmap)
            {
                bitmap[0] |= (1 << 7);
                lastInt = 16;
            }

            // Always HEX, at least for now
            //if (msgDefinition.BitmapType == BitmapTypes.HEX)
            //{
            for (int i = 0; i < lastInt; i++)
                sbHeader.Append(string.Format("{0:X2}", bitmap[i]));
            //}
            //else
            //    throw new Exception("Binary bitmap not implemented yet");

            return string.Concat(sbHeader.ToString(), sbValues.ToString());
        }

        public static string GetConstructed(bool throwIfNotEvaluable, string fieldKey, Dictionary<string, MsgFieldDefinition> fieldDefinitions, Dictionary<string, MsgField> childFields, MsgGeneralParameters generalParameters, MsgAttributes msgAttr, CardData cardData, Dictionary<string, string> reqSrcValues, Dictionary<string, string> reqSnkValues, Dictionary<string, string> rspSnkValues, CardDataOMPI cardDataOMPI)
        {
            StringBuilder sbValues = new StringBuilder();

            foreach (KeyValuePair<string, MsgField> kvp in childFields)
            {
                string f = kvp.Key;
                MsgField mf = kvp.Value;
                //MsgFieldDefinition mfd;

                //if (fieldDefinitions.TryGetValue(f, out mfd) && (mfd != null))
               // {
                    string value = getValue(true, f, mf.dataSource, mf.dataSourceInfo, null, null, mf.valueConditions, mf.tokens, mf.format, generalParameters, msgAttr, cardData, reqSrcValues, reqSnkValues, rspSnkValues, cardDataOMPI);
                    sbValues.Append(value);



                    if (string.IsNullOrEmpty(value))
                        throw new Exception(string.Format("No value for field",kvp.Key));
                       // sbValues.Append(MessageData.GetFieldValueISO8583(mfd, value));

                //}
            }

            return sbValues.ToString();
        }

        public static string GetFields(bool throwIfNotEvaluable, string fieldKey, Dictionary<string, MsgFieldDefinition> fieldDefinitions, Dictionary<string, MsgField> childFields, MsgGeneralParameters generalParameters, MsgAttributes msgAttr, CardData cardData, Dictionary<string, string> reqSrcValues, Dictionary<string, string> reqSnkValues, Dictionary<string, string> rspSnkValues, CardDataOMPI cardDataOMPI)
        {
            StringBuilder sb = new StringBuilder();

            foreach (KeyValuePair<string, MsgField> kvp in childFields)
            {
                string fKey = kvp.Key;
                MsgField mf = kvp.Value;

                string value = getValue(throwIfNotEvaluable, fKey, mf.dataSource, mf.dataSourceInfo, fieldDefinitions, mf.childFields, mf.valueConditions, mf.tokens, mf.format, generalParameters, msgAttr, cardData, reqSrcValues, reqSnkValues, rspSnkValues, cardDataOMPI);

                if (!string.IsNullOrEmpty(value))
                {
                    int keyLength = fKey.Length;
                    int keyLenLength = keyLength.ToString(CultureInfo.InvariantCulture).Length;
                    int valueLength = value.Length;
                    int valueLenLength = valueLength.ToString(CultureInfo.InvariantCulture).Length;

                    sb.AppendFormat("{0}{1}{2}{3}{4}{5}", keyLenLength, keyLength, fKey, valueLenLength, valueLength, value);
                }
            }

            return sb.ToString();
        }

        public static string GetCard_Data(bool throwIfNotEvaluable, CardData cardData, string dataKey)
        {
            
            if (cardData == null)
            {
                if (throwIfNotEvaluable)
                    throw new Exception("Card data is null");

                return null;
            }

            return cardData.GetValue(dataKey, true);
       
        }

        public static string GetCard_Tag(bool throwIfNotEvaluable, CardData cardData, string dataKey, bool returnRawData)
        {
            
            if (cardData == null)
            {
                if (throwIfNotEvaluable)
                    throw new Exception("Card data is null");

                return null;
            }

            return cardData.GetTagValue(dataKey, returnRawData, true);
        
        }

        public static string GetMembership_Number(MsgGeneralParameters generalParameters, string currencyCode)
        {
            if (generalParameters == null)
                throw new Exception("General parameters are null");

            return generalParameters.GetMembershipNumber(currencyCode);
        }

        public static string GetTerminal_Id(MsgGeneralParameters generalParameters, string currencyCode)
        {
            if (generalParameters == null)
                throw new Exception("General parameters are null");

            return generalParameters.GetTerminalId(currencyCode);
        }

        public static string GetCurrency_Symbol(MsgGeneralParameters generalParameters, string currencyCode)
        {
            if (generalParameters == null)
                throw new Exception("General parameters are null");

            return generalParameters.GetCurrencySymbol(currencyCode);
        }

        public static string GetParse_Token(string value1, string value2)
        {
            return MsgTokens.ParseToken(value1, value2);
        }

        public static string GetConcat(List<string> options)
        {
            string result = string.Empty;

            foreach (string str in options)
                result = string.Concat(result, str);

            return result;
        }

        public static string GetRandomOption(List<string> options)
        {
            Random rnd = new Random((int)DateTime.Now.Ticks);

            return options[rnd.Next(0, options.Count)];
        }

        public static string GetUserOption(Dictionary<string, string> userValues, string key)
        {
            string value;

            if (userValues.TryGetValue(key, out value))
                return value;

            return null;
        }


        public static string GetRandom(string dataType, int length)
        {
            string dt = dataType.ToLower();
            Random rnd = new Random((int)DateTime.Now.Ticks);
            byte[] bytes = new byte[length];
            ASCIIEncoding encoder = new ASCIIEncoding();


            if (dt.Equals("a"))
            {
                //A-Z

                rnd.Next(65, 90);

                for (int i = 0; i < length; i++)
                    bytes[i] = (byte)(char)rnd.Next(65, 90);

            }
            else if (dt.Equals("n"))
            {
                //0-9
                for (int i = 0; i < length; i++)
                    bytes[i] = (byte)(char)rnd.Next(48, 57);
            }
            else if (dt.Equals("an"))
            {
                //A-Z, 0-9
                for (int i = 0; i < length; i++)
                {
                    int next = rnd.Next(0, 36);

                    if (next <= 9)
                        bytes[i] = (byte)(char)(next + 48);
                    else
                        bytes[i] = (byte)(char)(next + 55);

                }
            }

            return encoder.GetString(bytes);

        }

        private static string getFormattedValue(string value, string format)
        {
            string result = null;
            if (format != null)
            {
                string[] formatInfo = format.Split('|');
                string dtype = formatInfo[0];
                string fmt = formatInfo[1];

                switch (formatInfo[0].ToLower())
                {
                    case "string":
                        result = string.Format(fmt, value);
                        break;
                    case "int32":
                        Int32 valInt32 = Int32.Parse(value);
                        result = valInt32.ToString(fmt, CultureInfo.InvariantCulture);
                        break;
                    default:
                        throw new Exception(string.Format("Unrecognized format data type '{0}'", dtype));
                }
            }
            else
                result = value;

            return result;

        }




        private static void checkParameterCount(string funcName, int expectedParameterCount, int actualParameterCount)
        {
            if (actualParameterCount != expectedParameterCount)
                throw new Exception(string.Format("Function '{0}' expects {1} parameters.  Received {2}", funcName, expectedParameterCount, actualParameterCount));
        }

        private static void checkParameterValueInt(string funcName, List<string> parameterValues, int paramIndex, out int result)
        {
            if (!Int32.TryParse(parameterValues[paramIndex], out result))
                throw new Exception(string.Format("Parameter {0} in function '{1}' must be integer type", paramIndex + 1, funcName));
        }

        private static void checkParameterValueHex(string funcName, List<string> parameterValues, int paramIndex)
        {
            string hexValue = parameterValues[paramIndex];

            for (int i = 0; i < hexValue.Length; i++)
            {
                byte aux;
                if (!Byte.TryParse(parameterValues[paramIndex], NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out aux))
                    throw new Exception(string.Format("Parameter {0} in function '{1}' must be hexadecimal type", paramIndex + 1, funcName));
            }
        }

        private static void checkParameterValueBool(string funcName, List<string> parameterValues, int paramIndex, out bool result)
        {
            if (!bool.TryParse(parameterValues[paramIndex], out result))
                throw new Exception(string.Format("Parameter {0} in function '{1}' must be boolean type", paramIndex + 1, funcName));
        }

        private static void checkLeastParameterCount(string funcName, int expectedParameterCount, int actualParameterCount)
        {
            if (actualParameterCount < expectedParameterCount)
                throw new Exception(string.Format("Function '{0}' expects at least {1} parameter.  Received {2}", funcName, expectedParameterCount, actualParameterCount));
        }

        private static string EvalParameter(bool throwIfNotFound, CardData cardData, Dictionary<string, string> reqSrcValues, Dictionary<string, string> reqSnkValues, Dictionary<string, string> rspSnkValues, string parameter, CardDataOMPI cardDataOMPI)
        {
            string result = null;
            string[] aux = parameter.Split(':');
            string source = aux[0].Substring(1);
            string tag = aux[1].Substring(0, aux[1].Length - 1);

            switch (source)
            {
                case "REQSRC":
                    if ((reqSrcValues == null || !reqSrcValues.TryGetValue(tag, out result)) && throwIfNotFound)
                        throw new Exception(string.Format("Source request value '{0}' not found", tag));
                    break;
                case "REQSNK":
                    if ((reqSnkValues == null || !reqSnkValues.TryGetValue(tag, out result)) && throwIfNotFound)
                        throw new Exception(string.Format("Sink request value '{0}' not found", tag));
                    break;
                case "RSPSNK":
                    if ((rspSnkValues == null || !rspSnkValues.TryGetValue(tag, out result)) && throwIfNotFound)
                        throw new Exception(string.Format("Sink response value '{0}' not found", tag));
                    break;
                case "CD":
                    result = cardData.GetValue(tag, throwIfNotFound);
                    break;
                case "CDOMPI":
                    result = cardDataOMPI.GetValue(tag, throwIfNotFound);
                    break;
                default:
                    throw new Exception(string.Format("Unknown placeholder '{0}'", source));
            }


            return result;
        }

        private static string evalFunction(bool throwIfNotEvaluable, MsgGeneralParameters generalParameters, MsgAttributes msgAttr, 
            CardData cardData,
            Dictionary<string, string> reqSrcValues, Dictionary<string, string> reqSnkValues, Dictionary<string, string> rspSnkValues, string funcName, List<string> funcParameters,
            CardDataOMPI cardDataOMPI)
        {
            bool evaluable = true;
            bool mustEvaluateParams = true;
            string result = null;
            List<string> parameterValues = new List<string>();

            if (funcName.ToUpper() == "IS_DEFINED")
            {
                // This function DOES work withs nulls, so I override normal behavior
                mustEvaluateParams = false;
                throwIfNotEvaluable = false;
            }

            foreach (string parameter in funcParameters)
            {
                string parameterValue = parameter.Trim();

                string actualParameterValue = null;

                if (parameter.IndexOf('(') > -1)
                    actualParameterValue = EvalFunction(throwIfNotEvaluable, generalParameters, msgAttr, cardData, reqSrcValues, reqSnkValues, rspSnkValues, parameterValue, cardDataOMPI);
                else if (parameter.IndexOf("[") > -1)
                    actualParameterValue = EvalParameter(throwIfNotEvaluable, cardData, reqSrcValues, reqSnkValues, rspSnkValues, parameterValue, cardDataOMPI);
                else if (parameterValue.StartsWith("'") && parameterValue.EndsWith("'"))
                    actualParameterValue = parameterValue.Substring(1, parameterValue.Length - 2);
                else
                    actualParameterValue = parameterValue;

                if ((actualParameterValue == null) && (mustEvaluateParams))
                {
                    evaluable = false;
                    break;
                }

                parameterValues.Add(actualParameterValue);
            }

            if (evaluable)
            {
                int parameterCount = parameterValues.Count;
                int iParam1, iParam2;
                bool bParam1;

                switch (funcName)
                {
                    case "LENGTH":
                        checkParameterCount(funcName, 1, parameterCount);

                        result = parameterValues[0].Length.ToString(CultureInfo.InvariantCulture);
                        break;
                    case "SUBSTRING":
                        checkParameterCount(funcName, 3, parameterCount);
                        checkParameterValueInt(funcName, parameterValues, 1, out iParam1);
                        checkParameterValueInt(funcName, parameterValues, 2, out iParam2);

                        result = parameterValues[0].Substring(iParam1, iParam2);
                        break;

                    case "SUBSTRINGSTART":
                        checkParameterCount(funcName, 2, parameterCount);
                        checkParameterValueInt(funcName, parameterValues, 1, out iParam1);

                        result = parameterValues[0].Substring(iParam1).Trim();
                        break;

                    case "CONCAT":
                        checkLeastParameterCount(funcName, 1, parameterCount);

                        result = GetConcat(parameterValues);
                        break;
                    case "RANDOM":
                        checkParameterCount(funcName, 2, parameterCount);
                        checkParameterValueInt(funcName, parameterValues, 1, out iParam1);

                        result = GetRandom(parameterValues[0], iParam1);
                        break;
                    case "LIST":
                        checkLeastParameterCount(funcName, 1, parameterCount);

                        result = GetRandomOption(parameterValues);
                        break;
                    case "CHECK_EQUALS":
                        checkParameterCount(funcName, 2, parameterCount);

                        result = GetCheck_Equals(parameterValues[0], parameterValues[1]);
                        break;
                    case "STARTS_WITH":
                        checkParameterCount(funcName, 2, parameterCount);

                        result = GetStarts_With(parameterValues[0], parameterValues[1]);
                        break;
                    case "ENDS_WITH":
                        checkParameterCount(funcName, 2, parameterCount);

                        result = GetEnds_With(parameterValues[0], parameterValues[1]);
                        break;
                    case "CHECK_IN":
                        checkLeastParameterCount(funcName, 2, parameterCount);

                        result = GetCheck_In(parameterValues);
                        break;
                    case "CHECK_NOT_IN":
                        checkLeastParameterCount(funcName, 2, parameterCount);

                        result = GetCheck_Not_In(parameterValues);
                        break;
                    case "PARSE_TOKEN":
                        checkParameterCount(funcName, 2, parameterCount);

                        result = GetParse_Token(parameterValues[0], parameterValues[1]);
                        break;
                    case "TRUE":
                        checkParameterCount(funcName, 0, parameterCount);

                        result = GetTrue();
                        break;
                    case "CARD_DATA":
                        checkParameterCount(funcName, 1, parameterCount);

                        result = GetCard_Data(throwIfNotEvaluable, cardData, parameterValues[0]);
                        break;
                    case "CARD_TAG":
                        checkParameterCount(funcName, 2, parameterCount);
                        checkParameterValueBool(funcName, parameterValues, 1, out bParam1);

                        result = GetCard_Tag(throwIfNotEvaluable, cardData,  parameterValues[0], bParam1);
                        break;

                    case "MEMBERSHIP_NUMBER":
                        checkParameterCount(funcName, 1, parameterCount);

                        result = GetMembership_Number(generalParameters, parameterValues[0]);
                        break;
                    case "TERMINAL_ID":
                        checkParameterCount(funcName, 1, parameterCount);

                        result = GetTerminal_Id(generalParameters, parameterValues[0]);
                        break;
                    case "CURRENCY_SYMBOL":
                        checkParameterCount(funcName, 1, parameterCount);

                        result = GetCurrency_Symbol(generalParameters, parameterValues[0]);
                        break;
                    case "AMOUNT_TO_ISO":
                        checkParameterCount(funcName, 1, parameterCount);

                        result = GetAmount_To_Iso(parameterValues[0]);
                        break;
                    case "ISO_TO_AMOUNT":
                        checkParameterCount(funcName, 1, parameterCount);

                        result = GetIso_To_Amount(parameterValues[0]);
                        break;
                    case "NOT":
                        checkParameterCount(funcName, 1, parameterCount);

                        result = GetNot(parameterValues[0]);
                        break;
                    case "AND":
                        checkLeastParameterCount(funcName, 1, parameterCount);

                        result = GetAnd(parameterValues);
                        break;
                    case "OR":
                        checkLeastParameterCount(funcName, 1, parameterCount);

                        result = GetOr(parameterValues);
                        break;
                    case "LOCALDATETIME":
                        checkParameterCount(funcName, 1, parameterCount);

                        result = GetDateTime(DataSources.LocalDateTime, msgAttr, parameterValues[0]);
                        break;
                    case "UTCDATETIME":
                        checkParameterCount(funcName, 1, parameterCount);

                        result = GetDateTime(DataSources.UTCDateTime, msgAttr, parameterValues[0]);
                        break;
                    case "OPERATIONCODE":
                        checkParameterCount(funcName, 0, parameterCount);

                        result = GetOperationCode(msgAttr);
                        break;
                    case "IS_DEFINED":
                        checkParameterCount(funcName, 1, parameterCount);

                        result = GetIsDefined(parameterValues[0]);
                        break;
                    case "SUM":
                        checkLeastParameterCount(funcName, 2, parameterCount);

                        result = GetSum(parameterValues);
                        break;
                    case "HEX_TO_DEC":
                        checkParameterCount(funcName, 1, parameterCount);
                        checkParameterValueHex(funcName, parameterValues, 0);

                        result = GetHexToDec(parameterValues[0]);
                        break;

                    case "READ_HEX_STRING":
                        checkParameterCount(funcName, 3, parameterCount);
                        checkParameterValueInt(funcName, parameterValues, 1, out iParam1);
                        checkParameterValueInt(funcName, parameterValues, 2, out iParam2);

                        result = GetReadHexString(parameterValues[0], iParam1, iParam2);
                        break;

                    case "READ_DEC_STRING":
                        checkParameterCount(funcName, 3, parameterCount);
                        checkParameterValueInt(funcName, parameterValues, 1, out iParam1);
                        checkParameterValueInt(funcName, parameterValues, 2, out iParam2);

                        result = GetReadDecString(parameterValues[0], iParam1, iParam2);
                        break;

                    case "GET_SCRIPT_AMEX":
                        checkParameterCount(funcName, 1, parameterCount);

                        result = GetScriptAmex(parameterValues[0]);
                        break;

                    default:
                        throw new Exception(string.Format("Unknown function name '{0}'", funcName));
                }
            }

            return result;
        }

        public static string EvalFunction(bool throwIfNotEvaluable, MsgGeneralParameters generalParameters, MsgAttributes msgAttr, CardData cardData, Dictionary<string, string> reqSrcValues, Dictionary<string, string> reqSnkValues, Dictionary<string, string> rspSnkValues, string func, CardDataOMPI cardDataOMPI)
        {
            string result = null;
            int nestLevel = 0;
            int maxNestLevel = 0;
            int paramStartIndex = -1;
            string funcName = null;
            List<string> funcParameters = new List<string>();


            for (int pos = 0; pos < func.Length; pos++)
            {
                switch (func[pos])
                {
                    case '(':
                        nestLevel++;
                        if (maxNestLevel < nestLevel)
                            maxNestLevel = nestLevel;

                        if (nestLevel == 1)
                        {
                            funcName = func.Substring(0, pos).Trim().ToUpper();
                            paramStartIndex = pos + 1;
                        }
                        break;
                    case ')':
                        nestLevel--;
                        if (nestLevel == 0)
                        {
                            string parameter = func.Substring(paramStartIndex, pos - paramStartIndex);

                            if (parameter.Trim().Length > 0)
                                funcParameters.Add(func.Substring(paramStartIndex, pos - paramStartIndex));

                            result = evalFunction(throwIfNotEvaluable, generalParameters, msgAttr, cardData, reqSrcValues, reqSnkValues, rspSnkValues, funcName, funcParameters, cardDataOMPI);
                        }
                        else if (nestLevel < 0)
                        {
                            throw new Exception("Parse error");
                        }
                        break;
                    case ',':
                        if (nestLevel == 1)
                        {
                            funcParameters.Add(func.Substring(paramStartIndex, pos - paramStartIndex));
                            paramStartIndex = pos + 1;
                        }
                        break;

                }
            }

            if ((nestLevel != 0) || (maxNestLevel < 1))
            {
                throw new Exception("General parse error");
            }

            return result;
        }



        private static string getValue(bool throwIfNotEvaluable, string fieldKey, DataSources dataSource, string dataSourceInfo, Dictionary<string, MsgFieldDefinition> fieldDefinitions, Dictionary<string, MsgField> childFields, List<MsgFieldValueCondition> valueConditions, Dictionary<string, MsgTokens> tokens, string format, MsgGeneralParameters generalParameters, MsgAttributes msgAttr, 
            CardData cardData, Dictionary<string, string> reqSrcValues, Dictionary<string, string> reqSnkValues, Dictionary<string, string> rspSnkValues, CardDataOMPI cardDataOMPI)
        {
            string aux = null;
            string result = null;

            string actualFieldKey;

            switch (dataSource)
            {
                case DataSources.LocalDateTime:
                case DataSources.UTCDateTime:
                    result = GetDateTime(dataSource, msgAttr, format);
                    break;
                case DataSources.OperationCode:
                    result = GetOperationCode(msgAttr);
                    break;
                case DataSources.Fixed:
                    if ((aux = dataSourceInfo) != null)
                        result = getFormattedValue(aux, format);
                    break;
                case DataSources.Echo:
                    if ((aux = GetUserOption(reqSrcValues, fieldKey)) != null)
                        result = getFormattedValue(aux, format);
                    break;
                case DataSources.CopyReqSrc:
                    if (string.IsNullOrEmpty(dataSourceInfo))
                        actualFieldKey = fieldKey;
                    else
                        actualFieldKey = dataSourceInfo;

                    if ((aux = GetUserOption(reqSrcValues, actualFieldKey)) != null)
                        result = getFormattedValue(aux, format);
                    break;
                case DataSources.CopyReqSnk:
                    if (string.IsNullOrEmpty(dataSourceInfo))
                        actualFieldKey = fieldKey;
                    else
                        actualFieldKey = dataSourceInfo;

                    if ((aux = GetUserOption(reqSnkValues, actualFieldKey)) != null)
                        result = getFormattedValue(aux, format);
                    break;
                case DataSources.CopyRspSnk:
                    if (string.IsNullOrEmpty(dataSourceInfo))
                        actualFieldKey = fieldKey;
                    else
                        actualFieldKey = dataSourceInfo;

                    if ((aux = GetUserOption(rspSnkValues, actualFieldKey)) != null)
                        result = getFormattedValue(aux, format);
                    break;
                case DataSources.Function:
                    if ((aux = EvalFunction(throwIfNotEvaluable, generalParameters, msgAttr, cardData , reqSrcValues, reqSnkValues, rspSnkValues, dataSourceInfo, cardDataOMPI)) != null)
                        result = getFormattedValue(aux, format);
                    break;
                case DataSources.Conditional:
                    foreach (MsgFieldValueCondition mfvc in valueConditions)
                    {
                        if (bool.Parse(EvalFunction(throwIfNotEvaluable, generalParameters, msgAttr, cardData, reqSrcValues, reqSnkValues, rspSnkValues, mfvc.Condition, cardDataOMPI)))
                        {
                            // Condition has been met
                            result = getValue(throwIfNotEvaluable, fieldKey, mfvc.DataSource, mfvc.DataSourceInfo, null, null, mfvc.NestedConditions, null, mfvc.Format, generalParameters, msgAttr, cardData, reqSrcValues, reqSnkValues, rspSnkValues, cardDataOMPI);
                            break;
                        }
                    }

                    break;
                case DataSources.Tokens:
                    StringBuilder sbTokens = new StringBuilder();
                    StringBuilder sbTokenFields = new StringBuilder();
                    string tokenFieldValue;
                    int tokenCount = 0;

                    foreach (KeyValuePair<string, MsgTokens> kvp in tokens)
                    {
                        MsgTokens mt = kvp.Value;

                        sbTokenFields.Remove(0, sbTokenFields.Length);

                        foreach (MsgField mf in mt.TokenFields)
                        {
                            tokenFieldValue = getValue(throwIfNotEvaluable, mf.Key, mf.DataSource, mf.DataSourceInfo, null, mf.childFields, mf.valueConditions, mf.tokens, mf.format, generalParameters, msgAttr, cardData, reqSrcValues, reqSnkValues, rspSnkValues, cardDataOMPI);

                            if (tokenFieldValue != null)
                                sbTokenFields.Append(tokenFieldValue);
                        }

                        if (sbTokenFields.Length > 0)
                        {
                            if (sbTokenFields.ToString().StartsWith(string.Format("! {0}", mt.Key)))
                                sbTokens.Append(sbTokenFields.ToString());
                            else
                                sbTokens.AppendFormat("! {0}{1:D5} {2}", mt.Key, sbTokenFields.Length, sbTokenFields.ToString());

                            tokenCount++;
                        }
                    }

                    result = string.Format("& {0:D5}{1:D5}{2}", tokenCount + 1, sbTokens.Length + 12, sbTokens.ToString());

                    break;
                case DataSources.XmlData:
                    XmlField xmlFields = new XmlField();

                    foreach (KeyValuePair<string, MsgField> kvp in childFields)
                    {
                        string xmlKey = kvp.Key;
                        MsgField mf = kvp.Value;

                        string xmlFieldValue = getValue(throwIfNotEvaluable, mf.Key, mf.DataSource, mf.DataSourceInfo, null, null, mf.valueConditions, mf.tokens, mf.format, generalParameters, msgAttr, cardData, reqSrcValues, reqSnkValues, rspSnkValues, cardDataOMPI);

                        xmlFields.SetValue(xmlKey, xmlFieldValue);
                    }

                    result = xmlFields.ToXmlString();

                    break;
                case DataSources.User:
                    if ((aux = GetUserOption(reqSrcValues, dataSourceInfo)) != null)
                        result = getFormattedValue(aux, format);
                    break;
                case DataSources.CardData:
                    if ((aux = GetCard_Data(throwIfNotEvaluable, cardData, dataSourceInfo)) != null)
                        result = getFormattedValue(aux, format);
                    break;
                case DataSources.Composite:
                    result = GetComposite(throwIfNotEvaluable, fieldKey, fieldDefinitions[fieldKey].ChildFields, childFields, generalParameters, msgAttr, cardData, reqSrcValues, reqSnkValues, rspSnkValues, cardDataOMPI);
                    break;
                case DataSources.Constructed:
                    result = GetConstructed(throwIfNotEvaluable, fieldKey, fieldDefinitions, childFields, generalParameters, msgAttr, cardData, reqSrcValues, reqSnkValues, rspSnkValues, cardDataOMPI);
                    break;
                case DataSources.Fields:
                    result = GetFields(throwIfNotEvaluable, fieldKey, fieldDefinitions, childFields, generalParameters, msgAttr, cardData, reqSrcValues, reqSnkValues, rspSnkValues, cardDataOMPI);
                    break;
                case DataSources.CardDataOMPI:
                    result = cardDataOMPI.GetValue(dataSourceInfo, throwIfNotEvaluable);
                    result = getFormattedValue(result, format);
                    break;
                default:
                    throw new Exception(string.Format("Data Source {0} not implemented yet", dataSource));
            }

            return result;

        }

        public string GetValue(bool throwIfNotEvaluable, MsgGeneralParameters generalParameters, MsgAttributes msgAttr, Dictionary<string, MsgFieldDefinition> fieldDefinitions, CardData cardData, Dictionary<string, string> reqSrcValues, Dictionary<string, string> reqSnkValues, Dictionary<string, string> rspSnkValues, CardDataOMPI cardDataOMPI)
        {
            return getValue(throwIfNotEvaluable, this.key, this.dataSource, this.dataSourceInfo, fieldDefinitions, this.childFields, this.valueConditions, this.tokens, this.format, generalParameters, msgAttr, cardData, reqSrcValues, reqSnkValues, rspSnkValues, cardDataOMPI);
        }

        public bool GetMandatory(MsgGeneralParameters generalParameters, MsgAttributes msgAttr, CardData cardData, Dictionary<string, string> reqSrcValues, Dictionary<string, string> reqSnkValues, Dictionary<string, string> rspSnkValues, CardDataOMPI cardDataOMPI)
        {
            bool result = false;

            switch (mandatory)
            {
                case MandatoryTypes.True:
                    result = true;
                    break;
                case MandatoryTypes.Conditional:
                    if (bool.Parse(MsgField.EvalFunction(true, generalParameters, msgAttr, cardData, reqSrcValues, reqSnkValues, rspSnkValues, mandatoryCondition, cardDataOMPI)))
                        result = true;
                    break;
            }

            return result;
        }


    }
}
