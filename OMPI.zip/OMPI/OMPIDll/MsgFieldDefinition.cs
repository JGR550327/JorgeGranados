﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Text.RegularExpressions;

namespace OMPI
{
    public enum MsgFieldDefinitionTypes
    {
        Simple = 0,
        Constructed = 1,
        Composite = 2
    }

    public class MsgFieldDefinition
    {
        private string key;
        private MsgFieldDefinitionTypes fieldType;
        private string name;
        private string representation;

        private string dataType;
        private bool variableLength;
        private int length;
        private int lenLength;

        private Dictionary<string, MsgFieldDefinition> childFields;

        public MsgFieldDefinition(string key, MsgFieldDefinitionTypes fieldType, string name, string representation)
        {
            this.key = key;
            this.fieldType = fieldType;
            this.name = name;
            this.representation = representation;

            this.childFields = null;

            ParseRepresentation();
        }


        private void ParseRepresentation()
        {
            int dotIndex, lastDotIndex, spaceIndex;
            char[] removeChars = new char[] { ' ' };

            if ((dotIndex = representation.IndexOf('.')) > -1)
            {
                variableLength = true;
                dataType = representation.Substring(0, dotIndex).Trim(removeChars);

                lastDotIndex = representation.LastIndexOf('.');
                length = Int32.Parse(representation.Substring(lastDotIndex + 1).Trim(removeChars));

                lenLength = lastDotIndex - dotIndex + 1;
            }
            else
            {
                variableLength = false;
                spaceIndex = representation.IndexOf(' ');

                dataType = representation.Substring(0, spaceIndex);
                length = Int32.Parse(representation.Substring(spaceIndex + 1).Trim(removeChars));
                lenLength = 0;
            }

        }

        public string Key
        {
            get { return key; }
        }

        public MsgFieldDefinitionTypes FieldType
        {
            get { return fieldType; }
        }

        public string Name
        {
            get { return name; }
        }

        public string Representation
        {
            get { return representation; }
        }

        public string DataType
        {
            get { return dataType; }
        }

        public int Length
        {
            get { return length; }
        }

        public int LenLength
        {
            get { return lenLength; }
        }

        public bool VariableLength
        {
            get { return variableLength; }
        }

        public Dictionary<string, MsgFieldDefinition> ChildFields
        {
            get { return childFields; }
        }

        private void loadChildFields(XmlNode baseNode)
        {
            childFields = new Dictionary<string, MsgFieldDefinition>();

            XmlNode current = baseNode.FirstChild;

            while (current != null)
            {
                MsgFieldDefinition mfd = LoadFromXml(current);
                childFields.Add(mfd.key, mfd);

                current = current.NextSibling;
            }
        
        }

        public static MsgFieldDefinition LoadFromXml(XmlNode baseNode)
        {
            if (!baseNode.Name.Equals("Field", StringComparison.InvariantCultureIgnoreCase))
                throw new Exception("Unexpected XML structure");

            string key = baseNode.Attributes["key"].Value;
            MsgFieldDefinitionTypes mfdt = (MsgFieldDefinitionTypes)Enum.Parse(typeof(MsgFieldDefinitionTypes), baseNode.Attributes["fieldType"].Value, true);
            string name = baseNode.Attributes["name"].Value;
            string representation = baseNode.Attributes["representation"].Value;

            MsgFieldDefinition result = new MsgFieldDefinition(key, mfdt, name, representation);

            if (mfdt == MsgFieldDefinitionTypes.Composite || mfdt == MsgFieldDefinitionTypes.Constructed)
                result.loadChildFields(baseNode);

            return result;

        }

        public bool ValidateData(string value)
        {
            bool result = false;
            int valueLength = value.Length;
            string allowedChars = null;

            if (dataType.IndexOf('b') > -1)
            {

                if (
                (!variableLength && (valueLength == length))
                || (variableLength && (valueLength <= length))
                )
                {
                    // Binary data, nothing to validate
                    result = true;
                }
                else if (
               (!variableLength && (valueLength == (2 * length)))
               || (variableLength && (valueLength <= (2 * length)))
               )
                {
                    //Check for hex data instead of binary
                    if (Regex.IsMatch(value, "^([0-9a-fA-F])*$"))
                        result = true;
                }
            }

            else if (
                (!variableLength && (valueLength == length))
                || (variableLength && (valueLength <= length))
                )
            {
                string pattern = null;
                allowedChars = string.Empty;

                if (dataType == "xn")
                    pattern = "^[c|d]([0-9])*$";
                else if (dataType == "z")
                    pattern = @"^([0-9])+\=([0-9])*$";
                else if (dataType == "f")
                    pattern = @"^[0-9]+(\.[0-9]{1,2})?$";
                else
                {
                    if (dataType.IndexOf('a') > -1)
                        allowedChars += "a-zA-Z";
                    if (dataType.IndexOf('n') > -1)
                        allowedChars += "0-9";
                    if (dataType.IndexOf('s') > -1)
                        allowedChars += @"@\!\#\$\%\&\/\(\)\=\+\-\*\{\}\[\]\ _\.\,\<\>\:";
                    if (dataType.IndexOf('p') > -1)
                        allowedChars += " ";

                    pattern = string.Format("^([{0}])*$", allowedChars);
                }

                if (Regex.IsMatch(value, pattern))
                    result = true;
                
            }

            return result;
        }


    }
}
