﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace OMPI
{
    public class MsgFieldValueCondition
    {
        private string condition;
        private DataSources dataSource;
        private string dataSourceInfo;
        private string format;
        private List<MsgFieldValueCondition> nestedConditions;

        public MsgFieldValueCondition(string condition, DataSources dataSource, string dataSourceInfo, string format)
        {
            this.condition = condition;
            this.dataSource = dataSource;
            this.dataSourceInfo = dataSourceInfo;
            this.format = format;
        }

        public string Condition { get { return condition; } }
        public DataSources DataSource { get { return dataSource; } }
        public string DataSourceInfo { get { return dataSourceInfo; } }
        public string Format { get { return format; } }
        public List<MsgFieldValueCondition> NestedConditions { get { return nestedConditions; } }


        private static List<MsgFieldValueCondition> loadNestedConditions(XmlNode baseNode, Dictionary<string, MsgCondition> conditions)
        {
            List<MsgFieldValueCondition> result = new List<MsgFieldValueCondition>();
            XmlNode current = baseNode.FirstChild;

            while (current != null)
            {
                result.Add(LoadFromXml(current, conditions));
                current = current.NextSibling;
            }

            return result;
        }

        public static MsgFieldValueCondition LoadFromXml(XmlNode baseNode, Dictionary<string, MsgCondition> conditions)
        {
            if (!baseNode.Name.Equals("Value", StringComparison.InvariantCultureIgnoreCase))
                throw new Exception("Invalid XML structure");

            string condition = baseNode.Attributes["condition"].Value;
            
            MsgCondition msgCondition;
            if (!conditions.TryGetValue(condition, out msgCondition))
                throw new Exception(string.Format("Undefined condition '{0}'", condition));


            XmlAttribute aux;
            string format;
            DataSources dataSource;

            if ((aux = baseNode.Attributes["format"]) != null)
                format = aux.Value;
            else
                format = null;

            if ((aux = baseNode.Attributes["dataSource"]) != null)
                dataSource = (DataSources)Enum.Parse(typeof(DataSources), aux.Value, true);
            else
                dataSource = DataSources.None;

            MsgFieldValueCondition result;
            string dataSourceInfo;

            if (dataSource == DataSources.Conditional)
            {
                dataSourceInfo = null;
                result = new MsgFieldValueCondition(msgCondition.Function, dataSource, dataSourceInfo, format);

                result.nestedConditions = loadNestedConditions(baseNode, conditions);
            }
            else
            {
                dataSourceInfo = baseNode.InnerXml;
                result = new MsgFieldValueCondition(msgCondition.Function, dataSource, dataSourceInfo, format);
            }

            return result;
        }

    }
}
