﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;
using System.Security.Cryptography;
using System.Security.Cryptography.Xml;

namespace OMPI
{
    public class MsgGeneralParameters
    {
        private MsgConnectionInfo connectionInfo;
        private MsgPinPadInfo pinPadInfo;
        private Dictionary<string, MsgCurrency> currencies;

        public MsgGeneralParameters()
        {
            currencies = new Dictionary<string, MsgCurrency>();
        }

        public MsgConnectionInfo ConnectionInfo
        {
            get { return connectionInfo; }
        }

        public MsgPinPadInfo PinPadInfo
        {
            get { return pinPadInfo; }
        }

        public Dictionary<string, MsgCurrency> Currencies
        {
            get { return currencies; }
        }

        private static void loadCurrencies(MsgGeneralParameters mgp, XmlNode baseNode)
        {
            XmlNode current = baseNode.FirstChild;

            while (current != null)
            {
                MsgCurrency mc = MsgCurrency.LoadFromXml(current);
                mgp.currencies.Add(mc.Code, mc);

                current = current.NextSibling;
            }
        
        }

        private static bool verifyXml(XmlDocument xmlDocument, RSA rsaKey)
        {
            bool result = false;

            // Check arguments
            if (xmlDocument == null)
                throw new ArgumentException("xmlDocument");

            if (rsaKey == null)
                result = true;
            else
            {

                SignedXml signedXml = new SignedXml(xmlDocument);
                XmlNodeList nodeList = xmlDocument.GetElementsByTagName("Signature");

                // Throw an exception if no signature was found
                if (nodeList.Count == 1)
                {
                    // Load the first <DocumentSignature> node  
                    signedXml.LoadXml((XmlElement)nodeList[0]);

                    // Check the signature and return the result
                    result = signedXml.CheckSignature(rsaKey);
                }
            }

            return result;
        }

        private static MsgGeneralParameters loadFromXml(string xmlFile, RSACryptoServiceProvider rsaKey)
        {
            MsgGeneralParameters result = new MsgGeneralParameters();

            XmlReaderSettings xrs = new XmlReaderSettings();
            xrs.IgnoreComments = true;
            xrs.IgnoreWhitespace = false;

            using (XmlReader reader = XmlReader.Create(xmlFile, xrs))
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(reader);

                //if (!verifyXml(doc, rsaKey))
                //    throw new Exception("Invalid document signature");

                XmlNode root = doc.FirstChild.NextSibling;

                if (!root.Name.Equals("GeneralParams"))
                    throw new Exception("Invalid XML structure");

                result = LoadFromXml(root, rsaKey);

            }

            return result;
        }

        public static MsgGeneralParameters LoadFromXml(XmlNode baseNode, RSACryptoServiceProvider rsaKey)
        {
            MsgGeneralParameters result;

            XmlNode current;
            XmlAttribute attr;

            if ((attr = baseNode.Attributes["LoadFromExternalFile"]) != null)
            {
                // Load from external file

                if (baseNode.HasChildNodes)
                    throw new Exception("GeneralParams nodes with the 'LoadFromExternalFile' attribute cannot include child nodes");

                string path = attr.Value;
                string filePath;
                
                // Ensure relative paths refer to current file!
                if (!path.Contains(":"))
                {
                    string currentPath = Path.GetDirectoryName(baseNode.OwnerDocument.BaseURI);
                    filePath = string.Concat(currentPath, @"\", path);
                }
                else
                    filePath = path;

                result = loadFromXml(filePath, rsaKey);
            }
            else
            {
                if (!baseNode.HasChildNodes)
                    throw new Exception("GeneralParams nodes without the 'LoadFromExternalFile' attribute must include child nodes");

                result = new MsgGeneralParameters();

                current = baseNode.FirstChild;

                while (current != null)
                {
                    switch(current.Name)
                    {
                        case "ConnectionInfo":
                            result.connectionInfo = MsgConnectionInfo.LoadFromXml(current);
                            break;
                        case "PinPad":
                            result.pinPadInfo = MsgPinPadInfo.LoadFromXml(current);
                            break;
                        case "Currencies":
                            loadCurrencies(result, current);
                            break;
                        case "Signature":
                            // Ignore
                            break;
                        default:
                            throw new Exception(string.Format("Unexpected node '{0}' in general parameters", current.Name));
                    
                    }

                    current = current.NextSibling;
                }
            }

            return result;
        }


        public string GetMembershipNumber(string currencyCode)
        {
            if (currencies != null)
            { 
                MsgCurrency currency;
                if (currencies.TryGetValue(currencyCode, out currency))
                    return currency.MembershipNumber;
            }

            return null;
        }

        public string GetTerminalId(string currencyCode)
        {
            if (currencies != null)
            {
                MsgCurrency currency;
                if (currencies.TryGetValue(currencyCode, out currency))
                    return currency.TerminalId;
            }

            return null;
        }

        public string GetCurrencySymbol(string currencyCode)
        {
            if (currencies != null)
            {
                MsgCurrency currency;
                if (currencies.TryGetValue(currencyCode, out currency))
                    return currency.Symbol;
            }

            return null;
        }
    }
}
