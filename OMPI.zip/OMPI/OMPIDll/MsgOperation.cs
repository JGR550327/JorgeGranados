﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Globalization;

namespace OMPI
{
    public class MsgOperation
    {

        public enum PinPadOperationType
        {
            Venta,
            DevolucionNormal,
            VentaForzada,
            CancelacionVenta,
            CancelacionCredito,
            PostPropina,
            CancelacionPostpropina,
            CargaLlaves
        }

        private string code;
        public string Code { get { return code; } }

        private bool reversalSupported;
        public bool ReversalSupported { get { return reversalSupported; } }

        private int maxReversalRetries;
        public int MaxReversalRetries { get { return maxReversalRetries; } }

        private MsgTransaction request;
        public MsgTransaction Request { get { return request; } }

        private MsgTransaction response;
        public MsgTransaction Response { get { return response; } }

        private MsgTransaction reversal;
        public MsgTransaction Reversal { get { return reversal; } }

        private MsgTransaction reversalResponse;
        public MsgTransaction ReversalResponse { get { return reversalResponse; } }

        private bool cardDataRequired;
        public bool CardDataRequired { get { return cardDataRequired; } }

        private string description;

        public string Description
        {
            get { return description; }

        }

        private string key;
        public string Key { get { return key; } }

        private PinPadOperationType pinpadOperationType;

        public PinPadOperationType PinpadOperationType
        {
            get { return pinpadOperationType; }
        }

        private bool cipheredMessage;
        public bool CipheredMessage
        {
            get { return cipheredMessage; }
        }

        private bool compressedMessage;
        public bool CompressedMessage
        {
            get { return compressedMessage; }
        }
        private MsgOperation(string key, string code, string description, bool reversalSupported, int maxReversalRetries,
                             bool cardDataRequired, PinPadOperationType pinpadOperationType, bool cipheredMessage,
                             bool compressedMessage)
        {
            this.key = key;
            this.code = code;

            this.reversalSupported = reversalSupported;
            this.maxReversalRetries = maxReversalRetries;
            this.cardDataRequired = cardDataRequired;
            this.description = description;

            this.request = null;
            this.response = null;
            this.reversal = null;
            this.reversalResponse = null;
            this.pinpadOperationType = pinpadOperationType;
            this.cipheredMessage = cipheredMessage;
            this.compressedMessage = compressedMessage;
        }


        public static MsgOperation LoadFromXml(XmlNode baseNode)
        {
            XmlAttribute attr;
            string key;
            string code;
            string description;

            bool reversalSupported = false;
            int maxReversalRetries = 0;
            bool cardDataRequired = false;

            bool cipheredMessage = false;
            bool compressedMessage = false;

            PinPadOperationType pinpadOperationType = PinPadOperationType.Venta;

            if ((attr = baseNode.Attributes["Key"]) == null)
                throw new Exception(string.Format("Missing attribute 'Key'"));
            else
                key = attr.Value;

            if ((attr = baseNode.Attributes["OperationCode"]) == null)
                throw new Exception(string.Format("Missing attribute 'OperationCode'"));
            else
                code = attr.Value;

            if ((attr = baseNode.Attributes["Description"]) == null)
                throw new Exception(string.Format("Missing attribute 'Description'"));
            else
                description = attr.Value;


            if ((attr = baseNode.Attributes["CardDataRequired"]) == null)
                throw new Exception(string.Format("Missing attribute 'CardDataRequired'"));
            else if (!bool.TryParse(attr.Value, out cardDataRequired))
                throw new Exception(string.Format("Attribute 'MxReversalRetries' must be bool"));

            if (cardDataRequired)
                if ((attr = baseNode.Attributes["PinpadOperationType"]) == null)
                    throw new Exception(string.Format("Missing attribute 'PinpadOperationType'"));
                else
                {
                    switch (attr.Value.ToUpperInvariant())
                    {
                        case "VENTA":
                            pinpadOperationType = PinPadOperationType.Venta;
                            break;
                        case "DEVOLUCION NORMAL":
                            pinpadOperationType = PinPadOperationType.DevolucionNormal;
                            break;
                        case "VENTA FORZADA":
                            pinpadOperationType = PinPadOperationType.VentaForzada;
                            break;
                        case "CANCELACION VENTA":
                            pinpadOperationType = PinPadOperationType.CancelacionVenta;
                            break;
                        case "CANCELACION CREDITO":
                            pinpadOperationType = PinPadOperationType.CancelacionCredito;
                            break;
                        case "POSTPROPINA":
                            pinpadOperationType = PinPadOperationType.PostPropina;
                            break;
                        case "CANCELACION POSTPROPINA":
                            pinpadOperationType = PinPadOperationType.CancelacionPostpropina;
                            break;
                        case "CARGA LLAVES":
                            pinpadOperationType = PinPadOperationType.CargaLlaves;
                            break;
                        default:
                            break;
                    }
                }

            if ((attr = baseNode.Attributes["ReversalSupported"]) == null)
                throw new Exception(string.Format("Missing attribute 'ReversalSupported'"));
            else if (!bool.TryParse(attr.Value, out reversalSupported))
                throw new Exception(string.Format("Attribute 'ReversalSupported' must be boolean"));

            if ((attr = baseNode.Attributes["MaxReversalRetries"]) == null)
                throw new Exception(string.Format("Missing attribute 'MaxReversalRetries'"));
            else if (!Int32.TryParse(attr.Value, NumberStyles.Any, CultureInfo.InvariantCulture, out maxReversalRetries))
                throw new Exception(string.Format("Attribute 'MxReversalRetries' must be integer"));

            // Encryption P2P  Abril 2021
            if ((attr = baseNode.Attributes["CipheredMessage"]) != null)
                bool.TryParse(attr.Value, out cipheredMessage);

            if ((attr = baseNode.Attributes["CompressedMessage"]) != null)
                bool.TryParse(attr.Value, out compressedMessage);

            MsgOperation result = new MsgOperation(key, code, description, reversalSupported, maxReversalRetries, cardDataRequired, pinpadOperationType, cipheredMessage, compressedMessage);

            XmlNode current = baseNode.FirstChild;

            while (current != null)
            {
                switch (current.Name.ToUpper())
                {
                    case "REQUEST":
                        if (result.request != null)
                            throw new Exception("Request cannot be defined more than once");

                        result.request = MsgTransaction.LoadFromXml(current);
                        break;

                    case "RESPONSE":
                        if (result.response != null)
                            throw new Exception("Response cannot be defined more than once");

                        result.response = MsgTransaction.LoadFromXml(current);
                        break;

                    case "REVERSAL":
                        if (result.reversal != null)
                            throw new Exception("Reversal cannot be defined more than once");

                        result.reversal = MsgTransaction.LoadFromXml(current);
                        break;

                    case "REVERSALRESPONSE":
                        if (result.reversalResponse != null)
                            throw new Exception("ReversalResponse cannot be defined more than once");

                        result.reversalResponse = MsgTransaction.LoadFromXml(current);
                        break;

                    default:
                        throw new Exception(string.Format("Unexpected node '{0}'", current.Name));
                }


                current = current.NextSibling;
            }

            if (result.request == null)
                throw new Exception("Request must be defined for the operation");
            else if (result.response == null)
                throw new Exception("Response must be defined for the operation");
            else if ((result.reversal == null) && reversalSupported)
                throw new Exception("Reversal must be defined for the operation if reversalSupported is enabled");
            else if ((result.reversalResponse == null) && reversalSupported)
                throw new Exception("ReversalResponse must be defined for the operation if reversalSupported is enabled");

            return result;

        }


    }
}
