﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using PinPadCommunication;
using PinPadCommunicationEGlobal;

namespace OMPI
{
    public class MsgPinPadInfo
    {
        private PinPadVersions pinPadVersion;
        private string commPort;
        private EntryCapability entryCapability;

        public MsgPinPadInfo(PinPadVersions pinPadVersion, string commPort, EntryCapability entryCapability)
        {
            this.pinPadVersion = pinPadVersion;
            this.commPort = commPort;
            this.entryCapability = entryCapability;
        }

        public PinPadVersions PinPadVersion { get { return pinPadVersion; } }
        public string CommPort { get { return commPort; } }
        public EntryCapability EntryCapability { get { return entryCapability; } }


        public static MsgPinPadInfo LoadFromXml(XmlNode baseNode)
        {
            XmlNode current = baseNode;
            string commPort = "COM4";
            EntryCapability entryCapability = EntryCapability.Unknown;
            PinPadVersions pinPadVersion;

            XmlAttribute attr;

            if ((attr = current.Attributes["commPort"]) == null)
                throw new Exception("Communication Port must be specified");
            else
                commPort = attr.Value;

            if ((attr = current.Attributes["entryCapability"]) == null)
                throw new Exception("Entry capability must be specified");
            else if (!Enum.TryParse<EntryCapability>(attr.Value, true, out entryCapability))
                throw new Exception("Entry capability must be a valid value");

            if ((attr = current.Attributes["pinPadVersion"]) == null)
            {
                Console.WriteLine("Trono prueba");
                throw new Exception("PinPad version must be specified");
            }
            else if (!Enum.TryParse<PinPadVersions>(attr.Value, true, out pinPadVersion))
                throw new Exception("PinPad version should be a valid value");

            return new MsgPinPadInfo(pinPadVersion, commPort, entryCapability);
        }


    }
}
