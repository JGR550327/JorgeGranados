﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Globalization;
using System.Runtime.InteropServices;
using PinPadCommunication;
using PinPadCommunicationEGlobal;

namespace OMPI
{
    public enum ReversalResults
    { 
        Ok = 0,
        CommunicationError = 1,
        SourceMessageError = 2,
        SinkMessageError = 3,
        Rejected = 4,
        ExceptionError = 5
    }

    public class MsgReversalData
    {
        private const string DLL_LOCATION = @"Rijndael.dll";

        [DllImport(DLL_LOCATION, EntryPoint = "RijndaelEncrypt", CharSet = CharSet.Ansi)]
        private extern static void RijndaelEncrypt(string str, StringBuilder result, ref int errorCode);

        [DllImport(DLL_LOCATION, EntryPoint = "RijndaelDecrypt", CharSet = CharSet.Ansi)]
        private extern static void RijndaelDecrypt(string str, StringBuilder result, ref int errorCode);

        private string filePath;
        private DateTime originalDate;
        private CardBrands cardBrand;
        private string messageId;
        private string operationCode;
        private string message;
        private int retries;

        public MsgReversalData(DateTime originalDate, CardBrands cardBrand, string messageId, string operationCode, string message)
        {
            this.filePath = null;
            this.originalDate = originalDate;
            this.cardBrand = cardBrand;
            this.messageId = messageId;
            this.operationCode = operationCode;
            this.message = message;
            this.retries = 0;
        }

        public DateTime OriginalDate { get { return originalDate; } }
        public CardBrands CardBrand { get { return cardBrand; } }
        public string MessageId { get { return messageId; } }
        public string OperationCode { get { return operationCode; } }
        public string Message { get { return message; } }
        public int Retries { get { return retries; } }

        private static int getResultLength(int plainLength)
        {
            if ((plainLength % 16) == 0)
                return 2 * plainLength + 1;
            else
                return 2 * (plainLength + (16 - (plainLength % 16))) + 1;
        }

        private static string encryptMessage(string message)
        {
            StringBuilder sbCipher = new StringBuilder(getResultLength(message.Length));
            int errorCode = 0;

            RijndaelEncrypt(message, sbCipher, ref errorCode);

            if (errorCode != 0)
                throw new Exception(string.Format("Error {0} encrypting data", errorCode));

            return sbCipher.ToString();
        }

        private static string decryptMessage(string cipher)
        {
            StringBuilder sbMessage = new StringBuilder(cipher.Length / 2 + 1);
            int errorCode = 0;

            RijndaelDecrypt(cipher, sbMessage, ref errorCode);

            if (errorCode != 0)
                throw new Exception(string.Format("Error {0} decrypting data", errorCode));

            return sbMessage.ToString();
        }

        public static MsgReversalData LoadFromFile(string path)
        {
            MsgReversalData result = null;

            DateTime dt;
            CardBrands cardBrand;
            string messageId = null;
            string operationCode = null;
            string message = null;
            int retries = 0;

            try
            {
                using (StreamReader sr = new StreamReader(path))
                {
                    string line;

                    if ((line = sr.ReadLine()) != null)
                    {
                        dt = DateTime.ParseExact(line, "G", CultureInfo.InvariantCulture);

                        if ((line = sr.ReadLine()) != null)
                        {
                            cardBrand = (CardBrands)Int32.Parse(line, CultureInfo.InvariantCulture);

                            if ((line = sr.ReadLine()) != null)
                            {
                                messageId = line;

                                if ((line = sr.ReadLine()) != null)
                                {
                                    operationCode = line;

                                    if ((line = sr.ReadLine()) != null)
                                    {
                                        message = decryptMessage(line);

                                        if ((line = sr.ReadLine()) != null)
                                        {
                                            retries = Int32.Parse(line, CultureInfo.InvariantCulture);

                                            result = new MsgReversalData(dt, cardBrand, messageId, operationCode, message);

                                            result.filePath = path;
                                            result.retries = retries;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {

            }

            return result;
        }


        private bool saveFile(string fileName, bool updateRetries)
        {
            bool result = false;

            using (StreamWriter sw = new StreamWriter(fileName))
            {
                int rt = retries;

                sw.WriteLine(originalDate.ToString("G", CultureInfo.InvariantCulture));
                sw.WriteLine((int)cardBrand);
                sw.WriteLine(messageId);
                sw.WriteLine(operationCode);
                sw.WriteLine(encryptMessage(message));

                if (updateRetries)
                    rt++;

                sw.WriteLine(rt.ToString(CultureInfo.InvariantCulture));
            }

            return result;
        }

        public bool UpdateFile()
        {
            return saveFile(filePath, true);
        }

        public bool SaveToFile(string path)
        {
            string actualPath;

            if (path.EndsWith(@"\"))
                actualPath = path;
            else
                actualPath = string.Concat(path, @"\");

            string fileName = string.Concat(actualPath, originalDate.ToString("yyyyMMddHmmss", CultureInfo.InvariantCulture), ".rmsg");

            return saveFile(fileName, false);
        }


        public bool IsStillReversable(int balanceHour, int balanceMinute)
        {
            bool result = true;
            DateTime balanceDate;

            DateTime currentDate = DateTime.Now;
            int currHour = currentDate.Hour;
            int currMinute = currentDate.Minute;

            int originalHour = originalDate.Hour;
            int originalMinute = originalDate.Minute;

            balanceDate = new DateTime(originalDate.Year, originalDate.Month, originalDate.Day, balanceHour, balanceMinute, 0);

            if ((originalHour > balanceHour) || ((originalHour == balanceHour) && (originalMinute >= balanceMinute)))
                balanceDate = balanceDate.AddDays(1);

            if (currentDate > balanceDate)
                result = false;

            return result;
        }
    }
}
