﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace OMPI
{
    public class MsgStructure
    {
        private Dictionary<string, MsgField> fields;
        private Dictionary<string, MsgCondition> conditions;
        private bool errorWhenUnexpectedField;

        public MsgStructure(bool errorWhenUnexpectedField)
        {
            this.errorWhenUnexpectedField = errorWhenUnexpectedField;
            fields = new Dictionary<string, MsgField>();

            conditions = new Dictionary<string, MsgCondition>();
            conditions.Add("TRUE", new MsgCondition("TRUE", "TRUE()"));

        }

        public bool ErrorWhenUnexpectedField
        {
            get { return errorWhenUnexpectedField; }
        }

        public Dictionary<string, MsgField> Fields
        {
            get { return fields; }
        }

        public Dictionary<string, MsgCondition> Conditions
        {
            get { return conditions; }
        }

        private static void loadFields(MsgStructure ms, XmlNode baseNode)
        {
            XmlNode current = baseNode.FirstChild;

            while (current != null)
            {
                if (!current.Name.Equals("Field", StringComparison.InvariantCultureIgnoreCase))
                    throw new Exception("Invalid XML structure");

                MsgField mf = MsgField.LoadFromXml(current, ms.conditions);

                ms.fields.Add(mf.Key, mf);

                current = current.NextSibling;
            }
        
        
        }

        private static void loadConditions(MsgStructure ms, XmlNode baseNode)
        {
            XmlNode current = baseNode.FirstChild;

            while (current != null)
            {
                if (!current.Name.Equals("Condition", StringComparison.InvariantCultureIgnoreCase))
                    throw new Exception("Invalid XML structure");

                MsgCondition mc = MsgCondition.LoadFromXml(current);

                ms.conditions.Add(mc.Key, mc);

                current = current.NextSibling;
            }
        }

        public static MsgStructure LoadFromXml(XmlNode baseNode)
        {
            bool errorWhenUnexpectedField = true;
            XmlAttribute attr;

            if ((attr = baseNode.Attributes["errorWhenUnexpectedField"]) != null)
                errorWhenUnexpectedField = bool.Parse(attr.Value);

            XmlNode current = baseNode.FirstChild;
            MsgStructure result = new MsgStructure(errorWhenUnexpectedField);

            while (current != null)
            {
                if (current.Name.Equals("Fields", StringComparison.InvariantCultureIgnoreCase))
                    loadFields(result, current);
                else if (current.Name.Equals("Conditions", StringComparison.InvariantCultureIgnoreCase))
                    loadConditions(result, current);
                else
                    throw new Exception("Invalid XML structure");

                current = current.NextSibling;
            }
            return result;

        }



    }
}
