﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace OMPI
{
    public class MsgTokens
    {
        private string key;
        private List<MsgField> tokenFields;

        public MsgTokens(string key)
        {
            this.key = key;

            tokenFields = new List<MsgField>();
        }

        public string Key { get { return key; } }
        public List<MsgField> TokenFields { get { return tokenFields; } }



        public static MsgTokens LoadFromXml(XmlNode baseNode, Dictionary<string, MsgCondition> conditions)
        {
            if (!baseNode.Name.Equals("Token", StringComparison.InvariantCultureIgnoreCase))
                throw new Exception("Invalid XML structure");

            string key = baseNode.Attributes["key"].Value;

            MsgTokens result = new MsgTokens(key);

            XmlNode current = baseNode.FirstChild;

            while (current != null)
            {
                MsgField mf = MsgField.LoadFromXml(current, conditions);

                result.tokenFields.Add(mf);

                current = current.NextSibling;
            }

            return result;
        }


        public static string ParseToken(string tokenData, string tokenKey)
        {
            string result = null;

            int tokenIndex;
            if ((tokenIndex = tokenData.IndexOf("! " + tokenKey)) > -1)
            {
                int valueLength = Int32.Parse(tokenData.Substring(tokenIndex + 4, 5));

                result = tokenData.Substring(tokenIndex, valueLength + 10);
            }

            return result;
        }

    }
}
