﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace OMPI
{
    public class MsgTransaction
    {
        private string mti;
        private string responseMti;
        private string reversalMti;
        private MsgStructure srcMsgStructure;
        private MsgStructure snkMsgStructure;

        public MsgTransaction(string mti, string responseMti, string reversalMti)
        {
            this.mti = mti;
            this.responseMti = responseMti;
            this.reversalMti = reversalMti;
        }

        public string Mti { get { return mti; } }
        public string ResponseMti { get { return responseMti; } }
        public string ReversalMti { get { return reversalMti; } }

        public MsgStructure SrcMsgStructure { get { return srcMsgStructure; } }
        public MsgStructure SnkMsgStructure { get { return snkMsgStructure; } }
        
        public static MsgTransaction LoadFromXml(XmlNode baseNode)
        {
            XmlAttribute attr;

            string mti = baseNode.Attributes["mti"].Value;

            string responseMti = null;
            if ((attr = baseNode.Attributes["responseMti"]) != null)
                responseMti = attr.Value;

            string reversalMti = null;
            if ((attr = baseNode.Attributes["reversalMti"]) != null)
                reversalMti = attr.Value;

            MsgTransaction result = new MsgTransaction(mti, responseMti, reversalMti);

            XmlNode current = baseNode.FirstChild;

            while (current != null)
            {
                if (current.Name.Equals("SourceMessageStructure", StringComparison.InvariantCultureIgnoreCase))
                {
                    result.srcMsgStructure = MsgStructure.LoadFromXml(current);
                }
                else if (current.Name.Equals("SinkMessageStructure", StringComparison.InvariantCultureIgnoreCase))
                {
                    result.snkMsgStructure = MsgStructure.LoadFromXml(current);
                }
                else
                    throw new Exception("Invalid XML structure");

                current = current.NextSibling;
            }

            return result;

        }

    }
}
