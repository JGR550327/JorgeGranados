﻿using PinPadCommunication;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OMPI
{
    //public class PinpadUtils
    //{

    //    public static string InitializePinPadKeys(MsgConfiguration msgConfig, Dictionary<string, string> reqSrcDataFields)
    //    {
    //        MsgAttributes msgAttr = new MsgAttributes("9999");

    //        var result = MessageFlow.ProcessMessage(msgConfig, msgAttr, reqSrcDataFields);
    //        return result.ResponseSink.FieldValues["39"];
    //    }

    //}
}
