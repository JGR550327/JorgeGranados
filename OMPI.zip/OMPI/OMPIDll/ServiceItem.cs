﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OMPI
{
    public class ServiceItem
    {
        private string key;

        public string Key
        {
            get { return key; }
            
        }

        private string operationCode;

        public string OperationCode
        {
            get { return operationCode; }
           
        }

        private String description;

        public String Description
        {
            get { return description; }
           
        }

        //private string sku;

        


        public ServiceItem()
        {

        }

       public ServiceItem(string key, string operationCode, string description)
        {
            this.key = key;
            this.operationCode = operationCode;
            this.description = description;
            
        }

    }
}
