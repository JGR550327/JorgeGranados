﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace OMPI
{
    /// <summary>
    /// Name        : Utilidad
    /// Description : Clase de Utilidad para utilizarlo en todo el proyecto 
    /// Date        : 14 Marzo, 2021
    /// Author      : Carlos Mejia
    /// </summary>
    public class Utilidad
    {

        static String[,] codigosRespuesta =
        {
            { "00", "APROBADO			"                                 },
            { "01", "FAVOR LLAMAR"                                        },
            { "02", "LLAME AL EMISOR"                                     },
            { "03", "COMERCIO INVALIDO"                                   },
            { "04", "RETENGA Y LLAME-04"                                  },	// ---
	        { "05", "DENEGADA"                                            },
            { "06", "ERROR"                                               },
            { "07", "TARJETA PERDIDA"                                     },
            { "10", "TRANS. INVALIDA"                                     },
            { "11", "APROBACION VIP (Utilizar 00) "                       },
            { "12", "TRANSACCION INVALIDA"                                },
            { "13", "MONTO INVALIDO"                                      },
            { "14", "CUENTA INVALIDA"                                     },
            { "15", "EMISOR INVALIDO"                                     },
            { "19", "REINICIE TRANSACCION"                                },
            { "21", "NINGUNA ACCION TOMADA"                               },
            { "25", "NO EXISTE COMPROBANTE"                               },	// ---	      
	        { "30", "FORMATO INVALIDO"                                    },
            { "31", "BANCO INVALIDO"                                      },	// ---	      
            { "39", "NO ES CUENTA CREDITO"                                },	// ---	      
	        { "41", "RETENER Y LLAMAR"                                    },
            { "43", "RETENER Y LLAMAR"                                    },
            { "51", "DENEGADA"                                            },
            { "52", "CUENTA INVALIDA"                                     },
            { "53", "CUENTA INVALIDA"                                     },
            { "54", "TARJETA EXPIRADA"                                    },
            { "55", "PIN INVALIDO"                                        },
            { "56", "CUENTA INVALIDA"                                     },
            { "57", "TRANS. NO PERMITIDA"                                 },
            { "58", "TRANS. INVALIDA"                                     },
            { "59", "RETENGA Y LLAME"                                     },
            { "60", "HORARIO INVALIDO"                                    },
            { "61", "LIMITES EXCEDIDOS"                                   },	// ---
	        { "62", "TARJETA RESTRINGIDA"                                 },
            { "63", "ERROR/LLAMAR"                                        },
            { "65", "NUMERO DE RETIRO EXCEDIDOS"                          },
            { "66", "CHEQUE ROBADO"                                       },
            { "75", "NUM. INTENTOS DE PIN EXCEDIDOS"                      },
            { "76", "ERROR/LLAMAR -DC"                                    },
            { "77", "ERROR EN CIERRE"                                     },
            { "78", "CARGO NO ENCONTRADO"                                 },
            { "79", "DENEGADA CVV2"                                       },
            { "80", "CIERRE COMPLETADO CON NUMERO DE LOTE INVALIDO"       },	// --- 
	        { "81", "NO DIGITO SU PIN"                                    },	// --- 
	        { "82", "NO EXISTE CARGO-82"                                  },	// --- 
	        { "83", "CARGOS NO EN SUSPEN"                                 },	// --- 	      
	        { "85", "LOTE NO ENCONTRADO"                                  },
            { "89", " NRO. TERM. INVALIDO"                                },
            { "91", "EMISOR NO CONTESTA"                                  },
            { "94", "LLAMAR/ERROR"                                        },	// ---
	        { "95", "ESPERE, TRANSMITIENDO"                               },
            { "96", "ERROR - LLAMAR"                                      },	// ---
	        { "98", "EXCEDIDO LIMITE DE EFECTIVO"                         },
            { "AA", "AA-TIPO TARJ.CAP INVAL."                             },
            { "BB", "BB-BALANCE POR LOTE"                                 },
            { "BB", "BB-BALANCE POR LOTE"                                 },
            { "BD", "BD-BALANCE DIARIO"                                   },
            { "BH", "BH-LLAMAR - ERROR HOST"                              },
            { "BU", "BU-BATCH UPLOAD NO COMPLETADO"                       },
            { "CE", "CE-INTENTE DE NUEVO"                                 },
            { "DT", "DT-DECLINADA POR TARJETA"                            },	// ---
	        { "EP", "EP-PIN INVALIDO "                                    },
            { "IF", "IF-FORMATO DE MENSAJE INVALIDO"                      },	// ---
	        { "IM", "IM-MAC INVALIDO"                                     },
            { "LB", "LB-INTENTE DE NUEVO"                                 },
            { "NA", "NA-INTENTE DE NUEVO"                                 },
            { "NB", "NB-INVALID BAL/RECORD"                               },
            { "NC", "BD-BALANCE DIARIO"                                   },
            { "ND", "ND-INTENTE DE NUEVO"                                 },
            { "NL", "NL-SIN LINEA DE TELEFONO"                            },
            { "RE", "RE-ERROR LECTURA TARJETA"                            },
            { "SA", "SA-ADVICES NO ENVIADO, POR FAVOR INTENTE NUEVO"      },	// ---
	        { "TN", "TN-TARJETA NO SOPORTADA "                            },
            { "TO", "TO-INTENTE DE NUEVO"                                 },	// ---
	        { "UC", "UC-CANCELADA POR USUARIO"                            },
            { "UN", "UN-TRANSACCION ERRONEA"                              },
            { "XC", "XC-TRANSACCION CANCELADA"                            },
            { "XX", "XX-TRANSACCION DECLINADA"                            },
            { "Y1", "Y1-APROBADA FUERA DE LINEA"                          },
            { "Y2", "Y2-APROBADA  APROBADA  "                             },
            { "Y3", "Y3-PROCESO ONLINE FALLIDO"                           },
            { "Z1", "Z1-DECLINADA OFFLINE"                                },
            { "Z2", "Z2-DECLINADA DECLINADA"                              },
            { "Z3", "Z3-PROCESO ONLINE FALLIDO "                          },
            { "LC", "LC-INTENTE DE NUEVO"                                 }

    };


        public const int MIN_RADIX = 2;

        public const int MAX_RADIX = 36;

        /// <summary>
        /// Convierte de BCD(Binary Code Decimal) de un número a cadena
        /// </summary>
        /// <param name="b">BCD representation</param>
        /// <param name="offset">starting offset</param>
        /// <param name="len">BCD field len * 2</param>
        /// <param name="padLeft">was padLeft packed?</param>
        /// <returns>the String representation of the number</returns>
        public static String Bcd2str(byte[] b, int offset,
                                                                int len, bool padLeft
                                                            )
        {
            StringBuilder d = new StringBuilder(len);

            int start = (((len & 1) == 1) && padLeft) ? 1 : 0;
            for (int i = start; i < len + start; i++)
            {
                int shift = ((i & 1) == 1 ? 0 : 4);
                char c = ForDigit(
                        ((b[offset + (i >> 1)] >> shift) & 0x0F), 16);

                d.Append(c.ToString().ToUpper());
            }
            return d.ToString();
        }

        /// <summary>
        /// * Determines the character representation for a specific digit in
        ///* the specified radix. If the value of {@code radix} is not a
        ///* valid radix, or the value of {@code digit} is not a valid
        ///* digit in the specified radix, the null character
        ///* ({@code '\u005Cu0000'}) is returned.
        ///* <p>
        ///* The {@code radix} argument is valid if it is greater than or
        ///* equal to {@code MIN_RADIX} and less than or equal to
        ///* {@code MAX_RADIX}. The {@code digit} argument is valid if
        ///* {@code 0 <= digit < radix}.
        ///* <p>
        ///* If the digit is less than 10, then
        ///* {@code '0' + digit} is returned. Otherwise, the value
        ///* {@code 'a' + digit - 10} is returned.
        ///*
        /// </summary>
        /// <param name="digit">the number to convert to a character</param>
        /// <param name="radix">the radix.</param>
        /// <returns>
        /// the {@code char} representation of the specified digit
        /// in the specified radix.
        /// </returns>
        public static char ForDigit(int digit, int radix)
        {
            if ((digit >= radix) || (digit < 0))
            {
                throw new ArgumentOutOfRangeException("radix");
            }
            if ((radix < MIN_RADIX) || (radix > MAX_RADIX))
            {
                throw new ArgumentOutOfRangeException("radix");
            }
            if (digit < 10)
            {
                return (char)('0' + digit);
            }
            return (char)('a' - 10 + digit);
        }

        /// <summary>
        ///* Rellena con el caracter especificado la cantidad de espacios faltantes en
        ///* digits Ejemplo: Vamos a rellenar de ceros el nÃºmero 15, pero lo queremos
        ///* de 5 dí­gitos 15 -> "00015"
        ///*
        ///* cadena = "15" toFillWith = "0" digitis = 5
        /// </summary>
        /// <param name="cadena"></param>
        /// <param name="toFillWith"></param>
        /// <param name="digits"></param>
        /// <returns></returns>
        public static String FillStringWith(String cadena, char toFillWith,
                                                                int digits, bool padLeft = true
                                                            )
        {
            if (padLeft)
            {
                return cadena.PadLeft(digits, toFillWith);
            }
            else
            {
                return cadena.PadRight(digits, toFillWith);
            }

        }
        /// <summary>
        /// Concatenates a number of array
        /// </summary>
        /// <param name="cntParam"></param>
        /// <returns></returns>
        public static byte[] ConcatVar(params byte[][] cntParam)
        {

            byte[] concatArrayAll = null;

            foreach (byte[] array in cntParam)
            {
                if (array == null) continue;

                if (concatArrayAll == null)
                {
                    concatArrayAll = new byte[array.Length];
                    Array.Copy(array, 0, concatArrayAll, 0, array.Length);
                    continue;
                }

                byte[] concatArrayTmp = new byte[array.Length + concatArrayAll.Length];

                Array.Copy(concatArrayAll, 0, concatArrayTmp, 0, concatArrayAll.Length);
                Array.Copy(array, 0, concatArrayTmp, concatArrayAll.Length, array.Length);

                concatArrayAll = new byte[concatArrayTmp.Length];

                Array.Copy(concatArrayTmp, 0, concatArrayAll, 0, concatArrayTmp.Length);
            }

            return concatArrayAll;
        }

        /// <summary>
        /// * Convierte una cadena a BCD (Binary Code Decimal)
        /// </summary>
        /// <param name="s">the number</param>
        /// <param name="padLeft">flag indicating left/right padding</param>
        /// <returns>BCD representation of the number</returns>
        public static byte[] Str2bcd(String s, bool padLeft)
        {
            int len = s.Length;

            byte[] d = new byte[(len + 1) >> 1];

            return Str2bcd(s, padLeft, d, 0);
        }

        /// <summary>
        /// Convierte una cadena a BCD (Binary Code Decimal)
        /// </summary>
        /// <param name="s">the number</param>
        /// <param name="padLeft">flag indicating left/right padding</param>
        /// <param name="d">The byte array to copy into.</param>
        /// <param name="offset">Where to start copying into.</param>
        /// <returns>BCD representation of the number</returns>
        public static byte[] Str2bcd(String s, bool padLeft,
                                                                byte[] d, int offset
                                                            )
        {
            int len = s.Length;
            //char[] sChar = s.ToCharArray();

            int start = (((len & 1) == 1) && padLeft) ? 1 : 0;
            for (int i = start; i < len + start; i++)
            {
                d[offset + (i >> 1)] |= (byte)((s[i - start] - '0') << ((i & 1) == 1 ? 0 : 4));
            }
            return d;
        }

        /// <summary>
        /// Obtiene el texto correspondiente al código de respuesta.
        /// </summary>
        /// <param name="responseCode"></param>
        /// <returns></returns>
        public static String GetResponseText(String responseCode)
        {
            String codigoTexto = "";

            for (int i = 0; i < codigosRespuesta.GetLength(0); i++)
            {
                if (codigosRespuesta[i, 0].Equals(responseCode))
                {
                    codigoTexto = codigosRespuesta[i, 1];
                    break;
                }
            }

            if (String.IsNullOrEmpty(codigoTexto.Trim()))
            {
                codigoTexto = "ERROR DESCONOCIDO";
            }

            return codigoTexto;
        }

        /// <summary>
        /// Chequea si la cadena es un número válido
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public static Boolean IsNumeric(String number)
        {
            Double tmp;

            Boolean isSuccess = Double.TryParse(number, out tmp);

            return isSuccess;

        }

        /// <summary>
        /// Obtiene el número de cuenta primaria, PAN (Primary Account Number), del track2
        /// </summary>
        /// <param name="track2"></param>
        /// <returns></returns>
        public static String GetPANFromTrack2(String track2)
        {

            String tmp = "";
            String PAN = "";

            if (String.IsNullOrEmpty(track2.Trim())) return "";

            for (int i = 0; i <= track2.Length; i++)
            {

                tmp = track2.Substring(i, 1);


                if (Utilidad.IsNumeric(tmp))
                {
                    PAN += tmp;
                }
                else
                {
                    break;
                }

            }

            return PAN;
        }

        /// <summary>
        /// Take a integer and turn into bcd format
        /// Example: 
        ///         int         -> 180 
        ///         bcd(bytes)  -> {0x01 , 0x80}
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static byte[] IntToByteArray(int value)
        {
            return new byte[] {
                                (byte)((uint)value >> 8),
                                (byte)value
                              };
        }

        /// <summary>
        /// Take a integer and turn into 4 length hex byte array 
        /// Example: 
        ///         int         -> 180 
        ///         bcd(bytes)  -> {0x01 , 0x80}
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static byte[] IntToHexByteArray(int value)
        {

            byte[] resultado = new byte[4];

            byte[] intBytes = BitConverter.GetBytes(value);
            if (BitConverter.IsLittleEndian)
                Array.Reverse(intBytes);

            Array.Copy(intBytes, 0, resultado, 0, intBytes.Length);


            return resultado;


        }

        /// <summary>
        /// Retorna una cadena de bytes con los das primeras posiciones 
        /// indicando el tamaño en bcd
        ///
        /// Ejemplo:   data     -> {0x34, 0x56, x34}
        /// 
        ///            return   -> {0x03, 0x34, 0x56, x34}
        ///
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static byte[] Insdata(byte[] data)
        {
            return Utilidad.ConcatVar(Utilidad.IntToByteArray(data.Length), data);
        }

        /// <summary>
        /// Function    : Aasc_to_bcd
        /// Description : Convierte  un byte ascii a un byte BCD
        /// </summary>
        /// <param name="asc"></param>
        /// <returns></returns>
        private static byte Ascii_to_bcd(byte asc)
        {
            byte bcd;

            if ((asc >= '0') && (asc <= '9'))
                bcd = (byte)(asc - '0');
            else if ((asc >= 'A') && (asc <= 'F'))
                bcd = (byte)(asc - 'A' + 10);
            else if ((asc >= 'a') && (asc <= 'f'))
                bcd = (byte)(asc - 'a' + 10);
            else
                bcd = (byte)(asc - 48);

            // reparar caso caracter ' ' quedaba como 0xF0
            if (asc == ' ')
                bcd = 0;
            return bcd;
        }

        /// <summary>
        /// Function    : ASCII_To_BCD
        /// Description : Convierte un arreglo de bytes ascii a un arreglo de bytes BCD
        /// </summary>
        /// <param name="ascii"></param>
        /// <returns></returns>
        public static byte[] ASCII_To_BCD(byte[] ascii)
        {
            byte[] bcd = new byte[ascii.Length / 2];

            int j = 0;
            for (int i = 0; i < (ascii.Length + 1) / 2; i++)
            {
                bcd[i] = Ascii_to_bcd(ascii[j++]);
                bcd[i] = (byte)(((j >= ascii.Length) ? 0x00 : Ascii_to_bcd(ascii[j++])) + (bcd[i] << 4));
            }
            return bcd;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataIn"></param>
        /// <returns></returns>
        public static byte[] OptionToBit(String dataIn)
        {
            // dataIn = NYYYNNNN = 01110000 = hex70 = dec112 = 
            byte[] bits = { 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, (byte)0x80 };
            byte convbit = 0;

            for (int ndx = 0; ndx <= dataIn.Length - 1; ndx++)
            {
                if (dataIn.Substring(ndx, 1).Equals("Y") == true)
                    convbit |= bits[ndx];
            }

            return new byte[] { convbit };
        }

        /// <summary>
        /// Function    : Bcd2Str
        /// Description : Convierte un arreglo de bytes BCD a Cadena
        /// </summary>
        /// <param name="b"></param>
        /// <returns></returns>
        public static String Bcd2Str(byte[] b)
        {
            if (b == null)
            {
                return "";
            }

            if (b.Length == 0)
            {
                return "";
            }

            return Bcd2str(b, 0, b.Length * 2, false);
        }

        // -*-*-*-*-*-*-*
        // Function Name: BUFFER_Mod10_Calculate
        //
        // Description  : Calculate the Mod10 for a buffer
        //
        // Parameters   : BYTE   *pBuffer,     Pointer to buffer
        //                size_t LenBuffer,    Length of buffer
        //
        // Return       : BYTE, Mod10
        //
        // Example      : None
        //
        // Notes        : None
        // -*-*-*-*-*-*-*
        public static int Mod10_Calculate(String pBuffer, int LenBuffer)
        {
            int i;
            int Factor = 2;
            int Result = 0;
            int SubResult;


            char[] cBuffer = pBuffer.ToCharArray();

            for (i = LenBuffer; i > 0; i--)
            {
                if (cBuffer[i - 1] <= '9')
                {
                    SubResult = ((pBuffer[i - 1]) & 0x0F) * Factor;
                }
                else
                {
                    SubResult = (((pBuffer[i - 1]) + 2) % 10) * Factor;
                }

                Result += ((SubResult / 10) + (SubResult % 10));

                Factor = ((2 == Factor) ? 1 : 2);
            }

            return (0x30 | ((0 != (Result % 10)) ? 10 - (Result % 10) : 0));
        }

        /*
        public static bool Mod10Check(string creditCardNumber, ref int checkDigit)
        {
            //// check whether input string is null or empty
            if (string.IsNullOrEmpty(creditCardNumber))
            {
                return false;
            }

            //// 1.	Starting with the check digit double the value of every other digit 
            //// 2.	If doubling of a number results in a two digits number, add up
            ///   the digits to get a single digit number. This will results in eight single digit numbers                    
            //// 3. Get the sum of the digits
            int sumOfDigits = creditCardNumber.Where((e) => e >= '0' && e <= '9')
                            .Reverse()
                            .Select((e, i) => ((int)e - 48) * (i % 2 == 0 ? 1 : 2))
                            .Sum((e) => e / 10 + e % 10);


            //// If the final sum is divisible by 10, then the credit card number
            //   is valid. If it is not divisible by 10, the number is invalid.            

            checkDigit = sumOfDigits;

            return sumOfDigits % 10 == 0;
        }
        */





        /// <summary>
        /// 
        /// Function    : RLE_decode
        /// 
        /// Description : Implementación de Decodificación RLE 
        /// 
        /// </summary>
        public static byte[] RLE_decode(byte[] input)
        {
            byte[] decodeData = null;

            if (null == input)
            {
                return null;
            }

            for (int i = 0; i < input.Length; i += 2)
            {

                byte toRepeat = input[i];
                byte byteData = input[i + 1];

                byte[] repeatedData = new byte[toRepeat];

                for (int k = 0; k < toRepeat; k++)
                {
                    repeatedData[k] = byteData;
                }


                decodeData = ConcatVar(decodeData, repeatedData);
            }


            return decodeData;
        }

        /// <summary>
        /// Converts a HexString to int 
        /// 
        /// Example> 
        /// 
        /// Array [0] = 0x00
        /// Array [1] = 0x0A
        /// 
        /// Result -> 10 
        /// 
        /// 
        /// </summary>
        /// <param name="hexData"></param>
        /// <returns></returns>
        public static int HexStringToInt32(byte[] hexData)
        {

            byte[] temp = hexData;

            if (hexData.Length == 3)
            {
                temp = new byte[] { 0x00, hexData[0], hexData[1], hexData[2] };
            }

            if (hexData.Length == 2)
            {
                temp = new byte[] { 0x00, 0x00, hexData[0], hexData[1] };
            }

            if (hexData.Length == 1)
            {
                temp = new byte[] { 0x00, 0x00, 0x00, hexData[0] };
            }


            if (BitConverter.IsLittleEndian)
            {
                Array.Reverse(temp); //need the bytes in the reverse order
            }

            return BitConverter.ToInt32(temp, 0);
        }

        /// <summary>
        /// Function    : HexDump
        /// Description : Retorna una cadena formateada en columnas
        /// </summary>
        /// <param name="bytes"></param>
        /// <param name="bytesPerLine"></param>
        /// <returns></returns>
        public static string HexDump(byte[] bytes, int bytesPerLine = 16)
        {
            if (bytes == null) return "<null>";
            int bytesLength = bytes.Length;

            char[] HexChars = "0123456789ABCDEF".ToCharArray();

            int firstHexColumn =
                  8                   // 8 characters for the address
                + 3;                  // 3 spaces

            int firstCharColumn = firstHexColumn
                + bytesPerLine * 3       // - 2 digit for the hexadecimal value and 1 space
                + (bytesPerLine - 1) / 8 // - 1 extra space every 8 characters from the 9th
                + 2;                  // 2 spaces 

            int lineLength = firstCharColumn
                + bytesPerLine           // - characters to show the ascii value
                + Environment.NewLine.Length; // Carriage return and line feed (should normally be 2)

            char[] line = (new String(' ', lineLength - Environment.NewLine.Length) + Environment.NewLine).ToCharArray();
            int expectedLines = (bytesLength + bytesPerLine - 1) / bytesPerLine;
            StringBuilder result = new StringBuilder(expectedLines * lineLength);

            for (int i = 0; i < bytesLength; i += bytesPerLine)
            {
                line[0] = HexChars[(i >> 28) & 0xF];
                line[1] = HexChars[(i >> 24) & 0xF];
                line[2] = HexChars[(i >> 20) & 0xF];
                line[3] = HexChars[(i >> 16) & 0xF];
                line[4] = HexChars[(i >> 12) & 0xF];
                line[5] = HexChars[(i >> 8) & 0xF];
                line[6] = HexChars[(i >> 4) & 0xF];
                line[7] = HexChars[(i >> 0) & 0xF];

                int hexColumn = firstHexColumn;
                int charColumn = firstCharColumn;

                for (int j = 0; j < bytesPerLine; j++)
                {
                    if (j > 0 && (j & 7) == 0) hexColumn++;
                    if (i + j >= bytesLength)
                    {
                        line[hexColumn] = ' ';
                        line[hexColumn + 1] = ' ';
                        line[charColumn] = ' ';
                    }
                    else
                    {
                        byte b = bytes[i + j];
                        line[hexColumn] = HexChars[(b >> 4) & 0xF];
                        line[hexColumn + 1] = HexChars[b & 0xF];
                        line[charColumn] = (b < 32 ? '·' : (char)b);
                    }
                    hexColumn += 3;
                    charColumn++;
                }
                result.Append(line);
            }
            return result.ToString();
        }

        /// <summary>
        /// Function    : CalcLenDecBCD2
        /// Description : Calcula la longitud y la retorna en formato BCD
        /// 
        /// </summary>
        /// <param name="datain"></param>
        /// <returns></returns>
        public static byte[] CalcLenDecBCD2(byte[] datain)
        {
            String str4len = Utilidad.FillStringWith(datain.Length.ToString(), '0', 4, true);
            //byte[] bcd2len = Utilidad.str2bcd(str4len, true);
            byte[] bcd2len = Utilidad.ASCII_To_BCD(ASCIIEncoding.ASCII.GetBytes(str4len));
            return bcd2len;
        }

  
        public static byte[] CalculateLCR(byte[] bytes)
        {
            byte LRC = 0;
            for (int i = 0; i < bytes.Length; i++)
            {
                LRC ^= bytes[i];
            }
            return new byte[] { LRC };

        }

    }

}
