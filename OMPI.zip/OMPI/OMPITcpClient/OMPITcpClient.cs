﻿#define NET4_6_2
#undef NET4_0

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.Net.Security;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;

namespace OMPITcpClient
{

    public abstract class Tcp_ClientBase
    {
        public enum MessageFormats
        {
            Raw = 0,
            AddTotalLength = 1,
            AddMessageLength = 2,
            AddSTX_ETX = 3,
            AddTotalLength_ETX = 4,
            AddMessageLength_ETX = 5,
        }

        private const byte STX = 0x02;
        private const byte ETX = 0x03;

        private const int MAX_MESSAGE_SIZE = 99999;
        private const int MAX_PACKET_SIZE = 10000;
        private const int SINGLE_OP_TIMEOUT = 10000;

        protected const string LOCALHOST = "127.0.0.1";
        protected const int DEFAULT_PORT = 2000;
        protected const string TIMEOUT_WHILE_RECEIVING = "TIMEOUT_WHILE_RECEIVING";
        protected const string ERROR_WHILE_SENDING = "TIMEOUT_WHILE_RECEIVING";

        #region --- Fields data types ---
        protected string _hostName;
        protected int _hostPort;
        protected bool _connected = false;
        #endregion

        #region --- Acessors / Mutators
        public string HostName
        {
            get
            {
                return (_hostName);
            }
        }
        public int HostPort
        {
            get
            {
                return (_hostPort);
            }
        }

        public bool Connected
        {
            get
            {
                return (_connected);
            }
        }

        #endregion


        public abstract void OpenConnection();
        public abstract void CloseConnection();

        protected abstract bool SocketReady();

        protected abstract void Write(byte[] buffer);
        protected abstract int Read(byte[] buffer, int trxTimeout);
        protected abstract int Read(byte[] buffer, int bytesToRead, int trxTimeout);


        public static Tcp_ClientBase GetTcpClient(string host, int port, bool secureEnabled, string certificateName)
        {
            if (secureEnabled)
                return new TCP_SecureClient(host, port, certificateName);
            else
                return new TCP_Client(host, port);
        }

        protected static IPAddress getIPAddress(string remoteServer)
        {
            IPAddress result = null;

            string validIpAddressRegex = @"^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$";

            if (Regex.IsMatch(remoteServer, validIpAddressRegex))
                result = IPAddress.Parse(remoteServer);
            else
            {
                IPHostEntry ipHostInfo = Dns.GetHostEntry(remoteServer); //Remote Host
                foreach (IPAddress ip in ipHostInfo.AddressList)
                {
                    //Transakcio only supports IPv4 connections
                    if (ip.AddressFamily == AddressFamily.InterNetwork) // IPV4
                    {
                        result = ip;
                        break;
                    }
                }
            }

            return result;
        }


        public void Send(byte[] message, MessageFormats msgFormat)
        {
            int msgLen;
            char[] DataLen = new char[2];

            byte[] newMessage = null;

            switch (msgFormat)
            {
                case MessageFormats.AddTotalLength:
                case MessageFormats.AddMessageLength:
                    newMessage = new byte[message.Length + 2];

                    if (msgFormat == MessageFormats.AddTotalLength)
                        msgLen = message.Length + 2;
                    else
                        msgLen = message.Length;

                    newMessage[0] = (byte)(msgLen / 256);
                    newMessage[1] = (byte)(msgLen % 256);

                    Buffer.BlockCopy(message, 0, newMessage, 2, message.Length);

                    break;
                case MessageFormats.AddTotalLength_ETX:
                case MessageFormats.AddMessageLength_ETX:
                    newMessage = new byte[message.Length + 3];

                    if (msgFormat == MessageFormats.AddTotalLength)
                        msgLen = message.Length + 3;
                    else
                        msgLen = message.Length + 1;

                    newMessage[0] = (byte)(msgLen / 256);
                    newMessage[1] = (byte)(msgLen % 256);
                    Buffer.BlockCopy(message, 0, newMessage, 2, message.Length);
                    newMessage[newMessage.Length - 1] = 0x03;
                    break;
                case MessageFormats.AddSTX_ETX:
                    newMessage = new byte[message.Length + 2];

                    newMessage[0] = 0x02;
                    Buffer.BlockCopy(message, 0, newMessage, 1, message.Length);
                    newMessage[newMessage.Length - 1] = 0x03;

                    break;
                case MessageFormats.Raw:
                    newMessage = new byte[message.Length];
                    Buffer.BlockCopy(message, 0, newMessage, 0, message.Length);
                    break;
                default:
                    throw new Exception(string.Format("Unexpected message format '{0}'", msgFormat));
            }

            if (SocketReady())
                Write(newMessage);
        }



        private byte[] receiveWithLength(MessageFormats msgFormat, int TrxTimeout)
        {
            DateTime startTime = DateTime.UtcNow;
            byte[] msgLen = new byte[2];
            byte[] rcvBuffer = new byte[MAX_PACKET_SIZE];
            byte[] result = null;

#if DEMOTPV

            int totalBytesRcvd = 0;
            int bytesRcvd = Read(rcvBuffer, 4, TrxTimeout);

            if (bytesRcvd == 4)
            {
                int expectedMsgLen = rcvBuffer[0] * (256 * 256 * 256) + rcvBuffer[1] * (256 * 256) + rcvBuffer[2] * 256 + rcvBuffer[3];
#else

            int totalBytesRcvd = 0;
            int bytesRcvd = Read(rcvBuffer, 1, TrxTimeout);

            if (bytesRcvd == 1)
            {
                msgLen[0] = rcvBuffer[0];
                bytesRcvd += Read(rcvBuffer, 1, TrxTimeout);
            }

            if (bytesRcvd == 2)
            {
                msgLen[1] = rcvBuffer[0];
                int expectedMsgLen = msgLen[0] * 256 + msgLen[1];
#endif
                if (msgFormat == MessageFormats.AddTotalLength)
                    expectedMsgLen -= 2;

                result = new byte[expectedMsgLen];

                while (totalBytesRcvd < expectedMsgLen)
                {
                    int elapsedMillis = (int)DateTime.UtcNow.Subtract(startTime).TotalMilliseconds;

                    if (elapsedMillis > TrxTimeout)
                        throw new Exception("Timeout exceeded");

                    bytesRcvd = Read(rcvBuffer, MAX_PACKET_SIZE, SINGLE_OP_TIMEOUT);

                    if (totalBytesRcvd + bytesRcvd > expectedMsgLen)
                        throw new Exception("Message is larger than expected");

                    Buffer.BlockCopy(rcvBuffer, 0, result, totalBytesRcvd, bytesRcvd);
                    totalBytesRcvd += bytesRcvd;
                }

            }

            return result;
        }

        private byte[] receiveWithLengthAndETX(MessageFormats msgFormat, int TrxTimeout)
        {
            DateTime startTime = DateTime.UtcNow;
            byte[] rcvBuffer = new byte[MAX_PACKET_SIZE];
            byte[] result = null;

            int totalBytesRcvd = 0;
            int bytesRcvd = Read(rcvBuffer, 2, TrxTimeout);

            if (bytesRcvd == 2)
            {
                int expectedMsgLen = rcvBuffer[0] * 256 + rcvBuffer[1];

                if (msgFormat == MessageFormats.AddTotalLength)
                    expectedMsgLen -= 2;

                result = new byte[expectedMsgLen - 1];

                while (totalBytesRcvd < expectedMsgLen)
                {
                    int elapsedMillis = (int)DateTime.UtcNow.Subtract(startTime).TotalMilliseconds;

                    if (elapsedMillis > TrxTimeout)
                        throw new Exception("Timeout exceeded");

                    bytesRcvd = Read(rcvBuffer, MAX_PACKET_SIZE, SINGLE_OP_TIMEOUT);

                    if (totalBytesRcvd + bytesRcvd > expectedMsgLen)
                        throw new Exception("Message is larger than expected");

                    if ((totalBytesRcvd + bytesRcvd) == expectedMsgLen)
                    {
                        if (rcvBuffer[bytesRcvd - 1] != ETX)
                            throw new Exception("Last byte in message is not ETX");

                        Buffer.BlockCopy(rcvBuffer, 0, result, totalBytesRcvd, bytesRcvd - 1);
                    }
                    else
                        Buffer.BlockCopy(rcvBuffer, 0, result, totalBytesRcvd, bytesRcvd);

                    totalBytesRcvd += bytesRcvd;
                }


            }

            return result;
        }

        private byte[] receiveWithSTXAndETX(MessageFormats msgFormat, int TrxTimeout)
        {
            DateTime startTime = DateTime.UtcNow;
            byte[] rcvBuffer = new byte[MAX_PACKET_SIZE];
            byte[] aux = null;
            byte[] result = null;

            int totalBytesRcvd = 0;
            int bytesRcvd = Read(rcvBuffer, 1, TrxTimeout);

            if (bytesRcvd == 1)
            {
                if (rcvBuffer[0] != STX)
                    throw new Exception("First byte int message is not STX");

                aux = new byte[MAX_MESSAGE_SIZE];

                do
                {
                    int elapsedMillis = (int)DateTime.UtcNow.Subtract(startTime).TotalMilliseconds;

                    if (elapsedMillis > TrxTimeout)
                        throw new Exception("Timeout exceeded");

                    bytesRcvd = Read(rcvBuffer, MAX_PACKET_SIZE, SINGLE_OP_TIMEOUT);

                    if (totalBytesRcvd + bytesRcvd > MAX_MESSAGE_SIZE)
                        throw new Exception("Message is larger than expected");

                    Buffer.BlockCopy(rcvBuffer, 0, aux, totalBytesRcvd, bytesRcvd);
                    totalBytesRcvd += bytesRcvd;
                }
                while (aux[totalBytesRcvd - 1] != ETX);

                result = new byte[totalBytesRcvd - 1];
                Buffer.BlockCopy(aux, 0, result, 0, totalBytesRcvd - 1);
            }

            return result;
        }


        private byte[] receiveRaw(MessageFormats msgFormat, int TrxTimeout)
        {
            DateTime startTime = DateTime.UtcNow;
            byte[] rcvBuffer = new byte[MAX_PACKET_SIZE];
            byte[] result = null;

            int bytesRcvd = Read(rcvBuffer, TrxTimeout);

            result = new byte[bytesRcvd];
            Buffer.BlockCopy(rcvBuffer, 0, result, 0, bytesRcvd);

            return result;
        }



        public virtual byte[] Receive(int TrxTimeout, MessageFormats msgFormat)
        {
            byte[] rcvBuffer = new byte[MAX_PACKET_SIZE];
            byte[] result = null;


            if (SocketReady())
            {
                rcvBuffer.Initialize();

                switch (msgFormat)
                {
                    case MessageFormats.AddTotalLength:
                    case MessageFormats.AddMessageLength:
                        result = receiveWithLength(msgFormat, TrxTimeout);
                        break;
                    case MessageFormats.AddTotalLength_ETX:
                    case MessageFormats.AddMessageLength_ETX:
                        result = receiveWithLengthAndETX(msgFormat, TrxTimeout);
                        break;
                    case MessageFormats.AddSTX_ETX:
                        result = receiveWithSTXAndETX(msgFormat, TrxTimeout);
                        break;
                    case MessageFormats.Raw:
                        result = receiveRaw(msgFormat, TrxTimeout);
                        break;
                    default:
                        throw new Exception(string.Format("Unexpected message format '{0}'", msgFormat));
                }

            }

            return result;
        }

    }

    public class TCP_Client : Tcp_ClientBase
    {

        private Socket _sendSocket = null;

        public TCP_Client(string RemoteServer, int RemotePort)
        {
            _hostName = RemoteServer;
            _hostPort = RemotePort;
        }

        public Socket WorkSocket { get { return _sendSocket; } }

        public override void OpenConnection()
        {
            int retriesCounter = 0;

            _connected = false;

            _sendSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

            IPAddress ipAddress = getIPAddress(_hostName);
            IPEndPoint commEndPoint = new IPEndPoint(ipAddress, _hostPort);


            while (true)
            {
                try
                {
                    _sendSocket.Connect(commEndPoint);
                    _connected = true;
                    break;
                }
                catch (SocketException)
                {
                    Thread.Sleep(500); //Wait 500 milliseconds

                    retriesCounter++;
                    if (retriesCounter >= 5)
                        throw;
                }
            }
        }

        public override void CloseConnection()
        {
            if (_sendSocket != null)
            {
                // Release the socket.
                _sendSocket.Shutdown(SocketShutdown.Both);
                _sendSocket.Close();
            }

            _connected = false;
        }

        protected override bool SocketReady()
        {
            return (_sendSocket != null);
        }

        protected override void Write(byte[] buffer)
        {
            _sendSocket.Send(buffer, SocketFlags.None);
        }

        protected override int Read(byte[] buffer, int bytesToRead, int trxTimeout)
        {

            int bytesRcvd = 0;

            bool msgArriveOnTime = _sendSocket.Poll(trxTimeout * 1000, SelectMode.SelectRead);
            if (msgArriveOnTime)
            {
                if (bytesToRead == -1)
                    bytesToRead = _sendSocket.Available;

                bytesRcvd = _sendSocket.Receive(buffer, 0, bytesToRead, SocketFlags.None);

            }

            return bytesRcvd;
        }

        protected override int Read(byte[] buffer, int trxTimeout)
        {
            return Read(buffer, -1, trxTimeout);
        }

    }

    public class TCP_SecureClient : Tcp_ClientBase
    {
        public SslStream sslStream = null;
        private TcpClient client = null;
        string Certificate = "";


        public TCP_SecureClient(string RemoteServer, int RemotePort, string CertificateName)
        {
            _hostName = RemoteServer;
            _hostPort = RemotePort;
            Certificate = CertificateName;
        }

        public SslStream WorkSocket { get { return sslStream; } }

        public override void OpenConnection()
        {
            //#if (NET4_6_2)
            //                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            //#else
            //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;
            //#endif

            //#if DEBUG
            //            Console.WriteLine("ServicePointManager.SecurityProtocol {0}", ServicePointManager.SecurityProtocol);
            //#endif

            //            foreach (SecurityProtocolType protocol in SecurityProtocolType.GetValues(typeof(SecurityProtocolType)))
            //            {
            //#if DEBUG
            //                Console.WriteLine("ProtocolName {0} {1}", protocol, (int)protocol);
            //#endif
            //                switch (protocol)
            //                {
            //                    case SecurityProtocolType.Ssl3:
            //                    case SecurityProtocolType.Tls:
            //#if (NET4_6_2)
            //                    case SecurityProtocolType.Tls11:
            //#endif
            //                        break;
            //                    default:
            //                        ServicePointManager.SecurityProtocol |= protocol;
            //                        break;
            //                }
            //            }

            // machineName is the host running the server application.
            //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;
            client = new TcpClient(_hostName, _hostPort);

            // Create an SSL stream that will close the client's stream.
            sslStream = new SslStream(
                client.GetStream(),
                false,
                new RemoteCertificateValidationCallback(ValidateServerCertificate),
                null
                );

            sslStream.AuthenticateAsClient(Certificate);
        }

        public override void CloseConnection()
        {
            try
            {
                if (client != null && client.Connected)
                    client.Close();
            }
            catch
            {
            }
        }

        protected override bool SocketReady()
        {
            return (sslStream != null);
        }

        protected override void Write(byte[] buffer)
        {
            sslStream.Write(buffer);
            sslStream.Flush();
        }

        protected override int Read(byte[] buffer, int bytesToRead, int trxTimeout)
        {
            sslStream.ReadTimeout = trxTimeout;


            int bytesRcvd = sslStream.Read(buffer, 0, bytesToRead);

            return bytesRcvd;
        }

        protected override int Read(byte[] buffer, int trxTimeout)
        {
            return Read(buffer, buffer.Length, trxTimeout);
        }

        // The following method is invoked by the RemoteCertificateValidationDelegate.
        private bool ValidateServerCertificate(
              object sender,
              X509Certificate certificate,
              X509Chain chain,
              SslPolicyErrors sslPolicyErrors)
        {
            if (sslPolicyErrors == SslPolicyErrors.None)
                return true;

            // Do not allow this client to communicate with unauthenticated servers.
            //return false; //To avoid false returns when a certificate is nt signed (only for development)
            return true;
        }


    }

}
