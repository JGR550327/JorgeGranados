﻿using FieldDataClassLib;
using PinPadCommunicationEGlobal;
using System;
using System.Globalization;

namespace PinPadCommunication
{
    public enum CardReadMode
    {
        Unknown = 0,
        Swiped = 1,
        Inserted = 2,
        Manual = 3,
        Fallback = 4,
        Contactless = 5
    }

    [Serializable(), System.Runtime.InteropServices.GuidAttribute("7993424A-BBAC-4947-8FC3-802C53274183")]
    public class CardData
    {
        private CardReadMode readMode;
        private EntryCapability entryCapability;
        private string track1;
        private string track2;
        private string b2;
        private string b3;
        private string b4;
        private string field55;
        private string product;
        private TLVs tags;
        private Tokens tokens;
        private bool requiresSignature;

        // Calculated / secondary fields
        private string cardholderName;
        private string pan;
        private string expirationDate;
        private string serviceCode;
        private string cvv;
        private string cv2;
        private string aid;
        private string arqc;
        //private string tokenES;
        //private string tokenEW;
        private string cardSequenceNumber;
        private string datosEMV;



        public CardData(string readMode, string cardNumber, string track1, string track2, string cardholderName, string aid, string arqc, string product, string tokenEZ, string tokenEY, string tokenES, string cardSequenceNumber, string datosEMV)
        {

            this.readMode = readMode == "05" ? CardReadMode.Inserted : readMode == "90" ? CardReadMode.Swiped : readMode=="80"? CardReadMode.Fallback: CardReadMode.Unknown;
            
           
            this.entryCapability = EntryCapability.Unknown;
            if (this.readMode == CardReadMode.Inserted)
                this.entryCapability = EntryCapability.CanAcceptPIN;

            this.requiresSignature = true;
            this.pan = cardNumber;
            if (!string.IsNullOrWhiteSpace(track1))
            this.Track1 = track1;
            if(!string.IsNullOrWhiteSpace(track2))
               this.Track2 = track2;

            this.cardholderName = cardholderName;
            this.aid = aid;
            this.arqc = arqc;
            this.product = product;
            if (cardSequenceNumber != "")
                this.cardSequenceNumber = cardSequenceNumber;
            else
                cardSequenceNumber = null;
            this.datosEMV = PinPadCommunicationEGlobal.Converter.Converters.BcdToHex(datosEMV);
            tokens.EZ = tokenEZ;
            tokens.EY = tokenEY;
            tokens.ES = tokenES;

        }

        public CardData(string tokenES, string tokenEW)
        {

            this.readMode =  CardReadMode.Manual;
            tokens.EW = tokenEW;
            tokens.ES = tokenES;
            
        }


        public CardData(CardReadMode readMode, EntryCapability entryCapability)
        {
            this.readMode = readMode;
            this.entryCapability = entryCapability;
            this.requiresSignature = true;
        }

        public static CardData getTestCard(CardBrands cardBrand, CardReadMode readMode, EntryCapability entryCapability, bool isCipher)
        {

            if (readMode != CardReadMode.Inserted)
                throw new ArgumentException(string.Format("ReadMode {0} not supported", readMode));

            if (isCipher == true)
                throw new ArgumentException(string.Format("isCipher {0} not supported", isCipher));


            CardData result = new CardData(CardReadMode.Inserted, EntryCapability.CanAcceptPIN);


            //result.Track1 = "PRUEBAS OPTIMA            ";
            if (cardBrand == CardBrands.VisaMastercard)
            {
                //result.Track2 = "4555400100267783=16122010000060200000";
                result.product = "VISA CREDITO";
                //result.tags.t9F34 = "9F34031E0300";
            }
            else
            {
                result.Track2 = "341111599241000=161250111018823400000";
                result.product = "AMEX CREDITO";
                result.tags.t9F34 = "9F3403410302";
            }
            /*
            result.tags.t4F = "4F07A0000000031010";
            result.tags.t50 = "500B564953412044454249544F";
            result.tags.t5F2A = "5F2A020484";
            result.tags.t5F30 = "5F30020201";
            result.tags.t5F34 = "5F340101";
            result.tags.t82 = "82025C00";
            result.tags.t84 = "8407A0000000031010";
            result.tags.t8A = "8A00";
            result.tags.t95 = "95050000008000";
            result.tags.t99 = "9900";
            result.tags.t9A = "9A03081107";
            result.tags.t9B = "9B02E800";
            result.tags.t9C = "9C0100";
            result.tags.t9F02 = "9F0206000004500000";
            result.tags.t9F03 = "9F0306000000000000";
            result.tags.t9F09 = "9F0902008C";
            result.tags.t9F10 = "9F100706010A03A0A000";
            result.tags.t9F12 = "9F1200";
            result.tags.t9F1A = "9F1A020484";
            result.tags.t9F1E = "9F1E083330333538313238";
            result.tags.t9F26 = "9F2608A2BD8A5C3060270A";
            result.tags.t9F27 = "9F270180";
            result.tags.t9F33 = "9F3303E0B0C8";
            result.tags.t9F35 = "9F350122";
            result.tags.t9F36 = "9F360200F0";
            result.tags.t9F37 = "9F3704C0E2F428";
            result.tags.t9F39 = "9F390105";
            result.tags.t9F41 = "9F410400000381";
            result.tags.t9F53 = "9F530152";
            */
            result.aid = "A0000000031010";
            result.arqc = "BFC18F38C5E8E81E";
            result.cardholderName = "TDC PRUEBA ICR      ";
            result.cardSequenceNumber = "01";
            result.pan = "4912849524917118";

            result.tokens.EZ = "! EZ00098 0420000000053100016B00003620010537A0007427D0633863E06F495D68C47B88EAD48F5914DAA38FA82E7118043116F3";
            result.tokens.EY = "! EY00000 ";
            result.tokens.ES = "! ES00060 IG0320v06_10        IG00000000PP301974055        A4599932010";
            /*
            result.b2 = "! B200158 FFF90000800000008000A2BD8A5C3060270A0000045000000000000000005C0000F048448408110700C0E2F428000706010A03A0A00000000000000000000000000000000000000000000000000000";
            result.b3 = "! B300080 FF0030358128E0B0C80000000000000022008C1E03000007A0000000031010000000000000000000";
            result.b4 = "! B400020 052510011E030000000 ";
            */
            result.datosEMV = "C1C7D5E20001A2BD8A5C3060270A0706010A03A0A00000000000000000000000000000000000000000000000000000C0E2F42800F0000000800008110700000004500000048404845C000000000000000180";


            return result;
        }

        public static CardData FromPOSData(string track2, string posEntryMode)
        {
            string entryMode = posEntryMode.Substring(0, 2);
            char entryCap = posEntryMode[2];

            CardReadMode readMode;
            EntryCapability entryCapability;

            switch (entryMode)
            {
                case "01":
                    readMode = CardReadMode.Manual;
                    break;
                case "02":
                case "90":
                    readMode = CardReadMode.Swiped;
                    break;
                case "80":
                    readMode = CardReadMode.Fallback;
                    break;
                case "05":
                    readMode = CardReadMode.Inserted;
                    break;
                default:
                    throw new Exception(string.Format("Unexpected entry mode '{0}'", entryMode));
            }

            switch (entryCap)
            {
                case '0':
                    entryCapability = EntryCapability.Unknown;
                    break;
                case '1':
                    entryCapability = EntryCapability.CanAcceptPIN;
                    break;
                case '2':
                    entryCapability = EntryCapability.CannotAcceptPIN;
                    break;
                default:
                    throw new Exception(string.Format("Unexpected entry capability '{0}'", entryCap));
            }

            CardData result = new CardData(readMode, entryCapability);

            result.Track2 = track2;



            return result;
        }

        public static CardData getManualCard(string pan, int expirationYear, int expirationMonth, string cv2)
        {
            CardData result = new CardData(CardReadMode.Manual, EntryCapability.CanAcceptPIN);

            string expirationDate = (expirationYear % 100).ToString("D2", CultureInfo.InvariantCulture) + expirationMonth.ToString("D2", CultureInfo.InvariantCulture);

            result.pan = pan;
            result.expirationDate = expirationDate;
            result.track2 = pan + "=" + expirationDate;
            result.cv2 = cv2;

            return result;
        }

        public CardReadMode ReadMode { get { return readMode; } }
        public string Track1
        {
            get { return track1; }
            set
            {

                if (value == null)
                {
                    track1 = null;
                    cardholderName = null;
                }
                else
                {
                    track1 = value;
                    int startIndex = 0;
                    int endIndex;

                    if (value.StartsWith("%B"))
                        startIndex = 1;

                    if ((endIndex = value.LastIndexOf('?')) > -1)
                        track1 = value.Substring(startIndex, endIndex - startIndex);
                    else
                        track1 = value.Substring(startIndex);

                    if ((readMode == CardReadMode.Swiped) || (readMode == CardReadMode.Fallback))
                    {
                        char sep = '^';
                        startIndex = track1.IndexOf(sep);

                        if (startIndex > -1)
                        {
                            endIndex = track1.IndexOf(sep, startIndex + 1);

                            if (endIndex > -1)
                                cardholderName = track1.Substring(startIndex + 1, endIndex - startIndex - 1).Trim();
                        }
                    }
                    else if (readMode == CardReadMode.Inserted)
                        cardholderName = track1.Trim();
                }
            }
        }

        private string translateTrack2(string readTrack2)
        {
            string result = null;

            int separatorPos;
            int finalPos;

            if (readTrack2.StartsWith(";"))
                readTrack2 = readTrack2.Substring(1);

            if ((separatorPos = readTrack2.IndexOf('D')) > -1)
            {
                result = readTrack2.Substring(0, separatorPos) + "=" + readTrack2.Substring(separatorPos + 1);
                if ((finalPos = result.IndexOf('F')) > -1)
                    result = result.Substring(0, finalPos);
            }

            if ((separatorPos = readTrack2.IndexOf('=')) > -1) // ISO-IEC 7813
            {
                int startIndex = 0;

                if (readTrack2[0] == ';')
                    startIndex = 1;

                if ((finalPos = readTrack2.IndexOf('?')) > -1)
                    result = readTrack2.Substring(startIndex, finalPos - startIndex);
                else
                    result = readTrack2.Substring(startIndex);
            }

            return result;
        }

        public string Track2
        {
            get { return track2; }
            set
            {
                int separatorPos;

                //Console.WriteLine("SETTING Track2 [{0}]", value);
                if (string.IsNullOrWhiteSpace(value))
                {
                    track2 = null;
                    pan = null;
                    serviceCode = null;
                    cvv = null;
                }
                else
                {
                    // ALWAYS set Track2 in magnetic stripe format (=, ?)
                    track2 = translateTrack2(value);

                    if ((separatorPos = track2.IndexOf('=')) > -1)
                    {
                        pan = track2.Substring(0, separatorPos);
                        if (track2.Length > separatorPos + 4)
                        {
                            expirationDate = track2.Substring(separatorPos + 1, 4);

                            if (track2.Length > separatorPos + 7)
                            {
                                serviceCode = track2.Substring(separatorPos + 5, 3);

                                if (track2.Length > separatorPos + 16)
                                    cvv = track2.Substring(separatorPos + 13, 3);
                            }
                        }
                    }
                }
            }
        }

        public string SafeTrack2
        {
            get
            {
                string result = null;

                if (pan != null)
                {
                    result = pan + "=";

                    if (expirationDate != null)
                        result += expirationDate;

                    if (serviceCode != null)
                        result += serviceCode;
                }

                return result;
            }
        }

        public bool HasChip
        {
            get
            {
                if (serviceCode != null)
                    return ((serviceCode[0] == '2') || (serviceCode[1] == '6'));
                else
                    return true;
            }
        }

        public string EntryMode
        {
            get
            {
                string result = null;

                switch (readMode)
                {
                    case CardReadMode.Manual:
                        result = "01";
                        break;
                    case CardReadMode.Swiped:
                        //if (HasChip)
                        //    result = "80";
                        //else
                            result = "90";
                        break;
                    case CardReadMode.Fallback:
                        result = "80";
                        break;
                    case CardReadMode.Inserted:
                        result = "05";
                        break;
                }

                switch (entryCapability)
                {
                    case EntryCapability.Unknown:
                        result += "0";
                        break;
                    case EntryCapability.CanAcceptPIN:
                        result += "1";
                        break;
                    case EntryCapability.CannotAcceptPIN:
                        result += "2";
                        break;
                }

                return result;
            }

        }

        public string CardSequenceNume { get { return cardSequenceNumber; } }
        public string ICCData { get { return datosEMV; } }
        public string CardholderName { get { return cardholderName; } }
        public string PAN { get { return pan; } set { pan = value; } }
        public string ExpirationDate { get { return expirationDate; } }
        public string ServiceCode { get { return serviceCode; } }
        public string CV2 { get { return cv2; } set { cv2 = value; } }
        public string AID { get { return aid; } }
        public string ARQC { get { return aid; } }

        public string B2 { get { return b2; } set { b2 = value; } }
        public string B3 { get { return b3; } set { b3 = value; } }
        public string B4 { get { return b4; } set { b4 = value; } }
        public string Field55 { get { return field55; } set { field55 = value; } }
        public string Product { get { return product; } set { product = value; } }
        public TLVs Tags { get { return tags; } set { tags = value; } }
        public Tokens Tokens { get { return tokens; } set { tokens = value; } }
        public bool RequiresSignature { get { return requiresSignature; } set { requiresSignature = value; } }

        public string GetValue(string dataKey, bool throwIfNotFound)
        {
            string result = null;

            switch (dataKey.ToUpper())
            {
                case "TRACK1":
                    result = track1;
                    break;
                case "TRACK2":
                    result = track2;
                    break;
                case "SAFETRACK2":
                    result = SafeTrack2;
                    break;
                case "FIELD55":
                    result = field55;
                    break;
                case "B2":
                    result = b2;
                    break;
                case "B3":
                    result = b3;
                    break;
                case "B4":
                    result = b4;
                    break;
                case "ER":
                    result = tokens.ER;
                    break;
                case "ES":
                    result = tokens.ES;
                    break;
                case "ET":
                    result = tokens.ET;
                    break;
                case "EW":
                    result = tokens.EW;
                    break;
                case "EX":
                    result = tokens.EX;
                    break;
                case "EY":
                    result = tokens.EY;
                    break;
                case "EZ":
                    result = tokens.EZ;
                    break;
                case "R1":
                    result = tokens.R1;
                    break;
                case "CARDHOLDER_NAME":
                    result = cardholderName;
                    break;
                case "EXPIRATION_DATE":
                    result = expirationDate;
                    break;
                case "PAN":
                    result = pan;
                    break;
                case "SERVICE_CODE":
                    result = serviceCode;
                    break;
                case "CVV":
                    result = cvv;
                    break;
                case "CV2":
                    result = cv2;
                    break;
                case "ENTRY_MODE":
                    result = EntryMode;
                    break;
                case "PRODUCT":
                    result = product;
                    break;
                case "REQUIRESSIGNATURE":
                    result = (requiresSignature ? "true" : "false");
                    break;
                case "EMVXML":
                    result = ComputeEmvXml();
                    break;
                case "ARQC":
                    result = arqc;
                    break;
                case "AID":
                    result = aid;
                    break;
                case "CARDSEQUENCENUMBER":
                    result = cardSequenceNumber;
                    break;
                case "ICCDATA":
                    result = ICCData;
                    break;
                default:
                    if (throwIfNotFound)
                        throw new Exception(string.Format("Unrecognized card data '{0}'", dataKey));
                    break;
            }


            return result;
        }

        public string ComputeEmvXml()
        {
            string ret = "";

            if (readMode == CardReadMode.Inserted)
            {
                XmlField xmlField = new XmlField();

                if (tags.t9F34 != null)
                {
                    xmlField.SetValue("EmvData/CVMResults", tags.t9F34.Substring(6));
                    return xmlField.ToXmlString();
                }
                else
                    return ret;

            }

            return null;
        }

        private string parseTag(string tag, string rawValue)
        {
            if (tag == null)
                throw new ArgumentException("Tag cannot be null");

            if (rawValue == null)
                throw new ArgumentException("Raw value cannot be null");

            if (!rawValue.StartsWith(tag))
                throw new ArgumentException("Raw value does not match requested tag");

            if (rawValue.Length < (tag.Length + 2))
                throw new ArgumentException("Incomplete raw value");

            int valueLength = 2 * Int32.Parse(rawValue.Substring(tag.Length, 2), NumberStyles.AllowHexSpecifier);

            if (rawValue.Length < (tag.Length + 2 + valueLength))
                throw new ArgumentException("Incomplete raw value");

            return rawValue.Substring(tag.Length + 2);
        }

        public string GetTagValue(string tag, bool raw, bool throwIfNotFound)
        {

            string aux = null;
            string result = null;

            switch (tag.ToUpper())
            {
                case "4F":
                    aux = tags.t4F;
                    break;
                case "9F12":
                    aux = tags.t9F12;
                    break;
                case "50":
                    aux = tags.t50;
                    break;
                case "5F30":
                    aux = tags.t5F30;
                    break;
                case "5F34":
                    aux = tags.t5F34;
                    break;
                case "9F34":
                    aux = tags.t9F34;
                    break;
                case "C2":
                    aux = tags.tC2;
                    break;
                case "95":
                    aux = tags.t95;
                    break;
                case "9F27":
                    aux = tags.t9F27;
                    break;
                case "9F26":
                    aux = tags.t9F26;
                    break;
                case "9B":
                    aux = tags.t9B;
                    break;
                case "9F39":
                    aux = tags.t9F39;
                    break;
                case "8A":
                    aux = tags.t8A;
                    break;
                case "99":
                    aux = tags.t99;
                    break;
                case "5F2A":
                    aux = tags.t5F2A;
                    break;
                case "82":
                    aux = tags.t82;
                    break;
                case "84":
                    aux = tags.t84;
                    break;
                case "9A":
                    aux = tags.t9A;
                    break;
                case "9C":
                    aux = tags.t9C;
                    break;
                case "9F02":
                    aux = tags.t9F02;
                    break;
                case "9F03":
                    aux = tags.t9F03;
                    break;
                case "9F09":
                    aux = tags.t9F09;
                    break;
                case "9F10":
                    aux = tags.t9F10;
                    break;
                case "9F1A":
                    aux = tags.t9F1A;
                    break;
                case "9F1E":
                    aux = tags.t9F1E;
                    break;
                case "9F33":
                    aux = tags.t9F33;
                    break;
                case "9F35":
                    aux = tags.t9F35;
                    break;
                case "9F36":
                    aux = tags.t9F36;
                    break;
                case "9F37":
                    aux = tags.t9F37;
                    break;
                case "9F41":
                    aux = tags.t9F41;
                    break;
                case "9F53":
                    aux = tags.t9F53;
                    break;

                default:
                    if (throwIfNotFound)
                        throw new Exception(string.Format("Unrecognized tag in card data '{0}'", tag));
                    break;
            }

            if (raw)
                result = aux;
            else
                result = parseTag(tag, aux);

            return result;

        }

        public string GetTokenValue(string tokenKey, bool throwIfNotFound)
        {
            string result = null;

            switch (tokenKey.ToUpper())
            {
                case "ER":
                    result = tokens.ER;
                    break;
                case "ES":
                    result = tokens.ES;
                    break;
                case "ET":
                    result = tokens.ET;
                    break;
                case "EW":
                    result = tokens.EW;
                    break;
                case "EX":
                    result = tokens.EX;
                    break;
                case "EY":
                    result = tokens.EY;
                    break;
                case "EZ":
                    result = tokens.EZ;
                    break;
                case "R1":
                    result = tokens.R1;
                    break;
                default:
                    if (throwIfNotFound)
                        throw new Exception(string.Format("Unrecognized token in card data '{0}'", tokenKey));
                    break;
            }

            return result;
        }
    }


}
