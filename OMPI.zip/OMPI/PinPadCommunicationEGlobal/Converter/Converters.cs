﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace PinPadCommunicationEGlobal.Converter
{
    public class Converters
    {

        private const string ENCODING_NAME = "iso-8859-1";

        public static string BcdToHex(string src)
        {
            byte[] aux = Encoding.GetEncoding(ENCODING_NAME).GetBytes(src);

            StringBuilder sb = new StringBuilder(aux.Length * 2);

            for (int i = 0; i < aux.Length; i++)
                sb.AppendFormat("{0:X2}", aux[i]);

            return sb.ToString();
        }

        public static string HexToBcd(string src)
        {
            byte[] aux = new byte[src.Length / 2];

            for (int i = 0; i < aux.Length; i++)
                aux[i] = byte.Parse(src.Substring(2 * i, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture);

            return Encoding.GetEncoding(ENCODING_NAME).GetString(aux);
        }



    }
}
