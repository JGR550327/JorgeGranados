﻿
using EglobalBBVA;
using PinPadCommunication;
using System;
using System.Runtime.InteropServices;

namespace PinPadCommunicationEGlobal
{
    public enum CardBrands
    {
        Unknown = 0,
        VisaMastercard = 1,
        AmericanExpress = 2,
    }

    public enum PinPadVersions
    {
        V1_Regular = 1,
        V2_Cipher = 2,
        V3_CipherHotels = 3
    }

    public enum EntryCapability
    {
        Unknown = 0,
        CanAcceptPIN = 1,
        CannotAcceptPIN = 2
    }

    public class PinPadTrxProps
    {
        private CardBrands cardBrand;
        private bool isRefund;
        private bool manualEnabled;

        public PinPadTrxProps(CardBrands cardBrand, bool isRefund, bool manualEnabled)
        {
            this.cardBrand = cardBrand;
            this.isRefund = isRefund;
            this.manualEnabled = manualEnabled;
        }

        public CardBrands CardBrand { get { return this.cardBrand; } }
        public bool IsRefund { get { return this.isRefund; } }
        public bool ManualEnabled { get { return this.manualEnabled; } }
    }


    [StructLayout(LayoutKind.Sequential, Size = 6), Serializable]
    public struct PPDateTime
    {
        public byte year;
        public byte month;
        public byte day;
        public byte hours;
        public byte minutes;
        public byte seconds;
    }

    [StructLayout(LayoutKind.Sequential, Size = 256, CharSet = CharSet.Ansi), Serializable]
    public struct CardInformation
    {
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 20)]
        public string Pan;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 27)]
        public string CardholderName;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 38)]
        public string Track2;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 80)]
        public string Track1;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 5)]
        public string CVV;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 3)]
        public string POSEntryMode;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 17)]
        public string Product;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 66)]
        public string dummy;
    }

    [StructLayout(LayoutKind.Sequential, Size = 640, CharSet = CharSet.Ansi), Serializable]
    public struct TLVs
    {
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 37)]
        public string t4F;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 39)]
        public string t9F12;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 37)]
        public string t50;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 11)]
        public string t5F30;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 9)]
        public string t5F34;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 13)]
        public string t9F34;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 7)]
        public string tC2;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 15)]
        public string t95;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 9)]
        public string t9F27;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 23)]
        public string t9F26;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 9)]
        public string t9B;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 9)]
        public string t9F39;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 9)]
        public string t8A;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 21)]
        public string t99;

        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 11)]
        public string t5F2A;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 9)]
        public string t82;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 37)]
        public string t84;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 11)]
        public string t9A;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 7)]
        public string t9C;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 19)]
        public string t9F02;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 19)]
        public string t9F03;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 11)]
        public string t9F09;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 71)]
        public string t9F10;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 11)]
        public string t9F1A;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 23)]
        public string t9F1E;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 13)]
        public string t9F33;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 9)]
        public string t9F35;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 11)]
        public string t9F36;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 15)]
        public string t9F37;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 23)]
        public string t9F41;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 9)]
        public string t9F53;

        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 59)]
        public string t5F20;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 43)]
        public string t57;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 25)]
        public string t5A;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 19)]
        public string t5F24;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 7)]
        public string tC2_1;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 7)]
        public string tC2_2;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 11)]
        public string t5F28;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 303)]
        public string dummy;
    }


    [StructLayout(LayoutKind.Sequential, Size = 2048, CharSet = CharSet.Ansi), Serializable]
    public struct Tokens
    {
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 13)]
        public string ER;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 71)]
        public string ES;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 377)]
        public string ET;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 549)]
        public string EW;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 79)]
        public string EX;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 183)]
        public string EY;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 109)]
        public string EZ;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 27)]
        public string R1;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 17)]
        public string Q6;
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 623)]
        public string dummy;
    }


    public class PinPad
    {
        PinPadSC Objeto;

        private string responseDescription;

        public string ResponseDescription
        {
            get { return responseDescription; }
            
        }

        private bool eSignature;

        public bool ESignature
        {
            get { return eSignature; }
            
        }


        private bool aSignatue;

        public bool ASignature
        {
            get { return aSignatue; }

        }

        //private string tokenES;
        //public string TokenES
        //{
        //    get { return tokenES; }
        //}

        //private string tokenEw;
        //public string TokenEW
        //{
        //    get { return tokenEw; }
        //}


        public PinPad()
        {
            Objeto = new PinPadSC();
            Objeto.SincronicacionInicial();
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="trxCode"></param>
        /// <param name="amount"></param>
        /// <param name="cashAount"></param>
        /// <param name="currencyType"></param>
        /// <param name="flag">1 Amex, 0 All other cards</param>
        /// <returns></returns>
        public int StartTransaction(string trxCode, string amount, string cashAmount, int currencyType, int flag, out CardData cardData)
        {
            cardData = null;
           

            string isoAmount = (Convert.ToDouble(amount)*100).ToString();
            Objeto.fnObtenerDatos(trxCode, isoAmount, cashAmount, currencyType, flag);

            if (Objeto.RespDLL == 0)
            {
                //string ES = Objeto.TokenES.Substring(0,51);                
                //ES+="A4599932";
                //ES+=Objeto.TokenES.Substring(59);
                
                cardData = new CardData(Objeto.ModoIngreso, Objeto.NumeroTarjeta, Objeto.Track1, Objeto.Track2, Objeto.NombreCliente, Objeto.AID, Objeto.Criptograma.Replace("ARQC: ", ""), Objeto.Emisor, Objeto.TokenEZ, Objeto.TokenEY, Objeto.TokenES, Objeto.CardSequenceNumber, Objeto.DatosEMV);
            }
            else if (Objeto.RespDLL == 62)
                cardData = new CardData(Objeto.TokenES, Objeto.TokenEW);
            responseDescription = Objeto.RespDllDescripcion;

            if (cardData!=null && cardData.EntryMode == "0")
            {
                Objeto.fnTerminaTNX("", "", "", "", "");
                responseDescription = "Operación no soportada";
                return 99;
            }

            eSignature = Objeto.FirmaElectronica;
            aSignatue = Objeto.FirmaAutografa;
            
            return Objeto.RespDLL;
        }

        public string GetReverseData() {
            return Objeto.EMVRecuperados;
        }


        public int EndKeyLoad(string TokenEX)
        {
            Objeto.fnCargadeLLave(TokenEX);
            Objeto.SincronicacionInicial();
            return Objeto.RespDLL;
        }

        public int  KeyRequest(out CardData cardData){
            Objeto.fnObtenerDatos("092", "0", "0", 0, 0);
            cardData = new CardData(Objeto.TokenES, Objeto.TokenEW);
            return Objeto.RespDLL;
        }

        public int EndTransaction(string EMVData, string ResponseCode, string authCode, string TokenER, string TokenET)
        {
            int result = -1;
            Objeto.fnTerminaTNX(EMVData, ResponseCode, authCode, TokenER, TokenET);
            responseDescription = Objeto.RespDllDescripcion;
            return result = Objeto.RespDLL;
        }

        public void LoadKeyAnotherIssuer()
        {
            Objeto.OtroEmisorLLave();
        }

        public void Telecarga(int indicator)
        {
            Objeto.Telecarga(indicator);
        }

    }
}
