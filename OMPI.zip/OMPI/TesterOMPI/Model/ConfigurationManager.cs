﻿using OMPI;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace TesterOMPI.Model
{
   public class ConfigurationManager
    {
        private  bool loadCfgVerificationKey(out RSACryptoServiceProvider rsaKey)
        {
            bool success = true;

            rsaKey = null;

            try
            {
                string keyData = null;

                using (Stream stream = this.GetType().Assembly.GetManifestResourceStream("TesterOMPI.Security.configurationKey.xml"))
                {
                    using (StreamReader sr = new StreamReader(stream))
                    {
                        keyData = sr.ReadToEnd();
                    }
                }

                if (keyData != null)
                {
                    rsaKey = new RSACryptoServiceProvider();
                    rsaKey.FromXmlString(keyData);
                }
            }
            catch
            {
                success = false;
            }


            return success;
        }


        public  Dictionary<string,MsgConfiguration> GetConfig(string filePath) {
            RSACryptoServiceProvider RSA;
            //Este método se encarga de validar la integridad del archivo de configuración
            var loadRSA = loadCfgVerificationKey(out RSA);
            //En caso de que sea correcta la verificación de la firma se procede a mandar a la OMPI el archivo con el que se va a cargar la configuración
            var ConfigDict = MessageBuilder.LoadConfiguration(filePath,RSA);
          return ConfigDict;
        }



    }
}
