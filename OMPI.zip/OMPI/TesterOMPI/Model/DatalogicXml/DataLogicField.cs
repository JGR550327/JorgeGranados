﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace TesterOMPI.Model.DatalogicXml
{
    public class DataLogicField : NoticationObject
    {
        public enum iTipoEnum
        {
            AN, NE, NM, FD, HR, ND, Undefined
        }

        private string sCampo;
        private iTipoEnum iTipo;
        private int iLongitud;
        private int iClase;
        private string sValor;
        private bool bEncriptado;

        public string SCampo { get { return sCampo; } set { sCampo = value; NotifyPropertyChanged("SCampo"); } }
        public iTipoEnum ITipo { get { return iTipo; } set { iTipo = value; NotifyPropertyChanged("ITipo"); } }
        public int ILongitud { get { return iLongitud; } set { iLongitud = value; NotifyPropertyChanged("ILongitud"); } }
        public int IClase { get { return iClase; } set { iClase = value; NotifyPropertyChanged("IClase"); } }
        public string SValor { get { return sValor; } set { sValor = value; NotifyPropertyChanged("SValor"); } }
        public bool BEncriptado { get { return bEncriptado; } set { bEncriptado = value; NotifyPropertyChanged("BEncriptado"); } }

        public DataLogicField(string sCampo, string iTipo, string iLongitud, string iClase, string sValor, string bEncriptado)
        {
            this.sCampo = sCampo;
            this.iTipo = iTipo == "AN" ? iTipoEnum.AN :
                iTipo == "NE" ? iTipoEnum.NE :
                iTipo == "NM" ? iTipoEnum.NM :
                iTipo == "FD" ? iTipoEnum.FD :
                iTipo == "HR" ? iTipoEnum.HR :
                iTipo == "ND" ? iTipoEnum.ND :
                iTipoEnum.Undefined;
            this.iLongitud = int.Parse(iLongitud);
            this.iClase = int.Parse(iClase);
            this.sValor = sValor;
            this.bEncriptado = bool.Parse(bEncriptado);
        }

        public static DataLogicField LoadFromXml(XmlNode node)
        {
            //DataLogicField result;
            string sCampo = "";
            string iTipo = "";
            string iLongitud = "";
            string iClase = "";
            string sValor = "";
            string bEncriptado = "";

            var current = node.FirstChild;

            while (current != null)
            {
                if (current.Name == "sCampo")
                    sCampo = current.InnerText;
                else if (current.Name == "iTipo")
                    iTipo = current.InnerText;
                else if (current.Name == "iLongitud")
                    iLongitud = current.InnerText;
                else if (current.Name == "iClase")
                    iClase = current.InnerText;
                else if (current.Name == "sValor")
                    sValor = current.InnerText;
                else if (current.Name == "bEncriptado")
                    bEncriptado = current.InnerText;
                else
                    throw new Exception(string.Format("Unexpected node name '{0}'", current.Name));
                current = current.NextSibling;
            }

            return new DataLogicField(sCampo, iTipo, iLongitud, iClase, sValor, bEncriptado);
        }

        public string GetXmlRepresentation()
        {

            StringBuilder xmlRep = new StringBuilder();
            xmlRep.Append(string.Format("<cCampo>"));
            xmlRep.Append(string.Format("    <sCampo xmlns=\"http://www.pagoexpress.com.mx/pxUniversal\">{0}</sCampo>                         ", sCampo));
            xmlRep.Append(string.Format("    <iTipo xmlns=\"http://www.pagoexpress.com.mx/pxUniversal\">{0}</iTipo>                           ", iTipo));
            xmlRep.Append(string.Format("    <iLongitud xmlns=\"http://www.pagoexpress.com.mx/pxUniversal\">{0}</iLongitud>                   ", iLongitud));
            xmlRep.Append(string.Format("    <iClase xmlns=\"http://www.pagoexpress.com.mx/pxUniversal\">{0}</iClase>                         ", iClase));
            xmlRep.Append(string.Format("    <sValor xsi:type=\"xsd:string\" xmlns=\"http://www.pagoexpress.com.mx/pxUniversal\">{0}</sValor> ", sValor));
            xmlRep.Append(string.Format("    <bEncriptado xmlns=\"http://www.pagoexpress.com.mx/pxUniversal\">{0}</bEncriptado>               ", bEncriptado));
            xmlRep.Append(string.Format("</cCampo>"));




            return xmlRep.ToString();
        }

    }
}
