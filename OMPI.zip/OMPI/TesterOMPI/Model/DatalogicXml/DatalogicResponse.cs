﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace TesterOMPI.Model.DatalogicXml
{
    public class DatalogicResponse
    {
        private ObservableCollection<DataLogicField> fields = new ObservableCollection<DataLogicField>();

        public ObservableCollection<DataLogicField> Fields
        { get { return fields; } }

        public DatalogicResponse(ObservableCollection<DataLogicField> fields)
        {
            this.fields = fields;
        }

        private string xmlRepresentation;

        public string XmlRepresentation
        {
            get {
                GetXmlRepresentation();
                return xmlRepresentation; }
            
        }

        public override string ToString()
        {
                return XmlRepresentation;
        }
        

        public static DatalogicResponse LoadFromXml(string data)
        {
            DatalogicResponse result;
            ObservableCollection<DataLogicField> fields = new ObservableCollection<DataLogicField>();

            XmlDocument doc = new XmlDocument();
            doc.LoadXml(data);
            XmlNode baseNode = doc.DocumentElement.GetElementsByTagName("ArrayOfCCampo").Item(0);


            while (baseNode!= null)
            {
                var current = baseNode.FirstChild;
                while (current != null)
                {
                    if (current.Name.Equals("cCampo", StringComparison.InvariantCultureIgnoreCase))
                    {
                        var field = DataLogicField.LoadFromXml(current);
                        fields.Add(field);
                    }
                    else
                        throw new Exception(string.Format("Unexpected node '{0}'", current.Name));

                    current = current.NextSibling;
                }
                baseNode = baseNode.NextSibling;
            }



            return result = new DatalogicResponse(fields);

        }

        private void GetXmlRepresentation() {
            StringBuilder xmlRep = new StringBuilder();
            
            xmlRep.Append("<ArrayOfCCampo xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">");

            foreach (var field in fields)
            {
                xmlRep.Append(field.GetXmlRepresentation());    
            }
            xmlRep.Append("</ArrayOfCCampo>");
            xmlRepresentation = xmlRep.ToString();
        }

    }
}
