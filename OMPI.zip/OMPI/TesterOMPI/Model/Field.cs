﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace TesterOMPI.Model
{
    public class Field : NoticationObject
    {
        private string key;

        public string Key
        {
            get { return key; }
            set { key = value; 
                NotifyPropertyChanged("Key"); }
        }

        private string _value;

        public string Value
        {
            get { return _value; }
            set { _value = value; NotifyPropertyChanged("Value"); }
        }



    }
}
