﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace TesterOMPI.Model.Moneygram
{
    public class MoneygramResponse
    {
        ObservableCollection<ProductFieldInfo> fields = new ObservableCollection<ProductFieldInfo>();
        public ObservableCollection<ProductFieldInfo> Fields
        { get { return fields; } }

        //private string doCheckIn;
        //private string timeStamp;
        //private string flags;
        //private string fqdoInfo;

        //public string DoCheckIn { get { return doCheckIn; } }
        //public string TimeStamp { get { return timeStamp; } }
        //public string Flags { get { return flags; } }
        //public string FqdoInfo { get { return fqdoInfo; } }

        public MoneygramResponse(ObservableCollection<ProductFieldInfo> fields)
        {
            this.fields = fields;
        }

        public static MoneygramResponse LoadFromXml(string data)
        {
            MoneygramResponse result;
            ObservableCollection<ProductFieldInfo> fields = new ObservableCollection<ProductFieldInfo>();

            XmlDocument doc = new XmlDocument();
            doc.LoadXml(data);
            XmlNode baseNode = doc.DocumentElement;

            while (baseNode != null)
            {

                var current = baseNode.FirstChild;
                while (current != null)
                {
                    string doCheckIn;
                    string timeStamp;
                    string flags;
                    string fqdoInfo;

                    if (current.Name.Equals("doCheckIn", StringComparison.InvariantCultureIgnoreCase)) doCheckIn = current.InnerText;
                    else if (current.Name.Equals("timeStamp", StringComparison.InvariantCultureIgnoreCase)) timeStamp = current.InnerText;
                    else if (current.Name.Equals("flags", StringComparison.InvariantCultureIgnoreCase)) flags = current.InnerText;
                    else if (current.Name.Equals("fqdoInfo", StringComparison.InvariantCultureIgnoreCase)) fqdoInfo = current.InnerText;

                    else if (current.Name.Equals("productFieldInfo", StringComparison.InvariantCultureIgnoreCase))
                        fields.Add(ProductFieldInfo.LoadFromXml(current));
                    else
                        throw new Exception(string.Format("Unexpected node '{0}'", current.Name));

                    current = current.NextSibling;
                }
                baseNode = baseNode.NextSibling;
            }

            fields = new ObservableCollection<ProductFieldInfo>(fields.OrderBy(X => X.displayOrder).ToList());

            return result = new MoneygramResponse(fields);

        }

    }
}
