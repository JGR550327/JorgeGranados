﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace TesterOMPI.Model.Moneygram
{
    public class ProductFieldInfo
    {
        public enum FieldVisibility
        {
            REQ,
            OPT,
            SUPT_OPT, 
            NOT_ALL,
            UNDEFINED
        }


        public string xmlTag;
        public FieldVisibility visibility;
        public string fieldLabel;
        public int displayOrder;
        public string dynamica;
        public long fieldMax;
        public long fieldMin;
        public string dataType;
        public bool enumerated;
        public string defaultValue;
        public string validationRegEx;
        public string arrayName;
        public int arrayLength;
        public string exampleFormat;
        public string enumeratedValues;

        public string XmlTag { get { return xmlTag; } }
        public FieldVisibility Visibility { get { return visibility; } }
        public string FieldLabel { get { return fieldLabel; } }
        public int DisplayOrder { get { return displayOrder; } }
        public string Dynamic { get { return dynamica; } }
        public long FieldMax { get { return fieldMax; } }
        public long FieldMin { get { return fieldMin; } }
        public string DataType { get { return dataType; } }
        public bool Enumerated { get { return enumerated; } }
        public string DefaultValue { get { return defaultValue; } }
        public string ValidationRegEx { get { return validationRegEx; } }
        public string ArrayName { get { return arrayName; } }
        public int ArrayLength { get { return arrayLength; } }
        public string ExampleFormat { get { return exampleFormat; } }
        public string EnumeratedValues { get { return enumeratedValues; } }

        public ProductFieldInfo(string xmlTag, string visibility, string fieldLabel, string displayOrder, string dynamica, string fieldMax, string fieldMin,
            string dataType, string enumerated, string defaultValue, string validationRegEx, string arrayName, string arrayLength, string exampleFormat, string enumeratedValues)
        {
            this.xmlTag = xmlTag;
            this.visibility = visibility=="REQ"?FieldVisibility.REQ: 
                              visibility=="OPT"?FieldVisibility.OPT:
                              visibility=="SUPT_OPT"?FieldVisibility.SUPT_OPT:
                              visibility=="NOT_ALL"? FieldVisibility.NOT_ALL:FieldVisibility.UNDEFINED;
            this.fieldLabel = fieldLabel;
            this.displayOrder = int.Parse(displayOrder);
            this.dynamica = dynamica;
            this.fieldMax = long.Parse(fieldMax);
            this.fieldMin = long.Parse(fieldMin);
            this.dataType = dataType;
            this.enumerated = bool.Parse(enumerated);
            this.defaultValue = defaultValue;
            this.validationRegEx = validationRegEx;
            this.arrayName = arrayName;
            this.arrayLength = int.Parse(arrayLength);
            this.exampleFormat = exampleFormat;
            this.enumeratedValues = enumeratedValues;
        }


        public static ProductFieldInfo LoadFromXml(XmlNode baseNode)
        {
            string xmlTag = string.Empty;
            string visibility = string.Empty;
            string fieldLabel = string.Empty;
            string displayOrder = string.Empty;
            string dynamica = string.Empty;
            string fieldMax = string.Empty;
            string fieldMin = string.Empty;
            string dataType = string.Empty;
            string enumerated = string.Empty;
            string defaultValue = string.Empty;
            string validationRegEx = string.Empty;
            string arrayName = string.Empty;
            string arrayLength = string.Empty;
            string exampleFormat = string.Empty;
            string enumeratedValues = string.Empty;

            XmlNode current = baseNode.FirstChild;

            while (current!=null)
            {


                if (current.Name == "xmlTag") xmlTag = current.InnerText;
                else if (current.Name == "visibility") visibility = current.InnerText;
                else if (current.Name == "fieldLabel") fieldLabel = current.InnerText;
                else if (current.Name == "displayOrder") displayOrder = current.InnerText;
                else if (current.Name == "dynamic") dynamica = current.InnerText;
                else if (current.Name == "fieldMax") fieldMax = current.InnerText;
                else if (current.Name == "fieldMin") fieldMin = current.InnerText;
                else if (current.Name == "dataType") dataType = current.InnerText;
                else if (current.Name == "enumerated") enumerated = current.InnerText;
                else if (current.Name == "defaultValue") defaultValue = current.InnerText;
                else if (current.Name == "validationRegEx") validationRegEx = current.InnerText;
                else if (current.Name == "arrayName") arrayName = current.InnerText;
                else if (current.Name == "arrayLength") arrayLength = current.InnerText;
                else if (current.Name == "exampleFormat") exampleFormat = current.InnerText;
                else if (current.Name == "enumeratedValues") enumeratedValues = current.InnerText;
                else
                    throw new Exception(string.Format("Unexpected node name '{0}'", current.Name));
                current = current.NextSibling;
            }
            return new ProductFieldInfo(xmlTag, visibility, fieldLabel, displayOrder, dynamica, fieldMax, fieldMin, dataType, enumerated, defaultValue, validationRegEx, arrayName, arrayLength, exampleFormat, enumeratedValues);
        }


    }
}
