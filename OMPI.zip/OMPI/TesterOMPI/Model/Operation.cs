﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace TesterOMPI.Model
{
    public class Operation : NoticationObject
    {

     
        

        //private string xmlFieldResponse;

        //public string XmlFieldResponse
        //{
        //    get { return xmlFieldResponse; }

        //}






        private ObservableCollection<Field> fields = new ObservableCollection<Field>();

        public ObservableCollection<Field> Fields
        {
            get { return fields; }
            set { fields = value; }
        }

        private ObservableCollection<Field> responseFields = new ObservableCollection<Field>();

        public ObservableCollection<Field> ResponseFields
        {
            get { return responseFields; }
            set { 
                responseFields = value;
               

            }
        }


        private string description;

        public string Description
        {
            get { return description; }
            set
            {
                description = value;
                NotifyPropertyChanged("Description");
            }
        }


        private string key;

        public string Key
        {
            get { return key; }
            set
            {
                key = value;
                NotifyPropertyChanged("Key");
            }
        }

        public override string ToString()
        {
            return string.Format("{0} - {1}", key, description);
        }
    }
}
