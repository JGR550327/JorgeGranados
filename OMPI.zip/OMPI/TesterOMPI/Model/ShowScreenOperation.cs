﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TesterOMPI.Model.SpecialOperationCodes
{
    class ShowScreenOperation:SpecialOperation
    {
        private List<XmlField> fields;

        public List<XmlField> Fields
        {
            get { return fields; }
        }

        public ShowScreenOperation(string operationCode, ActionRule action, State onMessage, List<XmlField> fields,string opType)
            :base(operationCode,action,onMessage,opType)
        {
            this.operationCode = operationCode;
            this.action = action;
            this.onMessage = onMessage;
            this.fields = fields;
        }

    }
}
