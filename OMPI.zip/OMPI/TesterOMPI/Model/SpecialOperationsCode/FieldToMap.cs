﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TesterOMPI.Model.SpecialOperationCodes
{
    public class FieldToMap
    {

        public enum MappingAction
        {
            Copy
        }

        private string operationCode;
        public string OperationCode
        {
            get { return operationCode; }
           
        }

        private string fromXmlField;
        public string FromXmlField
        {
            get { return fromXmlField; }
          
        }

        //private string fromField;
        //public string FromField
        //{
        //    get { return fromField; }
         
        //}


        private string xmlFieldName;
        public string XmlFieldName
        {
            get { return xmlFieldName; }
           
        }

        private string toParameterField;
        public string ToParameterField
        {
            get { return toParameterField; }
           
        }
        

        private MappingAction action;
        public MappingAction Action
        {
            get { return action; }
          
        }

        public FieldToMap(string operationCode, string xmlFieldName, string fromXmlField, string toParameterField, MappingAction action)
        {
            this.operationCode = operationCode;
            this.xmlFieldName = xmlFieldName;
            this.fromXmlField = fromXmlField;
            this.toParameterField = toParameterField;
            this.action = action;
        }

    }
}
