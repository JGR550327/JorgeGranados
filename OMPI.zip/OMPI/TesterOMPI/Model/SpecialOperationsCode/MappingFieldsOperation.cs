﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TesterOMPI.Model.SpecialOperationCodes
{
    class MappingFieldsOperation:SpecialOperation
    {
        private List<FieldToMap> fieldsRelationship;

        public List<FieldToMap>FieldsRelationship
        {
            get { return fieldsRelationship; }
        }

        public MappingFieldsOperation(string operationCode, ActionRule action, State onMessage, string opType, List<FieldToMap> fieldsRelationship)
            : base(operationCode, action, onMessage,opType)
        {
            this.operationCode = operationCode;
            this.action = action;
            this.onMessage = onMessage;
            this.fieldsRelationship = fieldsRelationship;
        }

    }
}
