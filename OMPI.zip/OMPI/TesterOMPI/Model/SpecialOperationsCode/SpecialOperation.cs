﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace TesterOMPI.Model.SpecialOperationCodes
{


    public class SpecialOperation
    {

        public enum ActionRule
        {
            ShowScreen,
            MappingFields,
            Undefined
        }

        public enum State
        {
            Request,
            Response,
            Undefined
        }

        public enum OperationType
        {
            DataLogic,
            MoneyGram,
            Undefined
        }


        protected string operationCode;
        public string OperationCode
        {
            get { return operationCode; }
        }

        protected ActionRule action;
        public ActionRule Action
        {
            get { return action; }
        }

        protected State onMessage;
        public State OnMessage
        {
            get { return onMessage; }

        }

        private OperationType opType;

        public OperationType Type
        {
            get { return opType; }
            set { opType = value; }
        }


        public SpecialOperation(string operationCode, ActionRule action, State onMessage, string opType)
        {
            this.opType = opType == "DataLogic" ? OperationType.DataLogic : opType == "MoneyGram" ? OperationType.MoneyGram : OperationType.Undefined;
            this.operationCode = operationCode;
            this.action = action;
            this.onMessage = onMessage;
        }


        public static SpecialOperation LoadFromXml(XmlNode baseNode)
        {
            SpecialOperation result = null;
            XmlNode current = baseNode;
            XmlAttribute attr;
            string operationCode;
            string description;
            State messageType;
            ActionRule action;
            string type;

            if ((attr = baseNode.Attributes["OperationCode"]) == null)
                throw new Exception(string.Format("Missing attribute 'OperationCode'"));
            else
                operationCode = attr.Value;

            attr = baseNode.Attributes["OperationType"];
            type = attr != null ? attr.Value : "";

            if ((attr = baseNode.Attributes["Description"]) == null)
                throw new Exception(string.Format("Missing attribute 'Description'"));
            else
                description = attr.Value;

            if ((attr = baseNode.Attributes["MessageType"]) == null)
                throw new Exception(string.Format("Missing attribute 'MessageType'"));
            else
            {

                var messageTypeString = attr.Value;
                switch (messageTypeString)
                {
                    case "Request":
                        messageType = State.Request;
                        break;
                    case "Response":
                        messageType = State.Response;
                        break;
                    default:
                        messageType = State.Undefined;
                        break;
                }
            }

            if ((attr = baseNode.Attributes["Action"]) == null)
                throw new Exception(string.Format("Missing attribute 'Action'"));
            else
            {
                var actionString = attr.Value;
                switch (actionString)
                {
                    case "ShowScreenFromXmlField":
                        action = ActionRule.ShowScreen;
                        break;
                    case "MappingFromXmlField":
                        action = ActionRule.MappingFields;
                        break;
                    default:
                        action = ActionRule.Undefined;
                        break;
                }
            }

            current = baseNode.FirstChild;





            switch (action)
            {
                case ActionRule.ShowScreen:
                    List<XmlField> xmlFields = new List<XmlField>();



                    while (current != null)
                    {
                        string fromOperationCode;
                        string xmlFieldName;


                        string whatToShow;
                        string whereToShow;


                        switch (current.Name)
                        {
                            case "ShowScreenFromXmlField":
                                if ((attr = current.Attributes["FromOperationCode"]) == null)
                                    throw new Exception(string.Format("Missing attribute 'FromOperationCode'"));
                                else
                                    fromOperationCode = attr.Value;

                                if ((attr = current.Attributes["XmlFieldName"]) == null)
                                    throw new Exception(string.Format("Missing attribute 'XmlFieldName'"));
                                else
                                    xmlFieldName = attr.Value;



                                if ((attr = current.Attributes["WhatToShow"]) == null)
                                    throw new Exception(string.Format("Missing attribute 'WhatToShow'"));
                                else
                                    whatToShow = attr.Value;

                                if ((attr = current.Attributes["WhereToShow"]) == null)
                                    throw new Exception(string.Format("Missing attribute 'WhereToShow'"));
                                else
                                    whereToShow = attr.Value;


                                //TesterOMPI.Model.SpecialOperationCodes.FieldToMap.MappingAction mAction = FieldToMap.MappingAction.Copy;

                                xmlFields.Add(new XmlField(fromOperationCode, xmlFieldName, whatToShow, whereToShow));

                                break;

                        }

                        current = current.NextSibling;

                    }



                    result = new ShowScreenOperation(operationCode, action, messageType, xmlFields, type);
                    break;

                case ActionRule.MappingFields:


                    List<FieldToMap> fieldsToMap = new List<FieldToMap>();


                    while (current != null)
                    {
                        string fromOperationCode;
                        string xmlFieldName;
                        string fromXmlField;
                        string toParameterField;
                        string actionField;
                        string name = current.Name;

                        switch (current.Name)
                        {
                            case "Field":
                                if ((attr = current.Attributes["FromOperationCode"]) == null)
                                    throw new Exception(string.Format("Missing attribute 'FromOperationCode'"));
                                else
                                    fromOperationCode = attr.Value;

                                if ((attr = current.Attributes["XmlFieldName"]) == null)
                                    throw new Exception(string.Format("Missing attribute 'FromOperationCode'"));
                                else
                                    xmlFieldName = attr.Value;

                                if ((attr = current.Attributes["FromXMLField"]) == null)
                                    throw new Exception(string.Format("Missing attribute 'FromOperationCode'"));
                                else
                                    fromXmlField = attr.Value;

                                if ((attr = current.Attributes["ToPameterField"]) == null)
                                    throw new Exception(string.Format("Missing attribute 'FromOperationCode'"));
                                else
                                    toParameterField = attr.Value;

                                if ((attr = current.Attributes["Action"]) == null)
                                    throw new Exception(string.Format("Missing attribute 'FromOperationCode'"));
                                else
                                    actionField = attr.Value;

                                TesterOMPI.Model.SpecialOperationCodes.FieldToMap.MappingAction mAction = FieldToMap.MappingAction.Copy;

                                fieldsToMap.Add(new FieldToMap(fromOperationCode, xmlFieldName, fromXmlField, toParameterField, mAction));

                                break;

                        }

                        current = current.NextSibling;
                    }


                    result = new MappingFieldsOperation(operationCode, action, messageType, "", fieldsToMap);
                    break;

                default:
                    break;
            }


            return result;
        }


    }
}
