﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace TesterOMPI.Model.SpecialOperationCodes
{
    public class SpecialOperationCodes
    {
        private List<SpecialOperation> operations;

        public List<SpecialOperation> Operations
        {
            get { return operations; }

        }



        public SpecialOperationCodes()
        {

        }

        public SpecialOperationCodes(List<SpecialOperation> Operations)
        {
            this.operations = Operations;
        }


        public static SpecialOperationCodes LoadFromXML(string filePath)
        {
            List<SpecialOperation> specialOperations = new List<SpecialOperation>();
            
            XmlReaderSettings xrs = new XmlReaderSettings();
            xrs.IgnoreComments = true;
            xrs.IgnoreWhitespace = false;

            using (XmlReader reader = XmlReader.Create(filePath, xrs))
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(reader);

                var baseNode = doc.FirstChild;

                if (!baseNode.Name.Equals("SpecialOperationCodes"))
                    throw new Exception(string.Format("Unexpected node name '{0}'", baseNode.Name));

                XmlNode current = baseNode;

                current = current.FirstChild;
                while (current != null)
                {
                    if (current.Name.Equals("Operation", StringComparison.InvariantCultureIgnoreCase))
                        specialOperations.Add(SpecialOperation.LoadFromXml(current));
                    else
                        throw new Exception(string.Format("Unexpected node '{0}'", current.Name));

                    current = current.NextSibling;
                }

            }

            return new SpecialOperationCodes(specialOperations);
        }

    }
}
