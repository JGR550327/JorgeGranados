﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TesterOMPI.Model.SpecialOperationCodes
{
    public class XmlField
    {
        public enum ShowFieldAction
        {
            DataOnly,
            XmlData
        }

        public enum ShowPlace
        {
            OnPopup,
            OnSameWindow
        }

        private string fromOperationCode;
        public string FromOperationCode
        {
            get { return fromOperationCode; }
            set { fromOperationCode = value; }
        }

        private string xmlFieldName;
        public string XMLFieldName
        {
            get { return xmlFieldName; }
            set { xmlFieldName = value; }
        }

        private ShowFieldAction show;
        public ShowFieldAction Show
        {
            get { return show; }
            set { show = value; }
        }

        private ShowPlace showOn;
        public ShowPlace ShowOn
        {
            get { return showOn; }
            set { showOn = value; }
        }

        public XmlField(string fromOperationCode, string xmlFieldName, string show, string showOn)
        {
            this.fromOperationCode = fromOperationCode;
            this.xmlFieldName = xmlFieldName;
            this.show = show=="DataOnly"? ShowFieldAction.DataOnly: ShowFieldAction.XmlData;
            this.showOn = showOn == "OnSameWindow"? ShowPlace.OnSameWindow: ShowPlace.OnPopup;
        }

    }
}
