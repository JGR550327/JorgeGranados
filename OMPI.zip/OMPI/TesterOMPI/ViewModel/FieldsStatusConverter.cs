﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using TesterOMPI.Model;

namespace TesterOMPI.ViewModel
{
    class FieldsStatusConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            var field = (Field)value;
            var inputValue = (string)field.Value;
            CultureInfo enUS = new CultureInfo("Es");
            DateTime date;
            if (field.Key=="LOCAL_DATE"  && DateTime.TryParseExact(inputValue, "MMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out date))
            {
                return false;
            }

            if (field.Key=="LOCAL_TIME" && DateTime.TryParseExact(inputValue, "HHmmss", CultureInfo.InvariantCulture, DateTimeStyles.None, out date))
            {
                return false;
            }

            return true;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return value;
        }
    }
}
