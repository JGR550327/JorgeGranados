﻿

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using TesterOMPI.Model;
using System.Runtime.Serialization;
using System.IO;

using OMPI;

using System.Xml;
using System.Windows;
using TesterOMPI.Model.SpecialOperationCodes;
using System.Runtime.Serialization.Formatters.Binary;
using TesterOMPI.Model.DatalogicXml;
using TesterOMPI.Model.Moneygram;

namespace TesterOMPI.ViewModel
{
    class OMPIViewModel : NoticationObject
    {

        private Dictionary<string, MoneygramResponse> mgResponses;

        public Dictionary<string, MoneygramResponse> MgResponses
        {
            get { return mgResponses; }
            set { mgResponses = value; }
        }

        private Dictionary<string, DatalogicResponse> dlResponses;

        public Dictionary<string, DatalogicResponse> DlResponses
        {
            get { return dlResponses; }
            set { dlResponses = value; NotifyPropertyChanged("DlResponses"); }
        }

        private SpecialOperationCodes specialOperations;

        public SpecialOperationCodes SpecialOperations
        {
            get { return specialOperations; }
            set { specialOperations = value; }
        }

        //private SpecialOperation currentRequestSpecialOperation;
        //private SpecialOperation currentResponseSpecialOperation;

        private DatalogicResponse currentDLResponse;

        public DatalogicResponse CurrentDLResponse
        {
            get { return currentDLResponse; }
            set { currentDLResponse = value; NotifyPropertyChanged("CurrentDLResponse"); }
        }

        private MoneygramResponse currentMGResponse;

        public MoneygramResponse CurrentMGResponse
        {
            get { return currentMGResponse; }
            set { currentMGResponse = value; }
        }


        private string isoRequest;
        public string IsoRequest
        {
            get { return isoRequest; }
            set { isoRequest = value; NotifyPropertyChanged("IsoRequest"); }
        }

        private string isoResponse;
        public string IsoResponse
        {
            get { return isoResponse; }
            set { isoResponse = value; NotifyPropertyChanged("IsoResponse"); }
        }

        private string error;

        public string Error
        {
            get { return error; }
            set { error = value; }
        }



        private string path;
        public string Path
        {
            get { return path; }
            set { path = value; NotifyPropertyChanged("Path"); }
        }

        private Dictionary<string, MsgConfiguration> ConfigDict;

        private Field newField;
        public Field NewField
        {
            get { return newField; }
            set { newField = value; NotifyPropertyChanged("NewField"); }
        }

        private Field selectedField;
        public Field SelectedField
        {
            get { return selectedField; }
            set { selectedField = value; NotifyPropertyChanged("SelectedField"); }
        }

        private Operation currentOperation;
        public Operation CurrentOperation
        {
            get { return currentOperation; }
            set
            {
                currentOperation = value;
                if (currentOperation != null)
                {
                    var dateField = (from field in currentOperation.Fields
                                     where field.Key == "LOCAL_DATE"
                                     select field).FirstOrDefault();

                    if (dateField != null)
                        dateField.Value = DateTime.Now.ToString("MMdd");

                    var timeField = (from field in currentOperation.Fields
                                     where field.Key == "LOCAL_TIME"
                                     select field).FirstOrDefault();

                    if (timeField != null)
                        timeField.Value = DateTime.Now.ToString("HHmmss");

                    var traceNumberF = (from field in currentOperation.Fields
                                        where field.Key == "TraceNumber"
                                        select field).FirstOrDefault();

                    if (traceNumberF != null)
                        traceNumberF.Value = traceNumber.ToString();
                    traceNumber++;

                    //var specialOperationForThisCode = (from op in specialOperations.Operations
                    //                                   where op.OperationCode == currentOperation.Key
                    //                                   select op).ToList();

                    //currentRequestSpecialOperation = specialOperationForThisCode.Where(X => X.OnMessage == SpecialOperation.State.Request).FirstOrDefault();
                    //currentResponseSpecialOperation = specialOperationForThisCode.Where(X => X.OnMessage == SpecialOperation.State.Response).FirstOrDefault();

                    //if (currentRequestSpecialOperation != null)
                    //{
                    //    if (currentRequestSpecialOperation is MappingFieldsOperation)
                    //    {
                    //        var mapOperation = (MappingFieldsOperation)currentRequestSpecialOperation;
                    //        foreach (var field in mapOperation.FieldsRelationship)
                    //        {
                    //            var op = operations.Where(X => X.Key == field.OperationCode).FirstOrDefault();
                    //            Console.Write(op);
                    //            var val = op.ResponseFields.Where(X => X.Key == field.FromXmlField).FirstOrDefault();
                    //            Console.Write(val);
                    //            //currentOperation.Fields.Where(X => X.Key == field.ToParameterField).FirstOrDefault().Value
                    //            //= operations.Where(X => X.Key == field.OperationCode).FirstOrDefault().ResponseFields.Where(X => X.Key == field.FromXmlField).FirstOrDefault().Value;
                    //            currentOperation.Fields.Where(X => X.Key == field.ToParameterField).FirstOrDefault().Value
                    //                = CurrentDLResponse.ToString();
                    //        }
                    //    }
                    //}
                }
                NotifyPropertyChanged("CurrentOperation");
            }
        }



        private ObservableCollection<Operation> operations = new ObservableCollection<Operation>();
        public ObservableCollection<Operation> Operations
        {
            get { return operations; }
            set
            {
                operations = value;
                NotifyPropertyChanged("Operations");
            }
        }

        private Operation newOperation;
        public Operation NewOperation
        {
            get { return newOperation; }
            set { newOperation = value; NotifyPropertyChanged("NewOperation"); }
        }


        int traceNumber = new Random(DateTime.Now.Millisecond).Next(100000, 999999);


        public DelegateCommand AddOperationCommand { get; private set; }
        public DelegateCommand AddFieldCommand { get; private set; }
        public DelegateCommand RemoveOperationCommand { get; private set; }
        public DelegateCommand RemoveFieldCommand { get; private set; }
        public DelegateCommand SaveAllCommand { get; private set; }
        public DelegateCommand LoadOperationsCommand { get; private set; }
        public DelegateCommand SendTrxCommand { get; private set; }
        public DelegateCommand ReloadCommand { get; private set; }
        public DelegateCommand LoadNewConfigCommand { get; private set; }

        void addOperation()
        {
            operations.Add(newOperation);
            NewOperation = new Operation();
        }

        void addField()
        {
            currentOperation.Fields.Add(newField);
            NewField = new Field() { Key = "", Value = "" };
        }

        void RemoveOperation()
        {
            operations.Remove(currentOperation);
        }

        void Reload()
        {
            ConfigurationManager configMng = new ConfigurationManager();
            try
            {
                ConfigDict = configMng.GetConfig(path);
                NewField = new Field();
                NewOperation = new Operation();


                //Console.WriteLine(OMPI.MsgConfiguration.GetRemittanceCompanyFromMTCN("12345678"));
                //Console.WriteLine(OMPI.MsgConfiguration.GetRemittanceCompanyFromMTCN("12345678987"));
                //Console.WriteLine(OMPI.MsgConfiguration.GetRemittanceCompanyFromMTCN("12345678"));
                //Console.WriteLine(OMPI.MsgConfiguration.GetRemittanceCompanyFromMTCN("1234567898"));
                //Console.WriteLine(OMPI.MsgConfiguration.GetRemittanceCompanyFromMTCN("12345678234"));
                //Console.WriteLine(OMPI.MsgConfiguration.GetRemittanceCompanyFromMTCN("12345678"));
                //Console.WriteLine(OMPI.MsgConfiguration.GetRemittanceCompanyFromMTCN("1234567"));
                //Console.WriteLine(OMPI.MsgConfiguration.GetRemittanceCompanyFromMTCN("123456781a"));


                List<ServiceItem> availableServices = ConfigDict["OMPIConfig"].GetAvalaibleServices();
                foreach (var serviceItem in availableServices)
                {
                    Console.WriteLine("{0} - {1}", serviceItem.OperationCode, serviceItem.Description);
                }


                List<DataLogicService> dlServices = ConfigDict["OMPIConfig"].GetDataLogicAvailableServices();
                foreach (var dlService in dlServices)
                {
                    Console.WriteLine("{0} - {1}", dlService.SKU, dlService.Description);
                }


                //var service1 = services.FirstOrDefault();
                var operationsData = ConfigDict.First().Value.GetOperationsFieldsData();



                Operations.Clear();
                foreach (var operation in operationsData)
                {
                    Operation op = new Operation();
                    op.Key = operation.Key;
                    op.Fields = new ObservableCollection<Field>((from fieldx in operation.Value.Value
                                                                 select new Field() { Key = fieldx }).ToList());
                    op.Description = operation.Value.Key;
                    Operations.Add(op);

                }

                if (operations.Count > 0)
                {
                    CurrentOperation = operations.First();
                }

            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }


        }

        void RemoveField()
        {
            currentOperation.Fields.Remove(selectedField);
        }

        void LoadOperations()
        {
            string fileName = "";
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            // Set filter for file extension and default file extension 
            //dlg.DefaultExt = ".txt";
            //dlg.Filter = "JPEG Files (*.jpeg)|*.jpeg|PNG Files (*.png)|*.png|JPG Files (*.jpg)|*.jpg|GIF Files (*.gif)|*.gif";
            // Display OpenFileDialog by calling ShowDialog method 
            Nullable<bool> result = dlg.ShowDialog();
            // Get the selected file name and display in a TextBox 
            if (result == true)
            {
                // Open document 
                fileName = dlg.FileName;

                DataContractSerializer serializer = new DataContractSerializer(typeof(ObservableCollection<Operation>));

                FileStream fs = new FileStream(fileName, FileMode.Open);
                XmlDictionaryReader reader =
               XmlDictionaryReader.CreateTextReader(fs, new XmlDictionaryReaderQuotas());
                DataContractSerializer ser = new DataContractSerializer(typeof(ObservableCollection<Operation>));

                // Deserialize the data and read it from the instance.
                Operations =
                   (ObservableCollection<Operation>)ser.ReadObject(reader, true);
                reader.Close();
                fs.Close();

                if (operations.Count > 0)
                {
                    CurrentOperation = operations.First();
                }

            }



        }

        void LoadNewConfig()
        {
            string fileName = "";
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            // Set filter for file extension and default file extension 
            //dlg.DefaultExt = ".txt";
            //dlg.Filter = "JPEG Files (*.jpeg)|*.jpeg|PNG Files (*.png)|*.png|JPG Files (*.jpg)|*.jpg|GIF Files (*.gif)|*.gif";
            // Display OpenFileDialog by calling ShowDialog method 
            Nullable<bool> result = dlg.ShowDialog(); 
            // Get the selected file name and display in a TextBox 
            if (result == true)
            {
                // Open document 
                fileName = dlg.FileName;

                Path = fileName;

                Reload();
            }
        }


        void sendTrx()
        {
            try
            {


                //string resultMessage = null;

                MessageData reqSrcData = new MessageData(MsgDefinitionTypes.Xml, "WINCOR", null);

                foreach (var item in currentOperation.Fields)
                {
                    if (item.Value != null)
                        reqSrcData.FieldValues.Add(item.Key, item.Value);
                }




                //bool approved = false;
                //bool requiresSignature = true;


                MsgConfiguration msgConfig = ConfigDict.First().Value;

                MsgAttributes msgAttr = new MsgAttributes(currentOperation.Key);

                string result = "NA";

                MessageFlow msgFlow = null;
                //if (currentOperation.Key != "9999")
                //{
                msgFlow = MessageFlow.ProcessMessage(msgConfig, msgAttr, reqSrcData.FieldValues);


                CurrentOperation = currentOperation;
                //}
                //else
                //{
                //    result = OMPI.PinpadUtils.InitializePinPadKeys(msgConfig, reqSrcData.FieldValues);
                //}


                //#if DEBUG

                //                IFormatter formatter = new BinaryFormatter();
                //                Stream stream = new FileStream(currentOperation.Description+ ".bin",
                //                                         FileMode.Create,
                //                                         FileAccess.Write, FileShare.None);
                //                formatter.Serialize(stream, msgFlow);
                //                stream.Close();

                //#endif




                if (currentOperation.Key != "9999")
                {
                    if (msgFlow.ResponseSource != null)
                    {
                        currentOperation.ResponseFields.Clear();

                        foreach (var item in msgFlow.ResponseSource.FieldValues)
                        {
                            currentOperation.ResponseFields.Add(new Field() { Key = item.Key, Value = item.Value });
                        }


                        //if (currentResponseSpecialOperation != null)
                        //{
                        //    if (currentResponseSpecialOperation is ShowScreenOperation
                        //        && currentResponseSpecialOperation.Type == SpecialOperation.OperationType.DataLogic)
                        //    {
                        //        var showData = (ShowScreenOperation)currentResponseSpecialOperation;
                        //        var data = currentOperation.ResponseFields.Where(X => X.Key == showData.Fields.FirstOrDefault().XMLFieldName).FirstOrDefault();

                        //        CurrentDLResponse = DatalogicResponse.LoadFromXml(data.Value);
                        //    }
                        //}

                    }
                    else
                    {
                        MessageBox.Show(msgFlow.ErrorMessage);
                    }
                }
                else
                {
                    MessageBox.Show(result, "Inicializacion");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
            }
        }

        void SaveAll()
        {
            string fileName;


            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
            // Set filter for file extension and default file extension 
            //dlg.DefaultExt = ".txt";
            //dlg.Filter = "JPEG Files (*.jpeg)|*.jpeg|PNG Files (*.png)|*.png|JPG Files (*.jpg)|*.jpg|GIF Files (*.gif)|*.gif";
            // Display OpenFileDialog by calling ShowDialog method 
            Nullable<bool> result = dlg.ShowDialog();
            // Get the selected file name and display in a TextBox 
            if (result == true)
            {
                // Open document 
                string filename = dlg.FileName;

                fileName = dlg.FileName;

                DataContractSerializer serializer = new DataContractSerializer(typeof(ObservableCollection<Operation>));

                var tempOperations = operations;

                foreach (var item in tempOperations)
                {
                    item.ResponseFields = new ObservableCollection<Field>();
                }


                FileStream writer = new FileStream(fileName, FileMode.Create);

                serializer.WriteObject(writer, tempOperations);
                writer.Close();
            }


        }






        public OMPIViewModel()
        {
            try
            {

                this.AddOperationCommand = new DelegateCommand(this.addOperation);
                this.AddFieldCommand = new DelegateCommand(this.addField);
                this.RemoveFieldCommand = new DelegateCommand(this.RemoveField);
                this.RemoveOperationCommand = new DelegateCommand(this.RemoveOperation);
                this.SaveAllCommand = new DelegateCommand(this.SaveAll);
                this.LoadOperationsCommand = new DelegateCommand(this.LoadOperations);
                this.SendTrxCommand = new DelegateCommand(this.sendTrx);
                this.ReloadCommand = new DelegateCommand(this.Reload);
                this.LoadNewConfigCommand = new DelegateCommand(this.LoadNewConfig);

                path = @"OMPIConfig.xml";
                Reload();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
            }
        }
    }
}
